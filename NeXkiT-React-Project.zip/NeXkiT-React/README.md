# NeXkiT

A React + Vite toolkit website with a dark glass-inspired interface.

## What's included

- Responsive homepage, search, category filters, favorites, theme toggle and tool workspace UI.
- Ready browser-side tools: word counter, JSON formatter, Base64 encode, URL encode, UUID generator, QR generator, password generator, percentage calculator, image resize, image conversion to PNG and JPEG compression.
- Planned tool catalogue for PDF, image, video/audio, developer and everyday utilities.
- GitHub Pages deployment workflow at `.github/workflows/deploy.yml`.

**Important:** Tools marked “Coming soon” are catalogue entries only. PDF merge/split/compression, video/audio processing, OCR, background removal and other advanced tools still need their processing engines integrated. The app does not claim these are implemented.

## Requirements

Node.js 20.19+ or 22.12+ recommended.

## Run locally

```bash
npm install
npm run dev
```

## Build for hosting

```bash
npm install
npm run build
```

Upload the contents of the generated `dist/` folder to Apache's document root (often `public_html/`, `htdocs/` or a configured site directory).

## GitHub Pages

1. Create a GitHub repository and upload the project files (the contents of this ZIP).
2. Push them to the `main` branch.
3. In GitHub, open **Settings → Pages**.
4. Set the source to **GitHub Actions**.
5. The included workflow builds and deploys the site on each push to `main`.

For a custom domain, configure it under **Settings → Pages** and add the DNS records required by GitHub Pages. Do not upload the source project directly as a static Apache website; build it first and publish `dist/`.

## Privacy

The included ready tools process text and images locally in the browser. No NeXkiT application backend or file-upload server is included.
