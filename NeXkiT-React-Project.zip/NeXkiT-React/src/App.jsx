import { useMemo, useRef, useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import QRCode from 'qrcode'
import {
  ArrowDownToLine, ArrowRight, ArrowUpRight, AudioLines, Braces, Check, ChevronDown,
  CircleHelp, Code2, Command, Copy, FileArchive, FileImage, FileText, Film, Heart,
  Image as ImageIcon, Menu, Moon, Search, ShieldCheck, Sparkles, Sun, Upload, Video,
  WandSparkles, X, Zap, Calculator, Hash, Link as LinkIcon, Type, LockKeyhole
} from 'lucide-react'

const categories = [
  { id: 'all', name: 'All tools', icon: Command },
  { id: 'pdf', name: 'PDF tools', icon: FileText },
  { id: 'image', name: 'Image tools', icon: ImageIcon },
  { id: 'video', name: 'Video & audio', icon: Film },
  { id: 'developer', name: 'Developer', icon: Code2 },
  { id: 'everyday', name: 'Everyday', icon: Calculator },
]

const tools = [
  { id:'word-counter', name:'Word Counter', desc:'Count words, characters, sentences and reading time.', category:'everyday', icon:Type, status:'Ready', action:'word' },
  { id:'json-formatter', name:'JSON Formatter', desc:'Format, validate and minify JSON data.', category:'developer', icon:Braces, status:'Ready', action:'json' },
  { id:'base64', name:'Base64 Encoder / Decoder', desc:'Encode or decode text locally in your browser.', category:'developer', icon:Code2, status:'Ready', action:'base64' },
  { id:'url-codec', name:'URL Encoder / Decoder', desc:'Safely encode or decode URL components.', category:'developer', icon:LinkIcon, status:'Ready', action:'url' },
  { id:'uuid', name:'UUID Generator', desc:'Generate random UUID identifiers.', category:'developer', icon:Hash, status:'Ready', action:'uuid' },
  { id:'qr', name:'QR Code Generator', desc:'Create and download a QR code from text or a link.', category:'everyday', icon:Command, status:'Ready', action:'qr' },
  { id:'password', name:'Password Generator', desc:'Generate a strong random password on your device.', category:'everyday', icon:LockKeyhole, status:'Ready', action:'password' },
  { id:'image-convert', name:'Image Converter', desc:'Convert common image formats in your browser.', category:'image', icon:FileImage, status:'Ready', action:'image' },
  { id:'image-resize', name:'Image Resizer', desc:'Resize an image to custom pixel dimensions.', category:'image', icon:ImageIcon, status:'Ready', action:'resize' },
  { id:'image-crop', name:'Image Cropper', desc:'Crop an image and save the result.', category:'image', icon:ImageIcon, status:'Coming soon' },
  { id:'image-compress', name:'Image Compressor', desc:'Reduce image file size with adjustable quality.', category:'image', icon:FileArchive, status:'Ready', action:'compress' },
  { id:'pdf-merge', name:'PDF Merger', desc:'Combine PDF documents into one file.', category:'pdf', icon:FileText, status:'Coming soon' },
  { id:'pdf-split', name:'PDF Splitter', desc:'Extract selected pages from a PDF.', category:'pdf', icon:FileText, status:'Coming soon' },
  { id:'pdf-compress', name:'PDF Compressor', desc:'Reduce the size of PDF documents.', category:'pdf', icon:FileArchive, status:'Coming soon' },
  { id:'pdf-to-image', name:'PDF to Image', desc:'Export PDF pages as images.', category:'pdf', icon:FileImage, status:'Coming soon' },
  { id:'video-compress', name:'Video Compressor', desc:'Compress video files with quality controls.', category:'video', icon:Video, status:'Coming soon' },
  { id:'video-convert', name:'Video Converter', desc:'Convert video formats in the browser.', category:'video', icon:Film, status:'Coming soon' },
  { id:'audio-extract', name:'Extract Audio', desc:'Extract an audio track from a video.', category:'video', icon:AudioLines, status:'Coming soon' },
  { id:'video-fps', name:'FPS Converter', desc:'Change video frame rate for supported files.', category:'video', icon:Film, status:'Coming soon' },
  { id:'calculator', name:'Percentage Calculator', desc:'Quickly calculate percentages and changes.', category:'everyday', icon:Calculator, status:'Ready', action:'percentage' },
]

function saveBlob(blob, filename) {
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url; a.download = filename; a.click()
  setTimeout(() => URL.revokeObjectURL(url), 1000)
}

function ToolWorkspace({ tool, onClose, notify }) {
  const [input, setInput] = useState('')
  const [output, setOutput] = useState('')
  const [file, setFile] = useState(null)
  const [width, setWidth] = useState(1200)
  const [height, setHeight] = useState(800)
  const [quality, setQuality] = useState(0.82)
  const [qrUrl, setQrUrl] = useState('')
  const [percent, setPercent] = useState(15)
  const [base, setBase] = useState(100)
  const fileRef = useRef(null)

  const run = async () => {
    try {
      switch (tool.action) {
        case 'word': {
          const words = input.trim() ? input.trim().split(/\s+/).length : 0
          const chars = input.length
          const sentences = (input.match(/[.!?]+/g) || []).length
          setOutput(`${words} words\n${chars} characters\n${sentences} sentences\n${Math.ceil(words / 200)} min estimated reading time`)
          break
        }
        case 'json': {
          const parsed = JSON.parse(input)
          setOutput(JSON.stringify(parsed, null, 2))
          break
        }
        case 'base64': setOutput(btoa(unescape(encodeURIComponent(input)))); break
        case 'url': setOutput(encodeURIComponent(input)); break
        case 'uuid': setOutput(Array.from({length:5}, () => crypto.randomUUID()).join('\n')); break
        case 'password': {
          const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789!@#$%&*_-'
          const arr = new Uint32Array(4); crypto.getRandomValues(arr)
          setOutput(Array.from(arr, n => chars[n % chars.length]).join('') + ' (sample — generate again for another)')
          break
        }
        case 'qr': {
          const data = await QRCode.toDataURL(input || 'https://example.com', { width: 640, margin: 2, color: { dark: '#111827', light: '#ffffff' } })
          setQrUrl(data); setOutput('QR code ready to download.')
          break
        }
        case 'percentage': setOutput(`${percent}% of ${base} = ${(base * percent / 100).toLocaleString()}\n${base} increased by ${percent}% = ${(base * (1 + percent / 100)).toLocaleString()}\n${base} decreased by ${percent}% = ${(base * (1 - percent / 100)).toLocaleString()}`); break
        case 'image': case 'resize': case 'compress': await processImage(); break
        default: notify('This tool is not available yet.')
      }
    } catch (e) { setOutput(`Please check your input: ${e.message}`); }
  }

  const processImage = async () => {
    if (!file) { notify('Choose an image first.'); return }
    const img = new Image()
    const src = URL.createObjectURL(file)
    img.onload = () => {
      const canvas = document.createElement('canvas')
      const w = tool.action === 'resize' ? Number(width) : img.width
      const h = tool.action === 'resize' ? Number(height) : Math.round(img.height * (w / img.width))
      canvas.width = w; canvas.height = h
      canvas.getContext('2d').drawImage(img, 0, 0, w, h)
      const type = tool.action === 'image' ? 'image/png' : 'image/jpeg'
      canvas.toBlob(blob => {
        if (blob) { saveBlob(blob, `${file.name.replace(/\.[^.]+$/, '')}-${tool.action}.${type === 'image/png' ? 'png' : 'jpg'}`); setOutput(`Done. Output: ${(blob.size / 1024).toFixed(1)} KB`); notify('Your image is ready.') }
        URL.revokeObjectURL(src)
      }, type, quality)
    }
    img.onerror = () => { URL.revokeObjectURL(src); notify('Could not read that image.'); }
    img.src = src
  }

  const copy = async () => { await navigator.clipboard.writeText(output); notify('Copied to clipboard.') }

  return <div className="fixed inset-0 z-[80] flex items-end justify-center bg-black/70 p-0 backdrop-blur-sm sm:items-center sm:p-5" onMouseDown={e => e.target === e.currentTarget && onClose()}>
    <motion.div initial={{opacity:0,y:25,scale:.98}} animate={{opacity:1,y:0,scale:1}} className="max-h-[92vh] w-full max-w-2xl overflow-y-auto rounded-t-3xl border border-white/10 bg-[#101321] p-6 shadow-2xl sm:rounded-3xl sm:p-8">
      <div className="mb-6 flex items-start justify-between">
        <div><div className="mb-2 inline-flex rounded-xl bg-violet-500/15 p-3 text-violet-300"><tool.icon size={22}/></div><h2 className="text-2xl font-bold">{tool.name}</h2><p className="mt-1 text-sm text-zinc-400">{tool.desc}</p></div>
        <button onClick={onClose} className="rounded-xl border border-white/10 p-2 text-zinc-400 hover:bg-white/5"><X size={18}/></button>
      </div>
      {['image','resize','compress'].includes(tool.action) ? <div className="space-y-4">
        <button onClick={() => fileRef.current?.click()} className="flex w-full flex-col items-center gap-3 rounded-2xl border border-dashed border-violet-400/30 bg-violet-500/5 p-8 text-center hover:bg-violet-500/10"><Upload className="text-violet-300"/><span className="font-medium">{file ? file.name : 'Choose an image'}</span><span className="text-xs text-zinc-500">PNG, JPG, WebP supported by your browser</span></button>
        <input ref={fileRef} type="file" accept="image/*" className="hidden" onChange={e=>setFile(e.target.files?.[0] || null)}/>
        {tool.action === 'resize' && <div className="grid grid-cols-2 gap-3"><label className="text-sm text-zinc-400">Width (px)<input type="number" value={width} onChange={e=>setWidth(e.target.value)} className="mt-2 w-full rounded-xl border border-white/10 bg-black/20 p-3 text-white"/></label><label className="text-sm text-zinc-400">Height (px)<input type="number" value={height} onChange={e=>setHeight(e.target.value)} className="mt-2 w-full rounded-xl border border-white/10 bg-black/20 p-3 text-white"/></label></div>}
        {tool.action === 'compress' && <label className="block text-sm text-zinc-400">Quality: {Math.round(quality*100)}%<input type="range" min=".2" max=".95" step=".05" value={quality} onChange={e=>setQuality(Number(e.target.value))} className="mt-3 w-full accent-violet-400"/></label>}
      </div> : tool.action === 'percentage' ? <div className="grid grid-cols-2 gap-3"><label className="text-sm text-zinc-400">Percentage<input type="number" value={percent} onChange={e=>setPercent(Number(e.target.value))} className="mt-2 w-full rounded-xl border border-white/10 bg-black/20 p-3 text-white"/></label><label className="text-sm text-zinc-400">Number<input type="number" value={base} onChange={e=>setBase(Number(e.target.value))} className="mt-2 w-full rounded-xl border border-white/10 bg-black/20 p-3 text-white"/></label></div> : <textarea value={input} onChange={e=>setInput(e.target.value)} placeholder={tool.action==='json'?'Paste JSON here...':tool.action==='word'?'Type or paste your text here...':'Enter text or a URL...'} rows={7} className="w-full resize-y rounded-2xl border border-white/10 bg-black/25 p-4 text-sm text-zinc-100 outline-none placeholder:text-zinc-600 focus:border-violet-400/50"/>}
      <button onClick={run} className="mt-5 flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-violet-600 to-indigo-500 px-5 py-3 font-semibold shadow-lg shadow-violet-950/30 transition hover:brightness-110"><Zap size={17}/> {['image','resize','compress'].includes(tool.action) ? 'Process image' : 'Run tool'}</button>
      {qrUrl && <div className="mt-5 flex flex-col items-center gap-3 rounded-2xl bg-white p-5"><img src={qrUrl} alt="Generated QR code" className="w-52"/><button onClick={()=>saveBlob(dataURLtoBlob(qrUrl),'nexkit-qr.png')} className="rounded-lg bg-zinc-900 px-4 py-2 text-sm font-semibold text-white">Download QR</button></div>}
      {output && <div className="mt-5 rounded-2xl border border-white/10 bg-black/25 p-4"><div className="mb-2 flex items-center justify-between text-xs font-semibold uppercase tracking-wider text-zinc-500"><span>Result</span><button onClick={copy} className="flex items-center gap-1 text-violet-300 hover:text-white"><Copy size={13}/> Copy</button></div><pre className="max-h-56 overflow-auto whitespace-pre-wrap break-words text-sm text-zinc-200">{output}</pre></div>}
      <p className="mt-5 text-xs leading-5 text-zinc-600">Processing for these ready tools happens locally in your browser. Files are not uploaded to a NeXkiT server.</p>
    </motion.div>
  </div>
}
function dataURLtoBlob(dataURL) { const [meta, data] = dataURL.split(','); const bytes = atob(data); const arr = new Uint8Array(bytes.length); for(let i=0;i<bytes.length;i++) arr[i]=bytes.charCodeAt(i); return new Blob([arr],{type:meta.match(/:(.*?);/)[1]}) }

export default function App() {
  const [query, setQuery] = useState('')
  const [category, setCategory] = useState('all')
  const [activeTool, setActiveTool] = useState(null)
  const [favorites, setFavorites] = useState(() => JSON.parse(localStorage.getItem('nexkit-favorites') || '[]'))
  const [showFavorites, setShowFavorites] = useState(false)
  const [light, setLight] = useState(false)
  const [toast, setToast] = useState('')
  const [mobileMenu, setMobileMenu] = useState(false)

  const notify = message => { setToast(message); window.clearTimeout(window.__nexkitToast); window.__nexkitToast = window.setTimeout(()=>setToast(''),2600) }
  const filtered = useMemo(() => tools.filter(t => (category==='all' || t.category===category) && `${t.name} ${t.desc} ${t.category}`.toLowerCase().includes(query.toLowerCase()) && (!showFavorites || favorites.includes(t.id))), [query,category,showFavorites,favorites])
  const toggleFavorite = id => { const next = favorites.includes(id) ? favorites.filter(x=>x!==id) : [...favorites,id]; setFavorites(next); localStorage.setItem('nexkit-favorites',JSON.stringify(next)); notify('Favorites updated.') }

  return <div className={light?'min-h-screen bg-[#f5f6fb] text-slate-900':'min-h-screen bg-[#080a12] text-white'}>
    <div className="pointer-events-none fixed inset-0 grid-bg opacity-60"/>
    <div className="pointer-events-none fixed -top-48 left-1/2 h-[520px] w-[760px] -translate-x-1/2 rounded-full bg-violet-600/15 blur-[140px]"/>
    <header className={`sticky top-0 z-50 border-b backdrop-blur-2xl ${light?'border-slate-200 bg-white/80':'border-white/[.07] bg-[#080a12]/80'}`}>
      <nav className="mx-auto flex max-w-7xl items-center justify-between px-5 py-4 lg:px-8">
        <a href="#" className="flex items-center gap-3"><div className="grid h-10 w-10 place-items-center rounded-xl bg-gradient-to-br from-violet-500 to-cyan-400 shadow-lg shadow-violet-900/30"><Zap size={21} fill="white"/></div><div><div className="text-xl font-black tracking-tight">NeXkiT<span className="text-violet-400">.</span></div><div className={`-mt-1 text-[9px] font-semibold uppercase tracking-[.2em] ${light?'text-slate-500':'text-zinc-500'}`}>Everything you need. One kit.</div></div></a>
        <div className="hidden items-center gap-8 text-sm text-zinc-400 md:flex"><a href="#tools" className="hover:text-violet-300">Tools</a><a href="#why" className="hover:text-violet-300">Why NeXkiT</a><a href="#footer" className="hover:text-violet-300">About</a></div>
        <div className="flex items-center gap-2"><button onClick={()=>setLight(!light)} className={`rounded-xl border p-2.5 ${light?'border-slate-200 bg-white text-amber-500':'border-white/10 bg-white/5 text-amber-300'}`} title="Toggle theme">{light?<Moon size={17}/>:<Sun size={17}/>}</button><button onClick={()=>{setShowFavorites(!showFavorites);document.getElementById('tools')?.scrollIntoView({behavior:'smooth'})}} className={`relative rounded-xl border p-2.5 ${light?'border-slate-200 bg-white text-rose-500':'border-white/10 bg-white/5 text-rose-300'}`} title="Favorites"><Heart size={17}/>{favorites.length>0&&<span className="absolute -right-1 -top-1 grid h-4 min-w-4 place-items-center rounded-full bg-rose-500 px-1 text-[9px] text-white">{favorites.length}</span>}</button><button onClick={()=>setMobileMenu(!mobileMenu)} className="rounded-xl border border-white/10 p-2.5 md:hidden"><Menu size={18}/></button></div>
      </nav>
      {mobileMenu&&<div className="border-t border-white/10 px-5 py-4 text-sm md:hidden"><a onClick={()=>setMobileMenu(false)} href="#tools">Explore tools</a></div>}
    </header>
    <main className="relative">
      <section className="mx-auto grid max-w-7xl items-center gap-12 px-5 pb-20 pt-20 lg:grid-cols-[1.1fr_.9fr] lg:px-8 lg:pb-28 lg:pt-28">
        <motion.div initial={{opacity:0,y:18}} animate={{opacity:1,y:0}} transition={{duration:.6}}>
          <div className="mb-7 inline-flex items-center gap-2 rounded-full border border-violet-400/20 bg-violet-400/10 px-4 py-2 text-xs font-semibold text-violet-300"><Sparkles size={14}/> Your everyday digital toolkit</div>
          <h1 className="max-w-3xl text-5xl font-black leading-[1.04] tracking-[-.045em] sm:text-6xl lg:text-7xl">Work smarter.<br/><span className="bg-gradient-to-r from-violet-400 via-fuchsia-300 to-cyan-300 bg-clip-text text-transparent">Not harder.</span></h1>
          <p className={`mt-7 max-w-xl text-base leading-8 ${light?'text-slate-600':'text-zinc-400'}`}>Convert, compress, create and get everyday digital tasks done — with a clean toolkit that stays out of your way.</p>
          <div className={`mt-9 flex max-w-xl items-center gap-3 rounded-2xl border p-2 shadow-2xl ${light?'border-slate-200 bg-white':'border-white/10 bg-white/[.055]'}`}><Search className="ml-3 shrink-0 text-zinc-500" size={20}/><input value={query} onChange={e=>{setQuery(e.target.value);setCategory('all')}} onKeyDown={e=>e.key==='Enter'&&document.getElementById('tools')?.scrollIntoView({behavior:'smooth'})} placeholder="Search 20+ tools..." className={`w-full bg-transparent py-3 text-sm outline-none ${light?'text-slate-900 placeholder:text-slate-400':'text-white placeholder:text-zinc-500'}`}/><button onClick={()=>document.getElementById('tools')?.scrollIntoView({behavior:'smooth'})} className="rounded-xl bg-violet-600 px-4 py-3 text-sm font-semibold text-white hover:bg-violet-500">Search</button></div>
          <div className={`mt-6 flex flex-wrap gap-5 text-xs ${light?'text-slate-500':'text-zinc-500'}`}><span className="flex items-center gap-2"><ShieldCheck size={15} className="text-emerald-400"/> Browser-based processing</span><span className="flex items-center gap-2"><Zap size={15} className="text-amber-400"/> Simple & fast</span><span className="flex items-center gap-2"><Sparkles size={15} className="text-violet-400"/> Free to use</span></div>
        </motion.div>
        <motion.div initial={{opacity:0,scale:.92}} animate={{opacity:1,scale:1}} transition={{duration:.8}} className="relative mx-auto aspect-square w-full max-w-[440px]">
          <div className="absolute inset-4 animate-[spin_45s_linear_infinite] rounded-full border border-dashed border-violet-400/25"/><div className="absolute inset-14 animate-[spin_35s_linear_infinite_reverse] rounded-full border border-cyan-300/20"/>
          <div className="absolute inset-0 grid place-items-center"><div className="grid h-36 w-36 place-items-center rounded-[2rem] border border-white/15 bg-gradient-to-br from-violet-600/80 to-cyan-500/80 shadow-[0_0_100px_rgba(139,92,246,.3)]"><div className="grid h-[calc(100%-8px)] w-[calc(100%-8px)] place-items-center rounded-[1.7rem] bg-[#0d1020]"><Zap size={54} className="text-cyan-300" fill="currentColor"/></div></div></div>
          <div className="glass absolute left-2 top-20 rounded-2xl p-4 shadow-xl"><FileText className="text-violet-300"/><p className="mt-2 text-xs font-semibold">PDF tools</p></div><div className="glass absolute right-0 top-24 rounded-2xl p-4 shadow-xl"><ImageIcon className="text-cyan-300"/><p className="mt-2 text-xs font-semibold">Image tools</p></div><div className="glass absolute bottom-16 left-8 rounded-2xl p-4 shadow-xl"><Code2 className="text-emerald-300"/><p className="mt-2 text-xs font-semibold">Developer</p></div><div className="glass absolute bottom-12 right-5 rounded-2xl p-4 shadow-xl"><Video className="text-rose-300"/><p className="mt-2 text-xs font-semibold">Media tools</p></div>
        </motion.div>
      </section>
      <section id="tools" className="mx-auto max-w-7xl scroll-mt-24 px-5 pb-24 lg:px-8">
        <div className="mb-8 flex flex-wrap items-end justify-between gap-4"><div><p className="mb-2 text-xs font-bold uppercase tracking-[.22em] text-violet-400">The collection</p><h2 className="text-3xl font-bold tracking-tight">Find your tool</h2><p className={`mt-2 text-sm ${light?'text-slate-500':'text-zinc-500'}`}>Handy utilities, gathered in one place.</p></div><span className="text-sm text-zinc-500">{filtered.length} results</span></div>
        <div className="mb-7 flex gap-2 overflow-x-auto pb-2">{categories.map(c=><button key={c.id} onClick={()=>{setCategory(c.id);setShowFavorites(false)}} className={`flex shrink-0 items-center gap-2 rounded-xl border px-4 py-2.5 text-sm font-medium transition ${category===c.id&&!showFavorites?'border-violet-400/40 bg-violet-500/15 text-violet-300':light?'border-slate-200 bg-white text-slate-600':'border-white/10 bg-white/[.03] text-zinc-400 hover:bg-white/[.07]'}`}><c.icon size={15}/>{c.name}</button>)}<button onClick={()=>setShowFavorites(!showFavorites)} className={`flex shrink-0 items-center gap-2 rounded-xl border px-4 py-2.5 text-sm ${showFavorites?'border-rose-400/40 bg-rose-500/10 text-rose-300':'border-white/10 text-zinc-400'}`}><Heart size={15}/> Saved</button></div>
        {filtered.length?<div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">{filtered.map((t,i)=><motion.article key={t.id} initial={{opacity:0,y:12}} whileInView={{opacity:1,y:0}} viewport={{once:true}} transition={{delay:i*.025}} className={`group rounded-2xl border p-5 transition hover:-translate-y-1 hover:border-violet-400/30 ${light?'border-slate-200 bg-white shadow-sm':'border-white/[.08] bg-white/[.025] hover:bg-white/[.045]'}`}><div className="flex items-start justify-between"><div className="grid h-11 w-11 place-items-center rounded-xl bg-violet-500/10 text-violet-300"><t.icon size={21}/></div><div className="flex items-center gap-2"><span className={`rounded-full px-2.5 py-1 text-[10px] font-semibold ${t.status==='Ready'?'bg-emerald-400/10 text-emerald-400':'bg-amber-400/10 text-amber-300'}`}>{t.status}</span><button onClick={()=>toggleFavorite(t.id)} aria-label="Save favorite" className={`rounded-lg p-2 ${favorites.includes(t.id)?'text-rose-400':'text-zinc-600 hover:text-rose-300'}`}><Heart size={16} fill={favorites.includes(t.id)?'currentColor':'none'}/></button></div></div><h3 className="mt-5 font-semibold">{t.name}</h3><p className={`mt-2 min-h-10 text-sm leading-6 ${light?'text-slate-500':'text-zinc-500'}`}>{t.desc}</p><button onClick={()=>t.status==='Ready'?setActiveTool(t):notify('This tool is planned for a future release.')} className="mt-5 flex items-center gap-2 text-sm font-semibold text-violet-300 transition group-hover:gap-3">{t.status==='Ready'?'Open tool':'Coming soon'} <ArrowUpRight size={15}/></button></motion.article>)}</div>:<div className="rounded-2xl border border-white/10 p-12 text-center text-zinc-500">No matching tools. Try another search.</div>}
      </section>
      <section id="why" className="mx-auto max-w-7xl px-5 pb-24 lg:px-8"><div className="relative overflow-hidden rounded-3xl border border-white/10 bg-gradient-to-br from-violet-500/15 via-white/[.025] to-cyan-500/10 p-8 md:p-14"><div className="relative z-10 max-w-2xl"><p className="mb-3 text-xs font-bold uppercase tracking-[.22em] text-violet-300">Why NeXkiT</p><h2 className="text-3xl font-bold tracking-tight md:text-4xl">Useful tools. No unnecessary fuss.</h2><p className="mt-5 leading-7 text-zinc-400">NeXkiT is designed to make everyday digital tasks easier. Ready tools process supported files locally in your browser, while more advanced tools are clearly marked as coming soon.</p><div className="mt-7 flex flex-wrap gap-3 text-sm text-zinc-300"><span className="rounded-xl border border-white/10 bg-black/10 px-4 py-2">Privacy-conscious</span><span className="rounded-xl border border-white/10 bg-black/10 px-4 py-2">Responsive design</span><span className="rounded-xl border border-white/10 bg-black/10 px-4 py-2">No account needed</span></div></div><WandSparkles className="absolute -bottom-12 -right-8 h-64 w-64 text-violet-300/10"/></div></section>
    </main>
    <footer id="footer" className="relative border-t border-white/[.07] px-5 py-8"><div className="mx-auto flex max-w-7xl flex-col items-center justify-between gap-3 text-xs text-zinc-500 sm:flex-row"><p>© {new Date().getFullYear()} NeXkiT. Everything you need. One kit.</p><p>Built to make digital work simpler.</p></div></footer>
    <AnimatePresence>{activeTool&&<ToolWorkspace tool={activeTool} onClose={()=>setActiveTool(null)} notify={notify}/>}</AnimatePresence>
    <AnimatePresence>{toast&&<motion.div initial={{opacity:0,y:15}} animate={{opacity:1,y:0}} exit={{opacity:0,y:10}} className="fixed bottom-5 right-5 z-[100] flex items-center gap-2 rounded-xl border border-violet-400/20 bg-[#17152a] px-4 py-3 text-sm text-white shadow-2xl"><Check size={16} className="text-emerald-400"/>{toast}</motion.div>}</AnimatePresence>
  </div>
}
