# NeXkiT — Advanced Tools

A self-contained Advanced Tools module for NeXkiT: browser-native video and audio
processing, a multi-track timeline editor, the WAGLE Method preparation pipeline
and a TikTok Studio with optional official-API publishing.

Built with React + Vite + Tailwind + Lucide, powered by **NXT Core** (the FFmpeg.wasm
adapter). It is designed to be dropped into the existing NeXkiT React + Vite site
as a separate sub-app, or deployed on its own.

```
Video Tools    Compressor · Converter · FPS Converter · Resizer · Metadata Inspector
Audio Tools    Extract Audio · Audio Converter · Audio Compressor
Video Editor   Multi-track timeline, trim/split, text overlays, fades, MP4 export
TikTok Studio  WAGLE Method preparation + OAuth publishing / draft upload / manual handoff
```

---

## 1. Quick start

```bash
npm install
npm run dev          # http://localhost:5173
npm run build        # production bundle in dist/
npm run preview      # serve the production build
```

Requirements: Node 18+ and a Chromium/Firefox/Safari build from the last couple of
years. Everything runs client-side; no account, no server and no network calls are
needed for the media tools.

`npm install` also stages the FFmpeg core into `public/ffmpeg/` (about 32 MB of
WebAssembly). That folder is generated — it is git-ignored and rebuilt by
`npm run sync:engine`, which `dev` and `build` call automatically.

---

## 2. Feature status

### Complete and working locally

- **Video Compressor** — H.264 MP4, CRF or target bitrate, 480p/720p/1080p/1440p/4K
  presets, speed presets, aspect-preserving scaling, size estimate, before/after
  sizes, download.
- **Video Converter** — any container the bundled FFmpeg can decode → MP4, H.264 /
  HEVC (experimental) / stream copy, CRF control, audio copy or removal, readable
  errors for unsupported files.
- **FPS Converter** — 24/25/30/50/60 fps constant-frame-rate output, explicit
  duplication-vs-interpolation choice, source frame-rate detection, interpolation
  warnings.
- **Video Resizer** — 9:16, 16:9, 1:1, 4:3, 4:5 and custom sizes; crop-to-fill with a
  focal point or fit-with-padding; canvas preview that uses the same maths as the
  encoder.
- **Metadata Inspector** — duration, resolution, aspect, fps, video/audio codecs,
  bitrates, pixel format, colour primaries/transfer/matrix and HDR/Dolby Vision
  signalling, plus the raw FFmpeg report (copyable).
- **Extract Audio / Audio Converter / Audio Compressor** — MP3, M4A (AAC), AAC (ADTS)
  and WAV; bitrate, channel and sample-rate control; quality presets; audio preview;
  size forecasts.
- **Video Editor** — import video/images/audio, 3+ tracks (add your own), drag to move,
  edge-drag to trim, split at playhead, duplicate, delete, per-clip scale/position/
  framing/volume, alpha fades used as crossfades, text overlays (content, size,
  colour, alignment, position, background), canvas preview with real playback, MP4
  export.
- **WAGLE Method** — five-step workflow (source analysis → quality → motion → HDR &
  colour → delivery), automatic passthrough when the source is already MP4-compatible,
  TikTok 9:16 presets at 30/60 fps, optional denoise/sharpen/resize, explicit HDR
  decisions, before/after comparison table, download.
- **TikTok Studio** — video selection from this session's processed files or upload,
  caption/hashtag editor, privacy and interaction settings, explicit publish
  confirmation, manual handoff (download + copy caption + open TikTok Studio).
- Cancellation, progress, success/error surfaces and hand-off buttons between tools
  ("Send to TikTok Studio", "Open in editor").

### Requires external credentials or services

| Feature | What is needed |
| --- | --- |
| TikTok direct publishing | Approved TikTok developer app, `video.publish` scope, deployed backend with client secret |
| TikTok draft upload | Same, with `video.upload` scope |
| Public posting on an unaudited app | TikTok's audit — unaudited clients are restricted to private viewing |

Everything in that table degrades honestly: without configuration the UI says
"manual mode", disables the publish button and offers the manual route. Nothing is
simulated.

### Known limitations

- **Browser encoding is CPU-bound.** Expect roughly real-time or slower for 1080p,
  and several minutes for 4K. The single-threaded core is used deliberately so the
  site works on GitHub Pages (multi-threaded wasm needs COOP/COEP headers that Pages
  cannot send).
- **File size** is limited by browser memory. The UI warns above 250 MB and stops at
  1 GB. Multi-gigabyte footage is a desktop-engine job; the engine adapter is isolated
  in `src/lib/ffmpeg.js` so it can be swapped later.
- **Encoder availability depends on the bundled core build.** H.264 (libx264) is
  reliable. HEVC (libx265) and some audio encoders vary between FFmpeg.wasm builds and
  fail with a readable error rather than silently. MP3/LAME ships with the official
  core; if a future build drops it, the audio converter reports "unknown encoder".
- **HDR is preserved only by container passthrough.** Encoding HDR into 8-bit H.264
  requires tone-mapping; the WAGLE Method warns and requires acknowledgement. See
  §8.
- **Editor export renders in real time** through `MediaRecorder`, then converts WebM
  to MP4 with FFmpeg when the browser cannot record MP4 directly. Chrome usually
  records MP4; Firefox and Safari fall back to WebM → FFmpeg conversion.
- **Editor** has no keyframe effects, masks, speed ramps, colour grading or project
  persistence. Reloading the page clears the project (object URLs are session-scoped
  on purpose — nothing is written to disk or to a server).
- **Duplicated frames are not motion.** Interpolation is available, but it is slow and
  can warp edges. Both options are labelled as what they are.
- **Subtitles, chapters and data streams** are dropped by every re-encode.
- The **TikTok backend** proxies uploads through the Node service (TikTok's upload URL
  is not browser-CORS friendly). Default cap: 200 MB.

---

## 3. Architecture

```
src/
  config.js                brand strings, home URL, limits, backend URL
  lib/
    ffmpeg.js              NXT Core engine: lazy load, serialised job queue, cancel,
                           progress, log capture, probe helper
    mediaInfo.js           FFmpeg report parser (streams, colour, HDR) + size maths
    encode.js              shared FFmpeg argument builders
    presets.js             resolution / quality / fps / TikTok presets, filters
    useTask.js             status + progress + cancel state machine
    results.js             session store so tools can hand files to each other
    tiktok.js              client for the optional publishing backend
  editor/
    model.js               immutable timeline model (tracks, clips, split, trim)
    render.js              canvas compositor (media + text overlay + fades)
    playback.js            media element sync with the playhead
    audio.js               WebAudio graph (preview + export capture)
    exporter.js            MediaRecorder render → MP4 (FFmpeg fallback)
    timelineMath.js        snapping / timecode helpers
  components/              UI kit (glass panels, buttons, dropzone, progress…)
  pages/                   one folder per workspace
  data/tools.js            the catalogue that drives the overview + search
server/                    optional TikTok publishing service (Node/Express)
```

Design decisions worth knowing:

- **One engine, many tools.** `runFFmpeg` serialises jobs against a single wasm
  instance, supports progress, cancellation (by terminating the instance) and log
  capture for real error messages.
- **Local-first.** Core files are served from `<base>/ffmpeg/` on your own origin —
  never a CDN — so they work behind a base path and are cached by the browser.
- **Lazy loading.** `@ffmpeg/*` is imported dynamically; the tools shell stays small.
  The editor is a lazily-loaded route.
- **No backend for media.** Files are read with the File API and processed in a
  Web Worker (FFmpeg.wasm) or on canvas. Only TikTok publishing ever leaves the
  browser, and only when you press publish.

---

## 4. Integrating into the existing NeXkiT site

Three options. **Option A is recommended** if your homepage already lives at
`https://<user>.github.io/nexkit/`.

### Option A — sub-app at `/nexkit/tools/` (recommended)

Build the module with the right base path and drop the output into your site's
`public/` folder, so the main Vite build copies it through untouched.

```bash
# in this project
VITE_BASE_PATH=/nexkit/tools/ \
VITE_NEXKIT_HOME_URL=/nexkit/ \
npm run build

# copy the built app into your existing NeXkiT repository
cp -R dist/* ../your-nexkit-repo/public/tools/
```

Then commit and let your normal GitHub Pages deploy run. The result:

```
https://<user>.github.io/nexkit/             ← your existing homepage (unchanged)
https://<user>.github.io/nexkit/tools/       ← Advanced Tools
https://<user>.github.io/nexkit/tools/ffmpeg/ffmpeg-core.wasm
```

Why `public/tools`: Vite copies `public/**` verbatim into `dist`, and it does not
delete it when the main app rebuilds. You never touch your homepage source.

The tools app uses a **hash router**, so deep links look like
`…/nexkit/tools/#/wagle` and work on GitHub Pages without 404 rewrites. If your site
has a custom `404.html` SPA fallback it is never involved.

Add the navigation entry wherever your homepage lists features:

```jsx
// e.g. src/components/AdvancedToolsButton.jsx in the existing project
export function AdvancedToolsButton() {
  return (
    <a
      href="/nexkit/tools/"
      className="inline-flex items-center gap-2 rounded-xl border border-white/10 bg-white/5 px-4 py-2.5 text-sm"
    >
      Advanced Tools
      <span aria-hidden="true">→</span>
    </a>
  )
}
```

Use a plain `<a>`, not React Router's `<Link>`: it is a separate app, so a full page
navigation is correct. Same for a nav item in your header.

### Option B — separate GitHub Pages site

```bash
VITE_BASE_PATH=/nexkit-tools/ VITE_NEXKIT_HOME_URL=/nexkit/ npm run build
```

Publish `dist/` to its own repository (or a `gh-pages` branch) and link to it from
the homepage with an absolute URL. This keeps repository size and build times apart.

### Option C — copy the source into your app

Possible but more invasive. You would copy `src/` (or the parts you want), add
`react-router-dom` routes, and make sure the pages are rendered inside a router
context (they use `Link`, `useLocation`). The overview at `src/pages/Home.jsx` is the
natural landing route. You would also need to keep `public/ffmpeg/` reachable and set
`VITE_BASE_PATH` to your app's base. Option A avoids all of this.

### Files you actually need to copy (Option A)

Nothing from source: only the built `dist/` output.

```
dist/index.html
dist/nexkit-mark.svg
dist/ffmpeg/ffmpeg-core.js        ~0.1 MB
dist/ffmpeg/ffmpeg-core.wasm      ~32 MB
dist/assets/*.js|*.css            (hashed bundles)
```

### Environment variables

| Variable | Purpose | Example |
| --- | --- | --- |
| `VITE_BASE_PATH` | Deploy base path | `/nexkit/tools/` |
| `VITE_NEXKIT_HOME_URL` | Target of "Back to NeXkiT Home" | `/nexkit/` |
| `VITE_TIKTOK_API_BASE` | Optional publishing backend | `https://nexkit-api.example.com` |
| `VITE_ALLOWED_HOSTS` | Extra hosts for the dev server | `abc.style.dev` |

Copy `.env.example` to `.env.local` for local overrides. Vite only exposes
`VITE_`-prefixed variables to the client — never put a secret in one.

### Hosting notes

- GitHub Pages serves `.wasm` as `application/wasm`; if you use a custom host, make
  sure the MIME type is correct or the engine will refuse to instantiate.
- The 32 MB core is cached by the browser after the first load. GitHub Pages sends
  long cache headers for static assets; no extra configuration needed.
- No COOP/COEP headers are required (single-threaded core), which is why this works
  on Pages at all.

---

## 5. The optional TikTok service

See [`server/README.md`](server/README.md) for the full walkthrough. Short version:

```bash
cd server
cp .env.example .env    # client key + secret + origins
npm install
npm start               # http://localhost:8787
```

Set `VITE_TIKTOK_API_BASE` in the frontend, redeploy the site, then connect the
account from TikTok Studio. Requirements:

- Approved TikTok developer app with `video.publish` and/or `video.upload`
- Public HTTPS redirect URI registered in the app
- `APP_ORIGIN` matching the frontend origin exactly (including `/nexkit/tools` if
  that is where it lives) and listed in `ALLOWED_ORIGINS`
- Persistent storage for `.data/sessions.json` (or a real database in production)

GitHub Pages cannot host this. Deploy it to Render/Railway/Fly/VPS. Without it,
TikTok Studio runs in manual mode.

Security properties implemented: authorisation-code flow with a `state` cookie,
tokens kept server-side only, httpOnly session cookie, origin allow-list, explicit
user confirmation before any publish call, no password collection, no cookie or
session scraping, no browser automation.

---

## 6. WAGLE Method — what it is, and what it claims

WAGLE Method is our own five-step preparation workflow. The public objectives it
follows (1080p delivery, constant frame rate, high bitrate, H.264/AAC) are widely
documented quality guidelines; the implementation here is independent.

1. **Source analysis** — resolution, fps, bitrate, codec, HDR signalling, aspect.
2. **Quality** — automatic **container passthrough** when the streams are already
   MP4-compatible (copy, zero loss), otherwise a capped-CRF H.264 encode with
   optional denoise/sharpen/resize.
3. **Motion** — keep source rate, or 30/60 fps by duplication (honest) or optional
   interpolation (labelled as generated).
4. **HDR & colour** — HDR is preserved only by passthrough; any tone-mapping requires
   an explicit acknowledgement.
5. **Delivery** — 1080×1920 presets, crop/fit, AAC bitrate, estimated size, then a
   before/after comparison and a preview.

It deliberately does **not** claim to:

- stop or defeat TikTok's server-side re-encode (it cannot),
- create real detail by upscaling,
- create real motion by duplicating frames,
- guarantee a particular quality on the platform.

Result screens carry "Processed with WAGLE Method" and "Powered by NXT Core".

---

## 7. Editor: why it is built here instead of importing OpenCut

Checked while building this module:

- `OpenCut-app/OpenCut` (MIT) is the active repository, but its README states it is
  "being rewritten from the ground up" (Rust core, GPUI desktop shell, Editor API and
  plugin architecture still roadmap items). The web app there is not a drop-in editor.
- `OpenCut-app/opencut-classic` (MIT, archived) is the usable classic editor — a
  Next.js/Bun application, not a Vite React module.
- `opencutvideo/Opencut` is a third-party re-upload/fork, freshly created, described as
  alpha. Not a dependency to build on.

Both official repositories are MIT, so reuse would be legally fine with attribution.
Practically, porting a Next.js + Bun app's timeline into this Vite module would mean
importing an entire framework, its state layer and its ffmpeg server bridge — far more
risk than value for the features required here.

Decision: implement a lightweight editor with the same workflow ideas (media bin,
multi-track timeline, trim/split, overlays, real-time preview, export), composed from
Web APIs already used elsewhere in this module. OpenCut is credited in the footer as
the workflow inspiration. No CapCut assets, names or branding are used anywhere.

---

## 8. Privacy and performance

- Files never leave the browser. No analytics, no telemetry, no third-party requests.
- The engine is downloaded once from your own origin and cached.
- Heavy modules are lazy: the FFmpeg core only loads when you start a job, the editor
  only when you open it.
- Progress and cancellation are available for every long job; cancelling terminates the
  wasm instance and releases its memory.
- The UI stays responsive because processing happens in a Web Worker and the editor
  renders on `requestAnimationFrame` with UI updates throttled to ~11 Hz.
- Large-file guards: a warning above 250 MB, a hard stop at 1 GB, and clear failure
  messages when the engine runs out of memory.

---

## 9. Troubleshooting

| Symptom | Fix |
| --- | --- |
| "The media engine files could not be loaded" | Run `npm install` (or `npm run sync:engine`) and confirm `<base>/ffmpeg/ffmpeg-core.wasm` is served |
| Engine loads forever | Check the network panel for a 404 on `ffmpeg-core.wasm`; on a custom host fix the `.wasm` MIME type |
| "Unknown encoder" in an error | The bundled FFmpeg build lacks that encoder — use H.264/AAC or WAV |
| Processing stops on a big file | Memory limit; trim the clip or lower the resolution preset |
| Blank preview in the editor | The browser cannot decode that codec; convert it to H.264 MP4 first |
| Export produces a WebM named `.mp4`? | It cannot: the exporter always converts to MP4 before offering the download |
| TikTok button stays disabled | No account connected, no video selected, empty caption or the confirmation box is unchecked |
| OAuth returns "state_mismatch" | The state cookie expired or the backend URL changed — start the connect flow again |
| Posts are private on TikTok | Expected for unaudited apps; submit the app for audit |
| Blank page after deploying under a folder | `VITE_BASE_PATH` did not match the deploy path; rebuild |
| "Back to NeXkiT Home" goes to the wrong place | Set `VITE_NEXKIT_HOME_URL` (e.g. `/nexkit/`) |

---

## 10. Scripts

| Script | What it does |
| --- | --- |
| `npm run dev` | Stages the engine, starts Vite on `0.0.0.0:5173` |
| `npm run build` | Stages the engine, builds to `dist/` |
| `npm run preview` | Serves the production build |
| `npm run sync:engine` | Copies the FFmpeg core into `public/ffmpeg/` |
| `npm run smoke` | Renders every page once in Node and fails on a render crash |

### Dependencies

Runtime: `react`, `react-dom`, `react-router-dom` (hash routing), `lucide-react`
(icons), `@ffmpeg/ffmpeg` + `@ffmpeg/util` (the NXT Core adapter — loaded lazily).

Build: `vite`, `@vitejs/plugin-react`, `tailwindcss` 3, `postcss`, `autoprefixer`,
and `@ffmpeg/core` (the wasm binary that `npm run sync:engine` copies into
`public/ffmpeg/`).

Nothing else is required: no state library, no UI kit, no FFmpeg server.

---

## 11. Credits

- [FFmpeg.wasm](https://github.com/ffmpegwasm/ffmpeg.wasm) — the browser media engine
- [Lucide](https://lucide.dev) — icon set
- [OpenCut](https://github.com/OpenCut-app/OpenCut) (MIT) — timeline editor workflow
  inspiration
- TikTok Content Posting API — publishing integration, implemented against the public
  documentation

NeXkiT and NXT Core are project names used by this module. No third-party trademarks
are claimed.
