#!/usr/bin/env node
/**
 * Copies the FFmpeg.wasm core into public/ so it is served from our own origin
 * (works with any Vite base path, e.g. /nexkit/tools/, and never hot-links a CDN).
 *
 * Runs on postinstall, dev and build. Missing core is reported but not fatal for
 * installs, because the app degrades with a clear message instead of a crash.
 */
import { cp, mkdir, access, stat } from 'node:fs/promises'
import { dirname, join, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..')
const target = join(root, 'public', 'ffmpeg')

const candidates = [
  'node_modules/@ffmpeg/core/dist/esm',
  'node_modules/@ffmpeg/core/dist/umd',
  'node_modules/@ffmpeg/core',
]

const exists = async (p) => {
  try {
    await access(p)
    return true
  } catch {
    return false
  }
}

const main = async () => {
  const source = candidates.find((dir) => join(root, dir))
  let dir = null
  for (const candidate of candidates) {
    if (await exists(join(root, candidate, 'ffmpeg-core.js'))) {
      dir = join(root, candidate)
      break
    }
  }

  if (!dir) {
    console.warn(
      '[nexkit] @ffmpeg/core not found — run `npm install` before `npm run dev` / `npm run build`.',
    )
    return
  }

  await mkdir(target, { recursive: true })
  const files = ['ffmpeg-core.js', 'ffmpeg-core.wasm']
  for (const file of files) {
    const from = join(dir, file)
    if (!(await exists(from))) {
      console.warn(`[nexkit] missing ${from}`)
      continue
    }
    await cp(from, join(target, file))
  }
  if (await exists(join(dir, 'ffmpeg-core.worker.js'))) {
    await cp(join(dir, 'ffmpeg-core.worker.js'), join(target, 'ffmpeg-core.worker.js'))
  }

  const wasm = await stat(join(target, 'ffmpeg-core.wasm')).catch(() => null)
  const mb = wasm ? (wasm.size / (1024 * 1024)).toFixed(1) : '?'
  console.log(`[nexkit] media engine staged in public/ffmpeg (${mb} MB wasm, served locally)`)
}

main().catch((error) => {
  console.warn('[nexkit] could not stage the media engine:', error.message)
})
