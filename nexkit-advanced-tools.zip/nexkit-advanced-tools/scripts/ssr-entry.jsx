import React from 'react'
import { renderToStaticMarkup } from 'react-dom/server'
import { MemoryRouter } from 'react-router-dom'
import App from '../src/App'
import Home from '../src/pages/Home'
import Compressor from '../src/pages/video/Compressor'
import Converter from '../src/pages/video/Converter'
import FpsConverter from '../src/pages/video/FpsConverter'
import Resizer from '../src/pages/video/Resizer'
import Inspector from '../src/pages/video/Inspector'
import ExtractAudio from '../src/pages/audio/ExtractAudio'
import AudioConverter from '../src/pages/audio/AudioConverter'
import AudioCompressor from '../src/pages/audio/AudioCompressor'
import EditorPage from '../src/pages/editor/EditorPage'
import WagleMethod from '../src/pages/wagle/WagleMethod'
import TikTokStudio from '../src/pages/tiktok/TikTokStudio'

const pages = {
  App,
  Home,
  Compressor,
  Converter,
  FpsConverter,
  Resizer,
  Inspector,
  ExtractAudio,
  AudioConverter,
  AudioCompressor,
  EditorPage,
  WagleMethod,
  TikTokStudio,
}

let failures = 0

for (const [name, Component] of Object.entries(pages)) {
  try {
    const html = renderToStaticMarkup(
      <MemoryRouter initialEntries={['/']}>
        <Component />
      </MemoryRouter>,
    )
    if (html.length < 400) throw new Error(`suspiciously small output (${html.length} bytes)`)
    console.log(`ok   ${name.padEnd(16)} ${String(html.length).padStart(7)} bytes`)
  } catch (error) {
    failures += 1
    console.log(`FAIL ${name.padEnd(16)} ${String(error.message).split('\n')[0]}`)
    if (process.env.SMOKE_VERBOSE) console.log(error)
  }
}

console.log(failures ? `\n${failures} page(s) failed` : '\nAll pages rendered without throwing')
if (failures) process.exitCode = 1
