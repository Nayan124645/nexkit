import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// Bundles the SSR smoke entry into .smoke/ so every page can be rendered once
// in Node. Used by `npm run smoke`; not part of the production build.
export default defineConfig({
  plugins: [react()],
  ssr: { noExternal: true },
  logLevel: 'warn',
  build: {
    ssr: 'scripts/ssr-entry.jsx',
    outDir: '.smoke',
    emptyOutDir: true,
    minify: false,
    target: 'node20',
    sourcemap: false,
  },
})
