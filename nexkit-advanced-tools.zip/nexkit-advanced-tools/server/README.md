# NeXkiT TikTok publishing service (optional)

This is the only part of Advanced Tools that needs a server. It exists because
TikTok's Content Posting API requires a **client secret**, and a client secret
must never ship inside a JavaScript bundle.

If you do not deploy this, TikTok Studio still works in **manual mode**: you can
prepare the video, caption and hashtags, download the file and finish the upload
on TikTok. Nothing is faked either way.

---

## What it does

| Endpoint | Purpose |
| --- | --- |
| `GET /health` | Reports whether credentials are configured |
| `GET /api/tiktok/auth` | Starts OAuth (Login Kit) with a signed `state` |
| `GET /api/tiktok/callback` | Exchanges the code, stores tokens, redirects to the app |
| `GET /api/tiktok/me` | Connected account (display name, username, avatar, counts) |
| `POST /api/tiktok/logout` | Deletes the session and clears the cookie |
| `GET /api/tiktok/creator-info` | Creator info + allowed privacy levels |
| `POST /api/tiktok/publish?mode=direct\|draft` | Initialises the post, uploads chunks, returns `publish_id` |
| `GET /api/tiktok/status?publishId=…` | Polls TikTok for post status |

Security model:

- TikTok tokens live **only** on the server, in a `.data/sessions.json` file with mode `0600`.
- The browser gets an `httpOnly` session cookie (`nxk_tiktok`). No token is ever readable by JavaScript.
- Origin allow-list + `credentials: true` CORS.
- No passwords, cookies or session tokens are read from the user's browser, and no
  browser automation is involved anywhere.

> `.data/sessions.json` is fine for a single-instance deployment. For production,
  replace it with Redis/Postgres and encrypt the tokens at rest.

---

## 1. Create the TikTok app

1. Go to <https://developers.tiktok.com/> → **Manage apps** → create an app.
2. Add the products **Login Kit** and **Content Posting API**.
3. Request the scopes you need:
   - `user.info.basic` — to show which account is connected
   - `video.publish` — direct publishing
   - `video.upload` — upload as a draft to the inbox
4. Register the redirect URI exactly as `TIKTOK_REDIRECT_URI`, e.g.
   `https://your-service.example.com/api/tiktok/callback`.
5. Submit for review. Until your app is **audited**, TikTok restricts posts made
   by unaudited clients to private viewing. That is a platform rule, not a bug here.

## 2. Run it locally

```bash
cd server
cp .env.example .env      # fill in client key/secret
npm install
npm run dev               # http://localhost:8787
```

Point the frontend at it:

```bash
# nexkit-advanced-tools/.env.local
VITE_TIKTOK_API_BASE=http://localhost:8787
```

For local OAuth, TikTok requires an HTTPS redirect URI. The usual workaround is a
tunnel (ngrok, cloudflared) whose public URL is set as `PUBLIC_URL` and registered
in the TikTok app. `APP_ORIGIN` stays `http://localhost:5173`.

On localhost the session cookie is `SameSite=Lax`; on HTTPS it switches to
`SameSite=None; Secure` automatically so it survives the cross-site OAuth return.

## 3. Deploy

Any Node 18+ host works: Render, Railway, Fly.io, a small VPS, Docker.

```bash
npm install --omit=dev
NODE_ENV=production npm start
```

Checklist:

- [ ] `TIKTOK_CLIENT_KEY` / `TIKTOK_CLIENT_SECRET` set as secrets (never in git).
- [ ] `PUBLIC_URL` is the public HTTPS origin of the service.
- [ ] `TIKTOK_REDIRECT_URI` exactly matches the TikTok app configuration.
- [ ] `APP_ORIGIN` is the frontend origin, including the folder path if any.
- [ ] `ALLOWED_ORIGINS` includes the frontend origin(s) and `http://localhost:5173` for dev.
- [ ] Restart after changing env values.
- [ ] `.data/` is on a persistent volume, or replaced by a real database.

GitHub Pages cannot host this service — it serves static files only. Deploy it
separately and set `VITE_TIKTOK_API_BASE` at build time.

## 4. Limits worth knowing

- **Rate limit:** 6 publish/status requests per minute per user token. The UI polls
  status every 10 seconds on purpose.
- **Video limits:** TikTok documents up to 4 GB and 60 fps for API uploads. This
  service caps proxied uploads at `MAX_UPLOAD_MB` (200 MB by default) to protect a
  small server; raise it if your host can take it.
- **Chunking:** files up to 64 MB go as a single chunk; larger files use 5–64 MB
  chunks with `Content-Range`. The last chunk may be smaller.
- **Privacy:** `privacy_level` must come from `creator_info.privacy_level_options`.
  The UI fetches creator info once an account is connected.
- **Failures:** `publish/video/init/` can return
  `unaudited_client_can_only_post_to_private_accounts`,
  `spam_risk_too_many_posts`, `reached_active_user_cap`, or
  `url_ownership_unverified` (only for `PULL_FROM_URL`). The server forwards the
  code and a readable message to the UI.
