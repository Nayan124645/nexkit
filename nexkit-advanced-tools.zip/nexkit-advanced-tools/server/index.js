/**
 * NeXkiT TikTok publishing service.
 *
 * Responsibilities
 *  - OAuth authorisation-code exchange (client secret stays here, never in the browser)
 *  - Token storage + refresh
 *  - Direct Post (video.publish) and Draft Upload (video.upload) via the official API
 *  - Chunked transfer to TikTok's upload URL
 *  - Post status polling
 *
 * The frontend never receives the TikTok access token: it holds an httpOnly
 * session cookie issued by this server.
 */
import crypto from 'node:crypto'
import fs from 'node:fs'
import path from 'node:path'
import express from 'express'
import cookieParser from 'cookie-parser'
import cors from 'cors'
import 'dotenv/config'

const PORT = Number(process.env.PORT || 8787)
const CLIENT_KEY = process.env.TIKTOK_CLIENT_KEY || ''
const CLIENT_SECRET = process.env.TIKTOK_CLIENT_SECRET || ''
const PUBLIC_URL = (process.env.PUBLIC_URL || `http://localhost:${PORT}`).replace(/\/+$/, '')
const APP_ORIGIN = (process.env.APP_ORIGIN || 'http://localhost:5173').replace(/\/+$/, '')
const REDIRECT_URI = process.env.TIKTOK_REDIRECT_URI || `${PUBLIC_URL}/api/tiktok/callback`
const SCOPES = process.env.TIKTOK_SCOPES || 'user.info.basic,video.publish,video.upload'
const MAX_UPLOAD_MB = Number(process.env.MAX_UPLOAD_MB || 200)
const ALLOWED_ORIGINS = (process.env.ALLOWED_ORIGINS || APP_ORIGIN)
  .split(',')
  .map((value) => value.trim().replace(/\/+$/, ''))
  .filter(Boolean)

const API = 'https://open.tiktokapis.com'
const SECURE_CONTEXT = APP_ORIGIN.startsWith('https://')

const app = express()
app.set('trust proxy', 1)

/* ------------------------------------------------------------------ sessions */

const DATA_DIR = path.join(process.cwd(), '.data')
const DATA_FILE = path.join(DATA_DIR, 'sessions.json')
const sessions = new Map()

function loadSessions() {
  try {
    const raw = fs.readFileSync(DATA_FILE, 'utf8')
    const parsed = JSON.parse(raw)
    Object.entries(parsed).forEach(([id, session]) => sessions.set(id, session))
    console.log(`[nexkit] restored ${sessions.size} session(s)`)
  } catch {
    /* first run */
  }
}

let saveTimer = null
function persistSessions() {
  clearTimeout(saveTimer)
  saveTimer = setTimeout(() => {
    try {
      fs.mkdirSync(DATA_DIR, { recursive: true })
      fs.writeFileSync(DATA_FILE, JSON.stringify(Object.fromEntries(sessions)), { mode: 0o600 })
    } catch (error) {
      console.warn('[nexkit] could not persist sessions:', error.message)
    }
  }, 200)
}

const COOKIE_NAME = 'nxk_tiktok'
const cookieOptions = {
  httpOnly: true,
  sameSite: SECURE_CONTEXT ? 'none' : 'lax',
  secure: SECURE_CONTEXT,
  maxAge: 30 * 24 * 60 * 60 * 1000,
  path: '/',
}

function sessionFor(req) {
  const id = req.cookies?.[COOKIE_NAME]
  if (!id) return null
  const session = sessions.get(id)
  if (!session) return null
  return session
}

function requireSession(req, res, next) {
  const session = sessionFor(req)
  if (!session?.tokens?.access_token) {
    res.status(401).json({ ok: false, error: { code: 'not_connected', message: 'No TikTok account is connected.' } })
    return
  }
  req.session = session
  req.sessionId = req.cookies[COOKIE_NAME]
  next()
}

/* ------------------------------------------------------------------- helpers */

async function tiktok(pathname, { method = 'GET', token, body, contentType } = {}) {
  const response = await fetch(`${API}${pathname}`, {
    method,
    headers: {
      Authorization: `Bearer ${token}`,
      ...(contentType ? { 'Content-Type': contentType } : {}),
    },
    body,
  })

  const text = await response.text()
  let payload = null
  try {
    payload = text ? JSON.parse(text) : null
  } catch {
    payload = null
  }

  if (!response.ok) {
    const message = payload?.error?.message || payload?.message || `TikTok answered ${response.status}.`
    const error = new Error(message)
    error.status = response.status
    error.code = payload?.error?.code
    throw error
  }
  return payload
}

function okError(payload) {
  const code = payload?.error?.code
  return code && code !== 'ok' ? { code, message: payload.error.message || code } : null
}

async function refreshIfNeeded(session) {
  const tokens = session.tokens
  if (!tokens) throw new Error('No tokens stored for this session.')
  if (tokens.expires_at && Date.now() < tokens.expires_at - 60_000) return tokens.access_token

  const body = new URLSearchParams({
    client_key: CLIENT_KEY,
    client_secret: CLIENT_SECRET,
    grant_type: 'refresh_token',
    refresh_token: tokens.refresh_token,
  })

  const response = await fetch(`${API}/v2/oauth/token/`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body,
  })
  const payload = await response.json()
  if (!response.ok || payload.error) {
    const error = new Error(payload?.error_description || payload?.error || 'Token refresh failed.')
    error.status = 401
    throw error
  }

  session.tokens = {
    ...tokens,
    access_token: payload.access_token,
    refresh_token: payload.refresh_token || tokens.refresh_token,
    expires_at: Date.now() + Number(payload.expires_in || 86400) * 1000,
    scope: payload.scope || tokens.scope,
  }
  persistSessions()
  return session.tokens.access_token
}

async function fetchAccount(accessToken) {
  const payload = await tiktok(
    '/v2/user/info/?fields=open_id,union_id,avatar_url,display_name,username,follower_count,following_count,likes_count,video_count',
    { token: accessToken },
  )
  const user = payload?.data?.user || {}
  return {
    openId: user.open_id,
    username: user.username,
    displayName: user.display_name,
    avatarUrl: user.avatar_url,
    followerCount: user.follower_count,
    followingCount: user.following_count,
    likesCount: user.likes_count,
    videoCount: user.video_count,
    scopes: undefined,
  }
}

/**
 * TikTok chunk rules:
 *  - whole file in one chunk up to 64 MB
 *  - otherwise 5–64 MB chunks, last chunk may be smaller
 */
function chunkPlan(size) {
  const MIN = 5 * 1024 * 1024
  const MAX = 64 * 1024 * 1024
  if (size <= MAX) return { chunkSize: size, count: 1 }
  const count = Math.ceil(size / MAX)
  const chunkSize = Math.max(MIN, Math.ceil(size / count))
  return { chunkSize, count: Math.ceil(size / chunkSize) }
}

async function uploadChunks(uploadUrl, buffer, chunkSize) {
  const size = buffer.length
  const count = Math.ceil(size / chunkSize)
  for (let index = 0; index < count; index += 1) {
    const start = index * chunkSize
    const end = Math.min(start + chunkSize, size)
    const slice = buffer.subarray(start, end)
    const response = await fetch(uploadUrl, {
      method: 'PUT',
      headers: {
        'Content-Type': 'video/mp4',
        'Content-Length': String(slice.length),
        'Content-Range': `bytes ${start}-${end - 1}/${size}`,
      },
      body: slice,
    })
    if (response.status >= 300) {
      const text = await response.text().catch(() => '')
      throw new Error(`TikTok rejected upload chunk ${index + 1}/${count} (HTTP ${response.status}). ${text.slice(0, 200)}`)
    }
  }
}

/* --------------------------------------------------------------------- routes */

app.use(
  cors({
    origin: (origin, callback) => {
      if (!origin) return callback(null, true)
      if (ALLOWED_ORIGINS.includes(origin)) return callback(null, true)
      return callback(new Error(`Origin ${origin} is not allowed by ALLOWED_ORIGINS.`))
    },
    credentials: true,
  }),
)
app.use(cookieParser())
app.use((req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff')
  res.setHeader('Referrer-Policy', 'no-referrer')
  res.setHeader('Cache-Control', 'no-store')
  next()
})

app.get('/', (req, res) => {
  res.type('text/plain').send(
    'NeXkiT TikTok publishing service.\n\n' +
      `Health: ${PUBLIC_URL}/health\n` +
      `Callback: ${REDIRECT_URI}\n` +
      `Allowed origins: ${ALLOWED_ORIGINS.join(', ')}\n`,
  )
})

app.get('/health', (req, res) => {
  res.json({
    ok: true,
    configured: Boolean(CLIENT_KEY && CLIENT_SECRET),
    redirectUri: REDIRECT_URI,
    scopes: SCOPES.split(','),
  })
})

app.get('/api/tiktok/auth', (req, res) => {
  if (!CLIENT_KEY || !CLIENT_SECRET) {
    res.status(503).json({
      ok: false,
      error: { code: 'missing_credentials', message: 'TIKTOK_CLIENT_KEY / TIKTOK_CLIENT_SECRET are not set.' },
    })
    return
  }
  const state = crypto.randomBytes(16).toString('hex')
  res.cookie('nxk_state', state, { ...cookieOptions, maxAge: 10 * 60 * 1000 })

  const url = new URL('https://www.tiktok.com/v2/auth/authorize/')
  url.searchParams.set('client_key', CLIENT_KEY)
  url.searchParams.set('scope', SCOPES)
  url.searchParams.set('response_type', 'code')
  url.searchParams.set('redirect_uri', REDIRECT_URI)
  url.searchParams.set('state', state)
  res.redirect(url.toString())
})

app.get('/api/tiktok/callback', async (req, res) => {
  const { code, state, error, error_description: errorDescription } = req.query
  const back = (query) => res.redirect(`${APP_ORIGIN}/#/tiktok?${query}`)

  if (error) return back(`error=${encodeURIComponent(errorDescription || error)}`)
  if (!code || !state || state !== req.cookies?.nxk_state) {
    return back('error=state_mismatch')
  }

  try {
    const body = new URLSearchParams({
      client_key: CLIENT_KEY,
      client_secret: CLIENT_SECRET,
      code: String(code),
      grant_type: 'authorization_code',
      redirect_uri: REDIRECT_URI,
    })
    const response = await fetch(`${API}/v2/oauth/token/`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body,
    })
    const payload = await response.json()
    if (!response.ok || payload.error) {
      throw new Error(payload?.error_description || payload?.error || 'Token exchange failed.')
    }

    const account = await fetchAccount(payload.access_token)
    const sessionId = crypto.randomBytes(24).toString('hex')
    sessions.set(sessionId, {
      createdAt: Date.now(),
      account,
      tokens: {
        access_token: payload.access_token,
        refresh_token: payload.refresh_token,
        open_id: payload.open_id,
        scope: payload.scope,
        expires_at: Date.now() + Number(payload.expires_in || 86400) * 1000,
      },
    })
    persistSessions()
    res.cookie(COOKIE_NAME, sessionId, cookieOptions)
    res.clearCookie('nxk_state', { path: '/' })
    return back('connected=1')
  } catch (error) {
    console.error('[nexkit] oauth callback failed:', error.message)
    return back(`error=${encodeURIComponent(error.message)}`)
  }
})

app.get('/api/tiktok/me', requireSession, async (req, res) => {
  try {
    const token = await refreshIfNeeded(req.session)
    const account = await fetchAccount(token)
    req.session.account = account
    persistSessions()
    res.json({ ok: true, account })
  } catch (error) {
    if (error.status === 401) {
      sessions.delete(req.sessionId)
      persistSessions()
      res.clearCookie(COOKIE_NAME, { path: '/' })
      return res.status(401).json({ ok: false, error: { code: 'session_expired', message: error.message } })
    }
    res.status(502).json({ ok: false, error: { code: 'upstream', message: error.message } })
  }
})

app.post('/api/tiktok/logout', (req, res) => {
  const id = req.cookies?.[COOKIE_NAME]
  if (id) {
    sessions.delete(id)
    persistSessions()
  }
  res.clearCookie(COOKIE_NAME, { path: '/' })
  res.json({ ok: true })
})

app.get('/api/tiktok/creator-info', requireSession, async (req, res) => {
  try {
    const token = await refreshIfNeeded(req.session)
    const payload = await tiktok('/v2/post/publish/creator_info/query/', {
      method: 'POST',
      token,
      contentType: 'application/json; charset=UTF-8',
      body: JSON.stringify({}),
    })
    const failure = okError(payload)
    if (failure) throw Object.assign(new Error(failure.message), { code: failure.code })
    res.json({ ok: true, creatorInfo: payload.data })
  } catch (error) {
    res.status(502).json({ ok: false, error: { code: error.code || 'upstream', message: error.message } })
  }
})

app.post('/api/tiktok/publish', requireSession, express.raw({ type: '*/*', limit: `${MAX_UPLOAD_MB}mb` }), async (req, res) => {
  const mode = req.query.mode === 'draft' ? 'draft' : 'direct'
  const buffer = Buffer.isBuffer(req.body) ? req.body : Buffer.alloc(0)

  if (!buffer.length) {
    res.status(400).json({ ok: false, error: { code: 'empty_body', message: 'No video bytes were received.' } })
    return
  }

  let meta = {}
  try {
    meta = JSON.parse(Buffer.from(String(req.headers['x-nxk-meta'] || 'e30='), 'base64').toString('utf8'))
  } catch {
    res.status(400).json({ ok: false, error: { code: 'bad_meta', message: 'Post metadata could not be parsed.' } })
    return
  }

  try {
    const token = await refreshIfNeeded(req.session)
    const { chunkSize, count } = chunkPlan(buffer.length)

    const body = {
      source_info: {
        source: 'FILE_UPLOAD',
        video_size: buffer.length,
        chunk_size: chunkSize,
        total_chunk_count: count,
      },
    }

    if (mode === 'direct') {
      body.post_info = {
        title: String(meta.caption || '').slice(0, 2200),
        privacy_level: meta.privacyLevel || 'SELF_ONLY',
        disable_comment: Boolean(meta.disableComment),
        disable_duet: Boolean(meta.disableDuet),
        disable_stitch: Boolean(meta.disableStitch),
        video_cover_timestamp_ms: 1000,
      }
    } else {
      body.post_info = { title: String(meta.caption || '').slice(0, 2200) }
    }

    const endpoint =
      mode === 'direct' ? '/v2/post/publish/video/init/' : '/v2/post/publish/inbox/video/init/'

    const init = await tiktok(endpoint, {
      method: 'POST',
      token,
      contentType: 'application/json; charset=UTF-8',
      body: JSON.stringify(body),
    })

    const failure = okError(init)
    if (failure) throw Object.assign(new Error(failure.message), { code: failure.code })

    const uploadUrl = init?.data?.upload_url
    const publishId = init?.data?.publish_id
    if (!uploadUrl || !publishId) throw new Error('TikTok did not return an upload URL.')

    await uploadChunks(uploadUrl, buffer, chunkSize)

    res.json({ ok: true, publishId, mode, chunks: count })
  } catch (error) {
    console.error('[nexkit] publish failed:', error.message)
    res.status(502).json({
      ok: false,
      error: {
        code: error.code || 'publish_failed',
        message: error.message,
        hint:
          error.code === 'unaudited_client_can_only_post_to_private_accounts'
            ? 'Until your app is audited, TikTok only allows posting to private accounts.'
            : undefined,
      },
    })
  }
})

app.get('/api/tiktok/status', requireSession, async (req, res) => {
  const publishId = String(req.query.publishId || '')
  if (!publishId) {
    res.status(400).json({ ok: false, error: { code: 'missing_publish_id', message: 'publishId is required.' } })
    return
  }
  try {
    const token = await refreshIfNeeded(req.session)
    const payload = await tiktok('/v2/post/publish/status/fetch/', {
      method: 'POST',
      token,
      contentType: 'application/json; charset=UTF-8',
      body: JSON.stringify({ publish_id: publishId }),
    })
    const failure = okError(payload)
    if (failure) throw Object.assign(new Error(failure.message), { code: failure.code })

    const data = payload.data || {}
    res.json({
      ok: true,
      status: data.status,
      message: data.fail_reason ? `TikTok: ${data.fail_reason}` : undefined,
      postIds: data.publicaly_available_post_id || data.publicly_available_post_id || [],
      uploadBytes: data.uploaded_bytes,
    })
  } catch (error) {
    res.status(502).json({ ok: false, error: { code: error.code || 'upstream', message: error.message } })
  }
})

loadSessions()

app.listen(PORT, () => {
  console.log(`[nexkit] TikTok service on http://localhost:${PORT}`)
  console.log(`[nexkit] allowed origins: ${ALLOWED_ORIGINS.join(', ')}`)
  console.log(`[nexkit] redirect URI: ${REDIRECT_URI}`)
  if (!CLIENT_KEY || !CLIENT_SECRET) {
    console.warn('[nexkit] WARNING: TIKTOK_CLIENT_KEY / TIKTOK_CLIENT_SECRET are not configured.')
  }
})
