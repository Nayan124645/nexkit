import { lazy, Suspense, useEffect, useState } from 'react'
import { Link, NavLink, Route, Routes, useLocation } from 'react-router-dom'
import { ArrowUpRight, Clapperboard, ExternalLink, Menu, Sparkles, WandSparkles, X } from 'lucide-react'
import { config } from './config'
import Home from './pages/Home'
import Compressor from './pages/video/Compressor'
import Converter from './pages/video/Converter'
import FpsConverter from './pages/video/FpsConverter'
import Resizer from './pages/video/Resizer'
import Inspector from './pages/video/Inspector'
import ExtractAudio from './pages/audio/ExtractAudio'
import AudioConverter from './pages/audio/AudioConverter'
import AudioCompressor from './pages/audio/AudioCompressor'
import WagleMethod from './pages/wagle/WagleMethod'
import TikTokStudio from './pages/tiktok/TikTokStudio'
import { Badge, Button, Spinner, cx } from './components/ui'

const EditorPage = lazy(() => import('./pages/editor/EditorPage'))

const NAV = [
  { to: '/', label: 'Overview', end: true },
  { to: '/editor', label: 'Video Editor' },
  { to: '/wagle', label: 'WAGLE Method' },
  { to: '/tiktok', label: 'TikTok Studio' },
]

function ScrollToTop() {
  const { pathname } = useLocation()
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'auto' })
  }, [pathname])
  return null
}

function BrandMark({ size = 34 }) {
  return (
    <span
      className="relative grid shrink-0 place-items-center rounded-xl border border-white/12 bg-ink-850 neu"
      style={{ height: size, width: size }}
    >
      <svg viewBox="0 0 64 64" width={size - 12} height={size - 12} fill="none" aria-hidden="true">
        <defs>
          <linearGradient id="nxlogo" x1="6" y1="6" x2="58" y2="58" gradientUnits="userSpaceOnUse">
            <stop stopColor="#c7d0ff" />
            <stop offset="0.55" stopColor="#818cf8" />
            <stop offset="1" stopColor="#35d6e8" />
          </linearGradient>
        </defs>
        <path
          d="M18 46V18l28 28V18"
          stroke="url(#nxlogo)"
          strokeWidth="5"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
      </svg>
    </span>
  )
}

function Header() {
  const [open, setOpen] = useState(false)
  const location = useLocation()

  useEffect(() => {
    setOpen(false)
  }, [location.pathname])

  const linkClass = ({ isActive }) =>
    cx(
      'relative rounded-lg px-3 py-2 text-[13px] font-medium transition-colors',
      isActive ? 'text-white' : 'text-slate-400 hover:text-slate-100',
    )

  return (
    <header className="sticky top-0 z-40 border-b border-white/[0.06] bg-ink-950/75 backdrop-blur-xl">
      <div className="mx-auto flex h-16 max-w-7xl items-center gap-4 px-4 sm:px-6 lg:px-8">
        <Link to="/" className="flex min-w-0 items-center gap-2.5">
          <BrandMark />
          <span className="min-w-0 leading-none">
            <span className="block text-[15px] font-semibold tracking-tight text-white">NeXkiT</span>
            <span className="mt-1 block text-[10.5px] uppercase tracking-[0.18em] text-slate-500">
              Advanced Tools
            </span>
          </span>
        </Link>

        <nav className="ml-4 hidden items-center gap-1 md:flex" aria-label="Main">
          {NAV.map((item) => (
            <NavLink key={item.to} to={item.to} end={item.end} className={linkClass}>
              {({ isActive }) => (
                <span className="inline-flex items-center gap-1.5">
                  {item.label}
                  {isActive ? (
                    <span className="absolute inset-x-2 -bottom-[1px] h-[2px] rounded-full bg-gradient-to-r from-nxt-400 to-cyanic-400" />
                  ) : null}
                </span>
              )}
            </NavLink>
          ))}
        </nav>

        <div className="ml-auto flex items-center gap-2">
          <span className="hidden items-center gap-1.5 rounded-full border border-white/10 bg-white/[0.04] px-2.5 py-1 text-[10.5px] uppercase tracking-[0.12em] text-slate-400 sm:inline-flex">
            <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 shadow-[0_0_8px_rgba(52,211,153,0.9)]" />
            Powered by {config.engine}
          </span>
          <Button as="a" href={config.homeUrl} variant="secondary" size="sm" className="hidden sm:inline-flex">
            NeXkiT Home
            <ArrowUpRight size={14} />
          </Button>
          <button
            type="button"
            aria-label={open ? 'Close menu' : 'Open menu'}
            onClick={() => setOpen((value) => !value)}
            className="grid h-10 w-10 place-items-center rounded-xl border border-white/10 bg-white/[0.04] text-slate-300 md:hidden"
          >
            {open ? <X size={18} /> : <Menu size={18} />}
          </button>
        </div>
      </div>

      {open ? (
        <div className="border-t border-white/[0.06] bg-ink-950/95 px-4 py-3 md:hidden">
          <nav className="flex flex-col gap-1" aria-label="Mobile">
            {NAV.map((item) => (
              <NavLink
                key={item.to}
                to={item.to}
                end={item.end}
                className={({ isActive }) =>
                  cx(
                    'rounded-lg px-3 py-2.5 text-sm',
                    isActive ? 'bg-white/[0.07] text-white' : 'text-slate-400',
                  )
                }
              >
                {item.label}
              </NavLink>
            ))}
            <a
              href={config.homeUrl}
              className="mt-1 flex items-center justify-between rounded-lg border border-white/10 px-3 py-2.5 text-sm text-slate-200"
            >
              Back to NeXkiT Home
              <ArrowUpRight size={15} />
            </a>
          </nav>
        </div>
      ) : null}
    </header>
  )
}

function Footer() {
  return (
    <footer className="mt-auto border-t border-white/[0.06] bg-ink-950/60">
      <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6 lg:px-8">
        <div className="flex flex-col gap-8 md:flex-row md:items-start md:justify-between">
          <div className="max-w-sm">
            <div className="flex items-center gap-2.5">
              <BrandMark size={30} />
              <span className="text-[14px] font-semibold text-white">NeXkiT Advanced Tools</span>
            </div>
            <p className="mt-3 text-[12.5px] leading-relaxed text-slate-500">
              Professional media preparation that runs on your own machine. Files are processed in the browser and
              never uploaded to a third-party server.
            </p>
          </div>

          <div className="grid grid-cols-2 gap-8 text-[12.5px] sm:grid-cols-3">
            <div>
              <p className="mb-2 text-[10.5px] uppercase tracking-[0.16em] text-slate-500">Tools</p>
              <ul className="space-y-1.5">
                <li><Link to="/video/compressor" className="text-slate-400 hover:text-slate-200">Video Compressor</Link></li>
                <li><Link to="/video/converter" className="text-slate-400 hover:text-slate-200">Video Converter</Link></li>
                <li><Link to="/audio/extract" className="text-slate-400 hover:text-slate-200">Extract Audio</Link></li>
                <li><Link to="/video/inspector" className="text-slate-400 hover:text-slate-200">Inspector</Link></li>
              </ul>
            </div>
            <div>
              <p className="mb-2 text-[10.5px] uppercase tracking-[0.16em] text-slate-500">Workflow</p>
              <ul className="space-y-1.5">
                <li><Link to="/editor" className="inline-flex items-center gap-1.5 text-slate-400 hover:text-slate-200"><Clapperboard size={12} /> Editor</Link></li>
                <li><Link to="/wagle" className="inline-flex items-center gap-1.5 text-slate-400 hover:text-slate-200"><WandSparkles size={12} /> WAGLE Method</Link></li>
                <li><Link to="/tiktok" className="inline-flex items-center gap-1.5 text-slate-400 hover:text-slate-200"><Sparkles size={12} /> TikTok Studio</Link></li>
              </ul>
            </div>
            <div>
              <p className="mb-2 text-[10.5px] uppercase tracking-[0.16em] text-slate-500">Engine</p>
              <ul className="space-y-1.5 text-slate-400">
                <li>Powered by {config.engine}</li>
                <li>H.264 · AAC · MP4</li>
                <li>Browser-side processing</li>
              </ul>
            </div>
          </div>
        </div>

        <div className="mt-9 flex flex-col gap-3 border-t border-white/[0.06] pt-5 text-[11.5px] text-slate-600 sm:flex-row sm:items-center sm:justify-between">
          <p>© {new Date().getFullYear()} NeXkiT. Advanced Tools module.</p>
          <p className="flex flex-wrap items-center gap-x-3 gap-y-1">
            <span>Timeline editor workflow inspired by the open-source OpenCut project (MIT).</span>
            <a
              href="https://github.com/OpenCut-app/OpenCut"
              target="_blank"
              rel="noreferrer noopener"
              className="inline-flex items-center gap-1 hover:text-slate-400"
            >
              <ExternalLink size={12} /> OpenCut
            </a>
          </p>
        </div>
      </div>
    </footer>
  )
}

function NotFound() {
  return (
    <div className="mx-auto flex max-w-3xl flex-col items-center px-6 py-24 text-center">
      <Badge tone="nxt">404</Badge>
      <h1 className="mt-4 text-2xl font-semibold text-white">This tool does not exist</h1>
      <p className="mt-2 text-sm text-slate-400">
        The page you followed is not part of Advanced Tools. Everything available is listed on the overview.
      </p>
      <Button as={Link} to="/" className="mt-6">
        Back to Advanced Tools
      </Button>
    </div>
  )
}

function Loading() {
  return (
    <div className="flex min-h-[50vh] items-center justify-center gap-3 text-sm text-slate-400">
      <Spinner /> Loading workspace…
    </div>
  )
}

export default function App() {
  return (
    <div className="flex min-h-dvh flex-col">
      <a
        href="#main"
        className="sr-only focus:not-sr-only focus:absolute focus:left-4 focus:top-4 focus:z-50 focus:rounded-lg focus:bg-ink-800 focus:px-4 focus:py-2 focus:text-sm focus:text-white"
      >
        Skip to content
      </a>
      <ScrollToTop />
      <Header />
      <main id="main" className="flex-1">
        <Suspense fallback={<Loading />}>
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/video/compressor" element={<Compressor />} />
            <Route path="/video/converter" element={<Converter />} />
            <Route path="/video/fps" element={<FpsConverter />} />
            <Route path="/video/resizer" element={<Resizer />} />
            <Route path="/video/inspector" element={<Inspector />} />
            <Route path="/audio/extract" element={<ExtractAudio />} />
            <Route path="/audio/convert" element={<AudioConverter />} />
            <Route path="/audio/compress" element={<AudioCompressor />} />
            <Route path="/editor" element={<EditorPage />} />
            <Route path="/wagle" element={<WagleMethod />} />
            <Route path="/tiktok" element={<TikTokStudio />} />
            <Route path="*" element={<NotFound />} />
          </Routes>
        </Suspense>
      </main>
      <Footer />
    </div>
  )
}
