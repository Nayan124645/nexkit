import { HardDrive, ShieldCheck, Timer } from 'lucide-react'
import { Notice } from './ui'
import { config } from '../config'
import { formatBytes } from '../lib/format'

export function FileLimitNotice({ file, className = '' }) {
  if (!file) return null
  const mb = file.size / (1024 * 1024)
  if (mb <= config.limits.warnFileMB) return null
  const overHardLimit = mb > config.limits.maxFileMB

  return (
    <Notice
      tone={overHardLimit ? 'danger' : 'warning'}
      title={overHardLimit ? 'This file is too large for browser processing' : 'Large file — read this first'}
      icon={HardDrive}
      className={className}
    >
      {overHardLimit ? (
        <>
          {formatBytes(file.size)} exceeds the {config.limits.maxFileMB} MB limit of the local engine. Trim the clip
          first, or process it on a desktop build of NXT Core.
        </>
      ) : (
        <>
          {formatBytes(file.size)} is above the comfortable range ({config.limits.recommendedFileMB} MB). The engine
          copies the file into memory, so a laptop with 8 GB RAM may struggle. Close other tabs and keep this one open
          while it works.
        </>
      )}
    </Notice>
  )
}

export function PrivacyNote({ className = '' }) {
  return (
    <div className={`rounded-xl border border-emerald-400/15 bg-emerald-500/[0.05] p-3.5 ${className}`}>
      <p className="flex items-center gap-2 text-[12px] font-medium text-emerald-200">
        <ShieldCheck size={14} /> Local processing
      </p>
      <p className="mt-1.5 text-[11.5px] leading-relaxed text-slate-400">
        Your file is decoded and re-encoded inside this browser tab. Nothing is uploaded to NeXkiT or any third party.
      </p>
    </div>
  )
}

export function SpeedNote({ className = '' }) {
  return (
    <div className={`flex gap-2.5 rounded-xl border border-white/[0.07] bg-white/[0.022] p-3.5 ${className}`}>
      <Timer size={14} className="mt-0.5 shrink-0 text-slate-500" />
      <p className="text-[11.5px] leading-relaxed text-slate-400">
        Browser encoding is CPU-bound: expect roughly real-time or slower for 1080p, and several minutes for 4K. Keep
        the tab in the foreground so the browser does not throttle it.
      </p>
    </div>
  )
}

export function EngineStatusPill({ ready, loading }) {
  return (
    <span className="inline-flex items-center gap-1.5 rounded-full border border-white/10 bg-white/[0.04] px-2.5 py-1 font-mono text-[10.5px] text-slate-400">
      <span
        className={`h-1.5 w-1.5 rounded-full ${
          ready ? 'bg-emerald-400' : loading ? 'animate-pulseSoft bg-amber-400' : 'bg-slate-500'
        }`}
      />
      {ready ? 'engine ready' : loading ? 'engine loading' : 'engine idle'}
    </span>
  )
}
