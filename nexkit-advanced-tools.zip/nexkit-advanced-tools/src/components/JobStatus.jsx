import { AlertTriangle, ChevronDown, LoaderCircle, X } from 'lucide-react'
import { Button, Notice, Progress } from './ui'

/**
 * One shared progress / cancel / error surface for every processing tool.
 */
export function JobStatus({ task, onCancel, runningLabel = 'Processing…', tone = 'nxt' }) {
  const { status, progress, phase, error, logs } = task

  if (status === 'idle') return null

  if (status === 'running') {
    return (
      <div className="space-y-3 rounded-xl border border-white/10 bg-white/[0.03] p-4">
        <Progress
          value={progress}
          tone={tone}
          indeterminate={progress < 0.015}
          label={phase || runningLabel}
        />
        <div className="flex items-center justify-between gap-3">
          <p className="flex items-center gap-1.5 text-[11.5px] text-slate-500">
            <LoaderCircle size={12} className="animate-spin" />
            Encoding locally — keep this tab open.
          </p>
          <Button variant="danger" size="sm" icon={X} onClick={onCancel || task.cancel}>
            Cancel
          </Button>
        </div>
      </div>
    )
  }

  if (status === 'cancelled') {
    return (
      <Notice tone="warning" title="Processing cancelled">
        The engine was stopped and its memory released. Your source file is untouched — you can start again with
        different settings.
      </Notice>
    )
  }

  if (status === 'error') {
    return (
      <Notice tone="danger" title="Processing failed" icon={AlertTriangle}>
        <p className="whitespace-pre-wrap break-words font-mono text-[11.5px] text-rose-100/90">{error}</p>
        {logs ? (
          <details className="mt-2 group">
            <summary className="flex cursor-pointer items-center gap-1 text-[11px] text-rose-200/80 hover:text-rose-100">
              <ChevronDown size={12} className="transition group-open:rotate-180" />
              Engine log
            </summary>
            <pre className="mt-2 max-h-40 overflow-auto rounded-lg bg-black/50 p-2.5 text-[10.5px] leading-relaxed text-slate-400">
              {logs}
            </pre>
          </details>
        ) : null}
        <p className="mt-2 text-[11.5px] text-slate-400">
          Large or unusual files can exceed the browser engine. Try a shorter clip, a smaller resolution preset, or a
          different source format.
        </p>
      </Notice>
    )
  }

  return null
}
