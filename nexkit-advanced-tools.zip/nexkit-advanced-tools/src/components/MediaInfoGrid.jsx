import { Badge, Stat } from './ui'
import { formatBitrate, formatDuration, prettyCodec } from '../lib/format'

export function MediaInfoGrid({ info, compact = false }) {
  if (!info) return null
  const video = info.video
  const audio = info.audio

  return (
    <div className="space-y-3">
      <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
        <Stat label="Duration" value={formatDuration(info.duration)} />
        <Stat label="Resolution" value={video?.width ? `${video.width} × ${video.height}` : '—'} />
        <Stat label="Aspect" value={video?.aspect || '—'} />
        <Stat label="Frame rate" value={video?.fps ? `${video.fps.toFixed(2)} fps` : '—'} />
        <Stat label="Video codec" value={prettyCodec(video?.codec)} />
        <Stat label="Video bitrate" value={formatBitrate(video?.bitrate)} />
        <Stat label="Audio codec" value={audio ? prettyCodec(audio.codec) : 'None'} />
        <Stat label="Audio" value={audio ? `${audio.channels || '—'} · ${audio.sampleRate ? `${audio.sampleRate / 1000} kHz` : '—'}` : '—'} />
        <Stat label="Audio bitrate" value={audio ? formatBitrate(audio.bitrate) : '—'} />
        {!compact ? (
          <>
            <Stat label="Pixel format" value={video?.pixFmt || '—'} />
            <Stat label="Colour" value={video?.colorPrimaries ? `${video.colorPrimaries} / ${video.colorTransfer}` : 'Not signalled'} />
            <Stat label="Overall bitrate" value={formatBitrate(info.overallBitrate)} />
          </>
        ) : null}
      </div>

      <div className="flex flex-wrap items-center gap-2">
        {video?.isHDR ? (
          <Badge tone="wagle">HDR · {video.hdr}</Badge>
        ) : (
          <Badge tone="slate">SDR</Badge>
        )}
        {video?.profile ? <Badge tone="slate">Profile {video.profile}</Badge> : null}
        {info.container ? <Badge tone="slate">{info.container.split(',')[0]}</Badge> : null}
      </div>

      {info.warnings?.length ? (
        <ul className="space-y-1 text-[11.5px] leading-relaxed text-amber-300/90">
          {info.warnings.map((warning) => (
            <li key={warning}>• {warning}</li>
          ))}
        </ul>
      ) : null}
    </div>
  )
}

export function HdrBadge({ info }) {
  if (!info?.video) return null
  return info.video.isHDR ? (
    <Badge tone="wagle">HDR source</Badge>
  ) : (
    <Badge tone="slate">SDR source</Badge>
  )
}
