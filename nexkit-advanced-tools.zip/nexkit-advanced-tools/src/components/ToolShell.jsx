import { Link } from 'react-router-dom'
import { ArrowLeft, ChevronRight, Download, RotateCcw, Share2, Sparkles } from 'lucide-react'
import { Badge, Button, IconBadge, Notice, cx } from './ui'
import { formatBytes } from '../lib/format'
import { downloadBlob } from '../lib/files'
import { addResult } from '../lib/results'

export function ToolShell({ eyebrow, title, description, icon, tone = 'nxt', badges = [], children, wide = false }) {
  return (
    <div className={cx('mx-auto w-full px-4 pb-20 pt-6 sm:px-6 lg:px-8', wide ? 'max-w-[1600px]' : 'max-w-6xl')}>
      <nav aria-label="Breadcrumb" className="mb-5 flex items-center gap-1.5 text-[12px] text-slate-500">
        <Link to="/" className="inline-flex items-center gap-1.5 transition hover:text-slate-200">
          <ArrowLeft size={13} />
          Advanced Tools
        </Link>
        <ChevronRight size={12} className="opacity-50" />
        <span className="text-slate-400">{eyebrow}</span>
      </nav>

      <header className="mb-7 flex flex-col gap-4 sm:flex-row sm:items-start">
        <IconBadge icon={icon} tone={tone} size="lg" />
        <div className="min-w-0">
          <div className="flex flex-wrap items-center gap-2">
            <h1 className="text-[clamp(1.6rem,3.4vw,2.3rem)] font-semibold leading-tight tracking-tightest text-white">
              {title}
            </h1>
            {badges.map((badge) => (
              <Badge key={badge.label} tone={badge.tone || 'slate'}>
                {badge.label}
              </Badge>
            ))}
          </div>
          <p className="mt-2 max-w-2xl text-[13.5px] leading-relaxed text-slate-400">{description}</p>
        </div>
      </header>

      {children}
    </div>
  )
}

export function ToolGrid({ main, side }) {
  return (
    <div className="grid gap-5 lg:grid-cols-[minmax(0,1.35fr)_minmax(0,1fr)]">
      <div className="space-y-5">{main}</div>
      <div className="space-y-5">{side}</div>
    </div>
  )
}

/**
 * Shared result surface: success state, before/after size, preview, download,
 * plus real hand-off buttons into TikTok Studio and the editor.
 */
export function OutputCard({ result, originalSize, previewKind = 'video', onReset, handoff = true, note }) {
  if (!result) return null

  const saved = originalSize ? originalSize - result.size : null
  const savedPercent = originalSize && originalSize > 0 ? saved / originalSize : null

  const sendTo = (target) => {
    addResult({
      blob: result.blob,
      name: result.name,
      kind: previewKind,
      meta: result.meta,
      source: target,
    })
  }

  return (
    <div className="animate-rise space-y-4">
      <Notice tone="success" title="Processing complete">
        {note || 'Your file was processed locally in this browser and is ready to download.'}
      </Notice>

      <div className="overflow-hidden rounded-xl border border-white/10 bg-black/50">
        {previewKind === 'video' ? (
          <video
            key={result.url}
            src={result.url}
            controls
            playsInline
            className="max-h-[320px] w-full bg-black object-contain"
          />
        ) : previewKind === 'audio' ? (
          <div className="px-4 py-5">
            <audio key={result.url} src={result.url} controls className="w-full" />
          </div>
        ) : previewKind === 'image' ? (
          <img src={result.url} alt="Processed result" className="max-h-[320px] w-full object-contain" />
        ) : null}
      </div>

      <div className="rounded-xl border border-white/[0.07] bg-white/[0.025] p-3.5">
        <div className="flex items-center justify-between gap-3 text-[12.5px]">
          <span className="truncate font-mono text-slate-300">{result.name}</span>
          <span className="shrink-0 font-mono text-slate-100">{formatBytes(result.size)}</span>
        </div>

        {originalSize ? (
          <>
            <div className="mt-3 h-1.5 overflow-hidden rounded-full bg-white/10">
              <div
                className="h-full rounded-full bg-gradient-to-r from-nxt-500 to-cyanic-400"
                style={{ width: `${Math.max(3, Math.min(100, (result.size / originalSize) * 100))}%` }}
              />
            </div>
            <div className="mt-2 flex flex-wrap items-center justify-between gap-2 text-[11.5px] text-slate-400">
              <span>
                Original <span className="font-mono text-slate-300">{formatBytes(originalSize)}</span>
                {' → '}
                Output <span className="font-mono text-slate-300">{formatBytes(result.size)}</span>
              </span>
              {saved !== null ? (
                <span className={saved > 0 ? 'text-emerald-300' : 'text-amber-300'}>
                  {saved > 0
                    ? `${formatBytes(saved)} smaller (${Math.round(savedPercent * 100)}%)`
                    : `${formatBytes(Math.abs(saved))} larger`}
                </span>
              ) : null}
            </div>
          </>
        ) : null}

        {result.meta?.length ? (
          <div className="mt-3 grid grid-cols-2 gap-x-3 gap-y-1.5 border-t border-white/[0.07] pt-3 text-[11.5px]">
            {result.meta.map((entry) => (
              <div key={entry.label} className="flex items-baseline justify-between gap-2">
                <span className="text-slate-500">{entry.label}</span>
                <span className="truncate font-mono text-slate-300">{entry.value}</span>
              </div>
            ))}
          </div>
        ) : null}
      </div>

      <div className="flex flex-wrap gap-2">
        <Button icon={Download} onClick={() => downloadBlob(result.blob, result.name)}>
          Download file
        </Button>
        {handoff ? (
          <>
            <Button as={Link} to="/tiktok" variant="secondary" icon={Share2} onClick={() => sendTo('tiktok')}>
              Send to TikTok Studio
            </Button>
            <Button as={Link} to="/editor" variant="secondary" icon={Sparkles} onClick={() => sendTo('editor')}>
              Open in editor
            </Button>
          </>
        ) : null}
        {onReset ? (
          <Button variant="ghost" icon={RotateCcw} onClick={onReset}>
            Process another
          </Button>
        ) : null}
      </div>
    </div>
  )
}

export function SideNote({ title = 'How this runs', children }) {
  return (
    <div className="rounded-xl border border-white/[0.07] bg-white/[0.022] p-4">
      <p className="text-[11px] uppercase tracking-[0.16em] text-slate-500">{title}</p>
      <div className="mt-2 space-y-2 text-[12px] leading-relaxed text-slate-400">{children}</div>
    </div>
  )
}
