import { useId, useRef, useState } from 'react'
import {
  AlertTriangle,
  Check,
  ChevronDown,
  Info,
  LoaderCircle,
  UploadCloud,
  X,
} from 'lucide-react'

export function cx(...parts) {
  return parts.filter(Boolean).join(' ')
}

/* ------------------------------------------------------------------ Button */

const BUTTON_VARIANTS = {
  primary:
    'text-white bg-gradient-to-br from-nxt-500 via-nxt-500 to-cyanic-500 shadow-[0_10px_30px_-12px_rgba(79,70,229,0.9)] hover:brightness-110 active:brightness-95 border border-white/10',
  secondary:
    'text-slate-100 bg-white/[0.06] border border-white/10 hover:bg-white/[0.1] hover:border-white/20',
  ghost: 'text-slate-300 hover:text-white hover:bg-white/[0.06] border border-transparent',
  outline: 'text-slate-200 border border-white/15 hover:bg-white/[0.06]',
  wagle:
    'text-[#22160a] font-semibold bg-gradient-to-br from-wagle-300 via-wagle-400 to-[#ff8a3d] shadow-[0_12px_34px_-14px_rgba(245,158,11,0.9)] border border-white/20 hover:brightness-105',
  danger: 'text-rose-100 bg-rose-500/15 border border-rose-400/30 hover:bg-rose-500/25',
}

const BUTTON_SIZES = {
  sm: 'h-9 px-3 text-[13px] gap-1.5 rounded-xl',
  md: 'h-11 px-4 text-sm gap-2 rounded-xl',
  lg: 'h-12 px-5 text-[15px] gap-2 rounded-2xl',
}

export function Button({
  as: Tag = 'button',
  variant = 'primary',
  size = 'md',
  icon: Icon,
  iconRight: IconRight,
  className = '',
  children,
  loading = false,
  disabled,
  ...rest
}) {
  return (
    <Tag
      className={cx(
        'inline-flex select-none items-center justify-center font-medium tracking-[-0.01em]',
        'transition-all duration-200 ease-smooth',
        'disabled:pointer-events-none disabled:opacity-45',
        BUTTON_VARIANTS[variant],
        BUTTON_SIZES[size],
        className,
      )}
      disabled={Tag === 'button' ? disabled || loading : undefined}
      aria-busy={loading || undefined}
      {...rest}
    >
      {loading ? (
        <LoaderCircle size={16} className="shrink-0 animate-spin" />
      ) : Icon ? (
        <Icon size={size === 'sm' ? 15 : 17} className="shrink-0" strokeWidth={2} />
      ) : null}
      {children}
      {IconRight ? <IconRight size={15} className="shrink-0 opacity-80" /> : null}
    </Tag>
  )
}

export function IconButton({ label, icon: Icon, className = '', ...rest }) {
  return (
    <button
      type="button"
      aria-label={label}
      title={label}
      className={cx(
        'inline-flex h-9 w-9 items-center justify-center rounded-xl border border-white/10 bg-white/[0.04] text-slate-300',
        'transition hover:bg-white/[0.09] hover:text-white disabled:opacity-40 disabled:pointer-events-none',
        className,
      )}
      {...rest}
    >
      <Icon size={16} />
    </button>
  )
}

/* ------------------------------------------------------------------- Panel */

export function Panel({ className = '', children, ...rest }) {
  return (
    <div className={cx('glass rounded-2xl', className)} {...rest}>
      {children}
    </div>
  )
}

export function PanelHeader({ title, subtitle, icon: Icon, action, className = '' }) {
  return (
    <div className={cx('flex items-start justify-between gap-4', className)}>
      <div className="flex items-start gap-3">
        {Icon ? (
          <span className="mt-0.5 grid h-9 w-9 shrink-0 place-items-center rounded-xl border border-white/10 bg-white/[0.05] text-nxt-300 neu">
            <Icon size={17} />
          </span>
        ) : null}
        <div>
          <h3 className="text-[15px] font-semibold text-slate-100">{title}</h3>
          {subtitle ? <p className="mt-0.5 text-[12.5px] leading-relaxed text-slate-400">{subtitle}</p> : null}
        </div>
      </div>
      {action}
    </div>
  )
}

export function IconBadge({ icon: Icon, tone = 'nxt', size = 'md', className = '' }) {
  const tones = {
    nxt: 'from-nxt-500/25 to-cyanic-500/15 text-nxt-200 ring-nxt-400/25',
    wagle: 'from-wagle-400/25 to-orange-500/10 text-wagle-300 ring-wagle-400/25',
    cyan: 'from-cyanic-400/25 to-sky-500/10 text-cyanic-300 ring-cyanic-400/25',
    slate: 'from-white/10 to-white/5 text-slate-300 ring-white/15',
    rose: 'from-rose-500/25 to-orange-500/10 text-rose-200 ring-rose-400/25',
  }
  const sizes = { sm: 'h-9 w-9 rounded-xl', md: 'h-11 w-11 rounded-2xl', lg: 'h-14 w-14 rounded-2xl' }
  const iconSize = { sm: 16, md: 19, lg: 24 }
  return (
    <span
      className={cx(
        'grid place-items-center bg-gradient-to-br ring-1 neu',
        tones[tone] || tones.nxt,
        sizes[size],
        className,
      )}
    >
      <Icon size={iconSize[size]} strokeWidth={1.8} />
    </span>
  )
}

export function Badge({ children, tone = 'slate', className = '' }) {
  const tones = {
    slate: 'border-white/10 bg-white/[0.05] text-slate-300',
    nxt: 'border-nxt-400/30 bg-nxt-500/12 text-nxt-200',
    cyan: 'border-cyanic-400/30 bg-cyanic-400/10 text-cyanic-300',
    wagle: 'border-wagle-400/30 bg-wagle-400/10 text-wagle-300',
    success: 'border-emerald-400/30 bg-emerald-500/10 text-emerald-300',
    warning: 'border-amber-400/30 bg-amber-500/10 text-amber-300',
    danger: 'border-rose-400/30 bg-rose-500/10 text-rose-300',
  }
  return (
    <span
      className={cx(
        'inline-flex items-center gap-1 rounded-full border px-2.5 py-0.5 text-[11px] font-medium tracking-wide',
        tones[tone] || tones.slate,
        className,
      )}
    >
      {children}
    </span>
  )
}

/* ------------------------------------------------------------------ Inputs */

export function Label({ children, htmlFor, hint, className = '' }) {
  return (
    <label
      htmlFor={htmlFor}
      className={cx('flex items-baseline justify-between gap-3 text-[12.5px] font-medium text-slate-300', className)}
    >
      <span>{children}</span>
      {hint ? <span className="text-[11.5px] font-normal text-slate-500">{hint}</span> : null}
    </label>
  )
}

export function Field({ label, hint, children, className = '', htmlFor }) {
  return (
    <div className={cx('space-y-2', className)}>
      {label ? (
        <Label htmlFor={htmlFor} hint={hint}>
          {label}
        </Label>
      ) : null}
      {children}
    </div>
  )
}

const CONTROL =
  'w-full rounded-xl border border-white/10 bg-ink-900/70 px-3 py-2.5 text-sm text-slate-100 placeholder:text-slate-500 ' +
  'shadow-[inset_0_1px_2px_rgba(0,0,0,0.5)] transition hover:border-white/20 focus:border-nxt-400/60 focus:outline-none ' +
  'focus:ring-2 focus:ring-nxt-500/25 disabled:opacity-50'

export function Input({ className = '', ...rest }) {
  return <input className={cx(CONTROL, className)} {...rest} />
}

export function Textarea({ className = '', ...rest }) {
  return <textarea className={cx(CONTROL, 'resize-y leading-relaxed', className)} {...rest} />
}

export function Select({ options = [], value, onChange, className = '', id, ...rest }) {
  return (
    <div className="relative">
      <select
        id={id}
        value={value}
        onChange={onChange}
        className={cx(CONTROL, 'appearance-none pr-9 cursor-pointer', className)}
        {...rest}
      >
        {options.map((option) => (
          <option key={option.value ?? option.id} value={option.value ?? option.id} className="bg-ink-900">
            {option.label}
          </option>
        ))}
      </select>
      <ChevronDown
        size={15}
        className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-slate-400"
      />
    </div>
  )
}

export function Slider({
  value,
  onChange,
  min = 0,
  max = 100,
  step = 1,
  label,
  display,
  hint,
  disabled,
  id: providedId,
}) {
  const generated = useId()
  const id = providedId || generated
  return (
    <div className="space-y-2">
      {label ? (
        <div className="flex items-baseline justify-between gap-3">
          <label htmlFor={id} className="text-[12.5px] font-medium text-slate-300">
            {label}
          </label>
          <span className="font-mono text-[12px] text-slate-200">{display ?? value}</span>
        </div>
      ) : null}
      <input
        id={id}
        type="range"
        className="range"
        min={min}
        max={max}
        step={step}
        value={value}
        disabled={disabled}
        onChange={(event) => onChange(Number(event.target.value))}
      />
      {hint ? <p className="text-[11.5px] leading-relaxed text-slate-500">{hint}</p> : null}
    </div>
  )
}

export function Toggle({ checked, onChange, label, hint, disabled }) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      disabled={disabled}
      onClick={() => onChange(!checked)}
      className={cx(
        'group flex w-full items-center justify-between gap-4 rounded-xl border border-white/10 bg-white/[0.03] px-3.5 py-3 text-left transition',
        'hover:border-white/20 hover:bg-white/[0.055] disabled:opacity-45',
      )}
    >
      <span className="min-w-0">
        <span className="block text-[13px] font-medium text-slate-200">{label}</span>
        {hint ? <span className="mt-0.5 block text-[11.5px] leading-relaxed text-slate-500">{hint}</span> : null}
      </span>
      <span
        className={cx(
          'relative h-6 w-11 shrink-0 rounded-full border transition-colors duration-200',
          checked ? 'border-nxt-400/50 bg-gradient-to-r from-nxt-500 to-cyanic-500' : 'border-white/15 bg-white/10',
        )}
      >
        <span
          className={cx(
            'absolute top-0.5 h-4.5 w-4.5 rounded-full bg-white shadow transition-transform duration-200 ease-smooth',
            checked ? 'translate-x-[22px]' : 'translate-x-[3px]',
          )}
          style={{ height: 18, width: 18 }}
        />
      </span>
    </button>
  )
}

export function Segmented({ options = [], value, onChange, className = '', size = 'md' }) {
  return (
    <div
      className={cx(
        'inline-flex w-full flex-wrap gap-1 rounded-xl border border-white/10 bg-ink-900/60 p-1 neu-inset',
        className,
      )}
      role="tablist"
    >
      {options.map((option) => {
        const active = (option.value ?? option.id) === value
        return (
          <button
            key={option.value ?? option.id}
            type="button"
            role="tab"
            aria-selected={active}
            onClick={() => onChange(option.value ?? option.id)}
            className={cx(
              'flex-1 whitespace-nowrap rounded-lg px-2.5 text-center font-medium transition-all duration-200',
              size === 'sm' ? 'py-1.5 text-[12px]' : 'py-2 text-[12.5px]',
              active
                ? 'bg-gradient-to-br from-white/[0.14] to-white/[0.06] text-white shadow-[0_2px_10px_rgba(0,0,0,0.45)]'
                : 'text-slate-400 hover:text-slate-200',
            )}
          >
            {option.label}
          </button>
        )
      })}
    </div>
  )
}

export function Checkbox({ checked, onChange, label, hint }) {
  return (
    <label className="flex cursor-pointer items-start gap-3 rounded-xl border border-white/10 bg-white/[0.03] px-3.5 py-3 transition hover:border-white/20">
      <span
        className={cx(
          'mt-0.5 grid h-5 w-5 shrink-0 place-items-center rounded-md border transition',
          checked ? 'border-nxt-400/60 bg-nxt-500 text-white' : 'border-white/20 bg-white/5 text-transparent',
        )}
      >
        <Check size={13} strokeWidth={3} />
      </span>
      <input
        type="checkbox"
        className="sr-only"
        checked={checked}
        onChange={(event) => onChange(event.target.checked)}
      />
      <span className="min-w-0">
        <span className="block text-[13px] font-medium text-slate-200">{label}</span>
        {hint ? <span className="mt-0.5 block text-[11.5px] leading-relaxed text-slate-500">{hint}</span> : null}
      </span>
    </label>
  )
}

/* ---------------------------------------------------------------- Feedback */

export function Progress({ value = 0, label, indeterminate = false, tone = 'nxt', className = '' }) {
  const pct = Math.round(Math.min(1, Math.max(0, value)) * 100)
  const tones = {
    nxt: 'from-nxt-500 via-nxt-400 to-cyanic-400',
    wagle: 'from-wagle-400 via-amber-400 to-orange-500',
    success: 'from-emerald-500 to-teal-400',
  }
  return (
    <div className={cx('space-y-2', className)}>
      <div className="flex items-center justify-between text-[11.5px]">
        <span className="text-slate-400">{label || 'Progress'}</span>
        <span className="font-mono text-slate-300">{indeterminate ? 'working…' : `${pct}%`}</span>
      </div>
      <div
        className="relative h-2 overflow-hidden rounded-full border border-white/10 bg-ink-950/80 neu-inset"
        role="progressbar"
        aria-valuenow={indeterminate ? undefined : pct}
        aria-valuemin={0}
        aria-valuemax={100}
      >
        <div
          className={cx(
            'h-full rounded-full bg-gradient-to-r transition-[width] duration-500 ease-smooth',
            tones[tone] || tones.nxt,
            indeterminate && 'animate-pulseSoft',
          )}
          style={{ width: indeterminate ? '100%' : `${pct}%` }}
        />
      </div>
    </div>
  )
}

export function Notice({ tone = 'info', title, children, icon: Icon, className = '', action }) {
  const tones = {
    info: {
      wrap: 'border-nxt-400/25 bg-nxt-500/[0.08]',
      icon: 'text-nxt-300',
      title: 'text-nxt-100',
    },
    success: {
      wrap: 'border-emerald-400/25 bg-emerald-500/[0.08]',
      icon: 'text-emerald-300',
      title: 'text-emerald-100',
    },
    warning: {
      wrap: 'border-amber-400/25 bg-amber-500/[0.08]',
      icon: 'text-amber-300',
      title: 'text-amber-100',
    },
    danger: {
      wrap: 'border-rose-400/25 bg-rose-500/[0.08]',
      icon: 'text-rose-300',
      title: 'text-rose-100',
    },
    neutral: {
      wrap: 'border-white/10 bg-white/[0.035]',
      icon: 'text-slate-400',
      title: 'text-slate-100',
    },
  }
  const theme = tones[tone] || tones.info
  const DefaultIcon =
    tone === 'success' ? Check : tone === 'danger' || tone === 'warning' ? AlertTriangle : Info
  const Glyph = Icon || DefaultIcon
  return (
    <div className={cx('rounded-xl border p-3.5', theme.wrap, className)} role="status">
      <div className="flex gap-3">
        <Glyph size={17} className={cx('mt-0.5 shrink-0', theme.icon)} />
        <div className="min-w-0 flex-1">
          {title ? <p className={cx('text-[13px] font-semibold', theme.title)}>{title}</p> : null}
          {children ? (
            <div className={cx('text-[12.5px] leading-relaxed text-slate-300', title && 'mt-1')}>
              {children}
            </div>
          ) : null}
        </div>
        {action}
      </div>
    </div>
  )
}

export function Spinner({ size = 16, className = '' }) {
  return <LoaderCircle size={size} className={cx('animate-spin', className)} />
}

export function Stat({ label, value, hint, mono = true, className = '' }) {
  return (
    <div className={cx('rounded-xl border border-white/[0.07] bg-white/[0.025] px-3 py-2.5', className)}>
      <p className="text-[10.5px] uppercase tracking-[0.14em] text-slate-500">{label}</p>
      <p className={cx('mt-1 text-[13.5px] text-slate-100', mono && 'font-mono text-[12.5px]')}>{value ?? '—'}</p>
      {hint ? <p className="mt-0.5 text-[11px] text-slate-500">{hint}</p> : null}
    </div>
  )
}

export function Divider({ className = '' }) {
  return <div className={cx('h-px w-full bg-gradient-to-r from-transparent via-white/10 to-transparent', className)} />
}

/* --------------------------------------------------------------- FileDrop */

import { FileAudio, FileVideo, Image as ImageIcon } from 'lucide-react'

function iconFor(file) {
  if (!file) return UploadCloud
  if (/^video\//.test(file.type) || /\.(mp4|mov|webm|mkv|avi|m4v|hevc)$/i.test(file.name)) return FileVideo
  if (/^audio\//.test(file.type) || /\.(mp3|wav|aac|m4a|ogg|opus|flac)$/i.test(file.name)) return FileAudio
  if (/^image\//.test(file.type)) return ImageIcon
  return UploadCloud
}

export function FileDrop({
  accept,
  onFile,
  file,
  hint,
  title = 'Drop a file here',
  subtitle = 'or click to browse',
  disabled = false,
  compact = false,
  inputRef: externalRef,
  multiple = false,
  className = '',
}) {
  const internalRef = useRef(null)
  const inputRef = externalRef || internalRef
  const [dragging, setDragging] = useState(false)
  const id = useId()

  const handleFiles = (files) => {
    if (!files || !files.length) return
    onFile(multiple ? Array.from(files) : files[0])
  }

  const Glyph = iconFor(file)

  return (
    <div className={className}>
      <input
        ref={inputRef}
        id={id}
        type="file"
        accept={accept}
        multiple={multiple}
        className="sr-only"
        disabled={disabled}
        onChange={(event) => {
          handleFiles(event.target.files)
          event.target.value = ''
        }}
      />
      <div
        role="button"
        tabIndex={disabled ? -1 : 0}
        aria-label={title}
        aria-disabled={disabled}
        onClick={() => !disabled && inputRef.current?.click()}
        onKeyDown={(event) => {
          if (disabled) return
          if (event.key === 'Enter' || event.key === ' ') {
            event.preventDefault()
            inputRef.current?.click()
          }
        }}
        onDragOver={(event) => {
          event.preventDefault()
          if (!disabled) setDragging(true)
        }}
        onDragLeave={() => setDragging(false)}
        onDrop={(event) => {
          event.preventDefault()
          setDragging(false)
          if (disabled) return
          handleFiles(event.dataTransfer?.files)
        }}
        className={cx(
          'group relative flex cursor-pointer flex-col items-center justify-center overflow-hidden rounded-2xl border-2 border-dashed text-center transition-all duration-300',
          compact ? 'px-4 py-6' : 'px-6 py-10',
          dragging
            ? 'border-nxt-400/70 bg-nxt-500/[0.1] shadow-glow'
            : file
              ? 'border-emerald-400/30 bg-emerald-500/[0.045] hover:border-emerald-400/50'
              : 'border-white/12 bg-white/[0.022] hover:border-white/25 hover:bg-white/[0.045]',
          disabled && 'cursor-not-allowed opacity-60',
        )}
      >
        <div
          className={cx(
            'grid place-items-center rounded-2xl border border-white/10 bg-white/[0.05] neu transition-transform duration-300 group-hover:scale-105',
            compact ? 'h-11 w-11' : 'h-14 w-14',
          )}
        >
          <Glyph size={compact ? 19 : 24} className={file ? 'text-emerald-300' : 'text-slate-300'} strokeWidth={1.7} />
        </div>

        {file ? (
          <>
            <p className="mt-3 max-w-full truncate px-2 text-[13.5px] font-medium text-slate-100">{file.name}</p>
            <p className="mt-1 text-[11.5px] text-slate-400">
              {(file.size / (1024 * 1024)).toFixed(1)} MB · click to replace
            </p>
          </>
        ) : (
          <>
            <p className="mt-3 text-[13.5px] font-medium text-slate-100">{title}</p>
            <p className="mt-1 text-[11.5px] text-slate-400">{subtitle}</p>
          </>
        )}

        {hint ? <p className="mt-3 max-w-[36ch] text-[11px] leading-relaxed text-slate-500">{hint}</p> : null}
      </div>
      {file ? (
        <button
          type="button"
          onClick={(event) => {
            event.stopPropagation()
            onFile(null)
          }}
          className="mt-2 inline-flex items-center gap-1 text-[11.5px] text-slate-500 transition hover:text-rose-300"
        >
          <X size={12} /> Clear file
        </button>
      ) : null}
    </div>
  )
}
