/**
 * Central configuration for NeXkiT Advanced Tools.
 * Everything an integrator might want to change lives here.
 */

const env = import.meta.env || {}

export const config = {
  brand: 'NeXkiT',
  engine: 'NXT Core',
  method: 'WAGLE Method',
  tagline: 'Advanced media tools',

  /** Where "Back to NeXkiT Home" points. Override with VITE_NEXKIT_HOME_URL. */
  homeUrl: env.VITE_NEXKIT_HOME_URL || '/',

  /** Optional TikTok publishing backend (see /server). Empty string = manual mode. */
  tiktokApiBase: String(env.VITE_TIKTOK_API_BASE || '').replace(/\/+$/, ''),

  limits: {
    /** Hard stop for the browser pipeline. */
    maxFileMB: 1024,
    /** Above this we warn about memory before starting. */
    warnFileMB: 250,
    /** Recommended ceiling for smooth browser encoding. */
    recommendedFileMB: 400,
  },
}

export const tiktokManualUploadUrl = 'https://www.tiktok.com/tiktokstudio/upload?from=webapp'
