import {
  AudioLines,
  Clapperboard,
  Crop,
  Download,
  Film,
  Gauge,
  Layers,
  Music,
  Scan,
  Scissors,
  Sparkles,
  WandSparkles,
} from 'lucide-react'

export const CATEGORIES = [
  {
    id: 'video',
    label: 'Video Tools',
    blurb: 'Compress, convert, retime and inspect footage — encoded locally with H.264.',
    icon: Film,
    tone: 'nxt',
    tools: [
      {
        id: 'compressor',
        name: 'Video Compressor',
        path: '/video/compressor',
        icon: Gauge,
        description:
          'Shrink MP4 and MOV files with H.264, adjustable CRF or bitrate, resolution presets and a live size estimate.',
        tags: ['MP4', 'H.264', 'CRF'],
        tone: 'nxt',
      },
      {
        id: 'converter',
        name: 'Video Converter',
        path: '/video/converter',
        icon: Film,
        description:
          'Bring MOV, WebM, MKV and other containers into a clean, compatible MP4 with your choice of encoder settings.',
        tags: ['MOV', 'WebM', 'MKV'],
        tone: 'nxt',
      },
      {
        id: 'fps',
        name: 'FPS Converter',
        path: '/video/fps',
        icon: Gauge,
        description:
          'Retime to 24, 25, 30, 50 or 60 fps. Choose honest frame duplication or optional motion interpolation.',
        tags: ['24–60 fps', 'CFR'],
        tone: 'cyan',
      },
      {
        id: 'resizer',
        name: 'Video Resizer',
        path: '/video/resizer',
        icon: Crop,
        description:
          'Reframe to 9:16, 16:9, 1:1, 4:3 or custom sizes with crop or fit, and preview the framing first.',
        tags: ['9:16', 'Crop', 'Fit'],
        tone: 'nxt',
      },
      {
        id: 'inspector',
        name: 'Metadata Inspector',
        path: '/video/inspector',
        icon: Scan,
        description:
          'Read resolution, frame rate, codec, bitrate, duration, colour and HDR signalling straight from the file.',
        tags: ['HDR', 'Codec', 'Bitrate'],
        tone: 'cyan',
      },
    ],
  },
  {
    id: 'audio',
    label: 'Audio Tools',
    blurb: 'Pull audio out of video, convert formats and control bitrate — offline in the browser.',
    icon: Music,
    tone: 'cyan',
    tools: [
      {
        id: 'extract',
        name: 'Extract Audio',
        path: '/audio/extract',
        icon: AudioLines,
        description:
          'Separate the audio track from any video into MP3, M4A, AAC or WAV, with a preview before download.',
        tags: ['MP3', 'M4A', 'WAV'],
        tone: 'cyan',
      },
      {
        id: 'audio-converter',
        name: 'Audio Converter',
        path: '/audio/convert',
        icon: Music,
        description:
          'Move between MP3, WAV, AAC and M4A with quality presets and a controllable bitrate.',
        tags: ['MP3', 'AAC', 'WAV'],
        tone: 'nxt',
      },
      {
        id: 'audio-compressor',
        name: 'Audio Compressor',
        path: '/audio/compress',
        icon: Download,
        description:
          'Reduce audio weight with predictable bitrate targets and see exactly what you save before downloading.',
        tags: ['Bitrate', 'Size'],
        tone: 'cyan',
      },
    ],
  },
  {
    id: 'editor',
    label: 'Video Editor',
    blurb: 'A browser timeline editor: multi-track, trim, split, text, fades, audio and MP4 export.',
    icon: Clapperboard,
    tone: 'nxt',
    tools: [
      {
        id: 'editor',
        name: 'Timeline Editor',
        path: '/editor',
        icon: Layers,
        description:
          'Import video, images and audio. Trim, split and reorder on multiple tracks, add text overlays, fades and export MP4.',
        tags: ['Timeline', 'Text', 'Export MP4'],
        tone: 'nxt',
      },
    ],
  },
  {
    id: 'tiktok',
    label: 'TikTok Studio',
    blurb: 'The WAGLE Method pipeline plus official-API publishing or a guided manual handoff.',
    icon: Sparkles,
    tone: 'wagle',
    tools: [
      {
        id: 'wagle',
        name: 'WAGLE Method',
        path: '/wagle',
        icon: WandSparkles,
        description:
          'Our signature preparation workflow: analyse the source, prepare quality, motion and colour, then deliver a 9:16 upload file.',
        tags: ['1080×1920', '60 fps', 'H.264'],
        tone: 'wagle',
        featured: true,
      },
      {
        id: 'studio',
        name: 'TikTok Studio',
        path: '/tiktok',
        icon: Scissors,
        description:
          'Prepare the post, then publish through the official TikTok Content Posting API — or finish the upload on TikTok manually.',
        tags: ['OAuth', 'Direct Post', 'Draft'],
        tone: 'wagle',
      },
    ],
  },
]

export const ALL_TOOLS = CATEGORIES.flatMap((category) =>
  category.tools.map((tool) => ({ ...tool, categoryId: category.id, categoryLabel: category.label })),
)

export function findTool(id) {
  return ALL_TOOLS.find((tool) => tool.id === id)
}
