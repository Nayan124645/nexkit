/**
 * Playback audio graph.
 * Every media element is routed through a MediaElementSource so the export
 * recorder can capture exactly what you hear.
 */
let ctx = null
let streamDestination = null
const connected = new WeakSet()

export function ensureAudioContext() {
  if (typeof window === 'undefined') return null
  const AudioCtx = window.AudioContext || window.webkitAudioContext
  if (!AudioCtx) return null

  if (!ctx) {
    ctx = new AudioCtx()
    streamDestination = ctx.createMediaStreamDestination()
  }
  if (ctx.state === 'suspended') ctx.resume().catch(() => {})
  return ctx
}

export function connectElement(element) {
  if (!element || connected.has(element)) return
  const audioCtx = ensureAudioContext()
  if (!audioCtx) return
  try {
    const source = audioCtx.createMediaElementSource(element)
    source.connect(audioCtx.destination)
    if (streamDestination) source.connect(streamDestination)
    connected.add(element)
  } catch {
    /* Element already has a source node (or has no audio) — ignore. */
  }
}

export function getAudioTracks() {
  ensureAudioContext()
  return streamDestination ? streamDestination.stream.getAudioTracks() : []
}

export function hasAudioContext() {
  return Boolean(ctx)
}
