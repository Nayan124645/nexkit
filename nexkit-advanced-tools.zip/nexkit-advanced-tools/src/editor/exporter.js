import { projectDelta } from './timelineMath'
import { getAudioTracks, connectElement } from './audio'
import { drawFrame } from './render'
import { pauseAll, resetAll, syncMedia, waitForMedia } from './playback'
import { projectSize } from './model'
import { runFFmpeg } from '../lib/ffmpeg'

const MP4_CANDIDATES = [
  'video/mp4;codecs=avc1.42E01E,mp4a.40.2',
  'video/mp4;codecs=avc1',
  'video/mp4',
  'video/webm;codecs=vp9,opus',
  'video/webm;codecs=vp8,opus',
  'video/webm',
]

export function pickMimeType() {
  if (typeof MediaRecorder === 'undefined') return null
  return MP4_CANDIDATES.find((type) => {
    try {
      return MediaRecorder.isTypeSupported(type)
    } catch {
      return false
    }
  })
}

function bitrateFor(width, height, fps) {
  const bpp = 0.12
  return Math.round(Math.min(24_000_000, Math.max(2_500_000, width * height * fps * bpp)))
}

/**
 * Export the timeline in real time from the compositing canvas, then convert to
 * MP4 when the browser can only record WebM.
 */
export async function exportProject({ project, pool, canvas, onProgress, onPhase, isCancelled }) {
  const duration = projectDelta(project)
  if (!duration) throw new Error('Add at least one clip to the timeline before exporting.')
  if (!canvas) throw new Error('The preview canvas is not ready yet.')
  if (typeof MediaRecorder === 'undefined') {
    throw new Error('This browser does not support MediaRecorder, so the editor cannot export.')
  }

  const mimeType = pickMimeType()
  if (!mimeType) throw new Error('No supported recording format was found in this browser.')

  const { width, height } = projectSize(project)
  const fps = project.fps || 30
  canvas.width = width
  canvas.height = height

  resetAll(pool, project.tracks.flatMap((track) => track.clips))
  await waitForMedia(pool)
  onPhase?.('Rendering timeline…')

  Object.values(pool.current || pool).forEach((element) => {
    if (element && element.tagName !== 'IMG') connectElement(element)
  })

  const stream = canvas.captureStream(fps)
  getAudioTracks().forEach((track) => stream.addTrack(track))

  const chunks = []
  const recorder = new MediaRecorder(stream, {
    mimeType,
    videoBitsPerSecond: bitrateFor(width, height, fps),
    audioBitsPerSecond: 160_000,
  })

  const stopped = new Promise((resolve) => {
    recorder.onstop = resolve
  })
  recorder.ondataavailable = (event) => {
    if (event.data && event.data.size > 0) chunks.push(event.data)
  }

  const ctx = canvas.getContext('2d')
  recorder.start(250)

  const started = performance.now()
  await new Promise((resolve) => {
    const tick = () => {
      const elapsed = (performance.now() - started) / 1000
      if (isCancelled?.() || elapsed >= duration) {
        resolve()
        return
      }
      syncMedia(project, pool, elapsed, true)
      drawFrame(ctx, project, pool, elapsed)
      onProgress?.(Math.min(0.99, elapsed / duration) * 0.9)
      requestAnimationFrame(tick)
    }
    requestAnimationFrame(tick)
  })

  pauseAll(pool)
  try {
    recorder.stop()
  } catch {
    /* already stopped */
  }
  await stopped
  stream.getTracks().forEach((track) => {
    if (track.kind === 'video') track.stop()
  })

  if (isCancelled?.()) return null

  const recorded = new Blob(chunks, { type: mimeType.split(';')[0] })
  if (!recorded.size) throw new Error('The recorder produced an empty file. Try a shorter timeline.')

  if (mimeType.includes('mp4')) {
    onProgress?.(1)
    return { blob: recorded, converted: false, mimeType }
  }

  onPhase?.('Converting to MP4 with H.264…')
  const file = new File([recorded], 'timeline-export.webm', { type: recorded.type })
  const result = await runFFmpeg({
    file,
    args: [
      '-hide_banner',
      '-y',
      '-i',
      '@in',
      '-c:v',
      'libx264',
      '-preset',
      'veryfast',
      '-crf',
      '20',
      '-pix_fmt',
      'yuv420p',
      '-movflags',
      '+faststart',
      '-c:a',
      'aac',
      '-b:a',
      '192k',
      '@out',
    ],
    output: 'timeline-export.mp4',
    outputType: 'video/mp4',
    onProgress: (value) => onProgress?.(0.9 + value * 0.1),
    onStatus: onPhase,
  })

  return { blob: result.blob, converted: true, mimeType: 'video/mp4' }
}
