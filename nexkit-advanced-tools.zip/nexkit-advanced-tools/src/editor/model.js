/**
 * Timeline data model. Plain objects + immutable helpers so React state updates
 * stay predictable and the renderer can stay completely dumb.
 */

export const ASPECTS = [
  { id: '9:16', width: 1080, height: 1920, label: '9:16 Vertical' },
  { id: '16:9', width: 1920, height: 1080, label: '16:9 Landscape' },
  { id: '1:1', width: 1080, height: 1080, label: '1:1 Square' },
  { id: '4:5', width: 1080, height: 1350, label: '4:5 Portrait' },
]

export const FPS_OPTIONS = [24, 25, 30, 60]

export const TRACK_KINDS = {
  video: { label: 'Video', accepts: ['video', 'image'] },
  overlay: { label: 'Overlay', accepts: ['text'] },
  audio: { label: 'Audio', accepts: ['audio'] },
}

let counter = 0
export function uid(prefix = 'id') {
  counter += 1
  return `${prefix}_${counter.toString(36)}${Math.random().toString(36).slice(2, 6)}`
}

export function projectSize(project) {
  const aspect = ASPECTS.find((item) => item.id === project.aspect) || ASPECTS[0]
  return { width: aspect.width, height: aspect.height }
}

export function createProject({ aspect = '9:16', fps = 30 } = {}) {
  return {
    id: uid('project'),
    name: 'Untitled project',
    aspect,
    fps,
    tracks: [
      { id: uid('track'), kind: 'video', name: 'Video 1', clips: [], muted: false },
      { id: uid('track'), kind: 'overlay', name: 'Overlay', clips: [], muted: false },
      { id: uid('track'), kind: 'audio', name: 'Audio', clips: [], muted: false },
    ],
  }
}

export function projectDuration(project) {
  let end = 0
  for (const track of project.tracks) {
    for (const clip of track.clips) end = Math.max(end, clip.start + clip.duration)
  }
  return end
}

export function assetDuration(asset) {
  if (!asset) return 0
  if (asset.type === 'image') return 5
  return Math.max(0.4, asset.duration || 5)
}

export function makeClipFromAsset(asset, start = 0) {
  const duration = assetDuration(asset)
  return {
    id: uid('clip'),
    type: asset.type,
    name: asset.name,
    src: asset.src,
    start: Math.max(0, start),
    duration,
    trimIn: 0,
    sourceDuration: asset.type === 'image' ? null : duration,
    volume: 1,
    fit: 'cover',
    scale: 1,
    offsetX: 0,
    offsetY: 0,
    fadeIn: 0,
    fadeOut: 0,
    text: null,
  }
}

export function makeTextClip(start = 0, content = 'Your text') {
  return {
    id: uid('clip'),
    type: 'text',
    name: content,
    src: null,
    start: Math.max(0, start),
    duration: 4,
    trimIn: 0,
    sourceDuration: null,
    volume: 1,
    fit: 'cover',
    scale: 1,
    offsetX: 0,
    offsetY: 0,
    fadeIn: 0,
    fadeOut: 0,
    text: {
      content,
      size: 72,
      color: '#ffffff',
      align: 'center',
      position: 'bottom',
      bg: true,
      weight: 700,
    },
  }
}

function mapTracks(project, fn) {
  return { ...project, tracks: project.tracks.map(fn) }
}

export function trackById(project, trackId) {
  return project.tracks.find((track) => track.id === trackId)
}

export function findClip(project, clipId) {
  for (const track of project.tracks) {
    const clip = track.clips.find((item) => item.id === clipId)
    if (clip) return { track, clip }
  }
  return null
}

export function allClips(project) {
  return project.tracks.flatMap((track) => track.clips.map((clip) => ({ ...clip, trackId: track.id, trackKind: track.kind })))
}

export function addClipToTrack(project, trackId, clip) {
  return mapTracks(project, (track) =>
    track.id === trackId ? { ...track, clips: [...track.clips, clip] } : track,
  )
}

export function targetTrackFor(project, kind) {
  return project.tracks.find((track) => track.kind === kind) || project.tracks[0]
}

export function updateClip(project, clipId, patch) {
  return mapTracks(project, (track) => ({
    ...track,
    clips: track.clips.map((clip) => (clip.id === clipId ? { ...clip, ...patch } : clip)),
  }))
}

export function updateText(project, clipId, patch) {
  return mapTracks(project, (track) => ({
    ...track,
    clips: track.clips.map((clip) =>
      clip.id === clipId && clip.type === 'text'
        ? { ...clip, text: { ...clip.text, ...patch }, name: patch.content ?? clip.name }
        : clip,
    ),
  }))
}

export function removeClip(project, clipId) {
  return mapTracks(project, (track) => ({
    ...track,
    clips: track.clips.filter((clip) => clip.id !== clipId),
  }))
}

export function duplicateClip(project, clipId) {
  const found = findClip(project, clipId)
  if (!found) return project
  const copy = { ...found.clip, id: uid('clip'), start: found.clip.start + found.clip.duration }
  return addClipToTrack(project, found.track.id, copy)
}

export function splitClip(project, clipId, time) {
  const found = findClip(project, clipId)
  if (!found) return project
  const { clip, track } = found
  const local = time - clip.start
  if (local <= 0.05 || local >= clip.duration - 0.05) return project

  const left = { ...clip, duration: local }
  const right = {
    ...clip,
    id: uid('clip'),
    start: clip.start + local,
    trimIn: clip.trimIn + local,
    duration: clip.duration - local,
  }

  return mapTracks(project, (item) =>
    item.id === track.id
      ? {
          ...item,
          clips: item.clips.flatMap((entry) => (entry.id === clipId ? [left, right] : [entry])),
        }
      : item,
  )
}

export function addTrack(project, kind = 'video') {
  const count = project.tracks.filter((track) => track.kind === kind).length + 1
  if (project.tracks.length >= 6) return project
  const insertAt = Math.max(
    project.tracks.findIndex((track) => track.kind === 'overlay'),
    0,
  )
  const track = {
    id: uid('track'),
    kind,
    name: `${TRACK_KINDS[kind].label} ${count}`,
    clips: [],
    muted: false,
  }
  const tracks = [...project.tracks]
  tracks.splice(insertAt < 0 ? tracks.length : insertAt, 0, track)
  return { ...project, tracks }
}

export function removeTrack(project, trackId) {
  const track = trackById(project, trackId)
  if (!track) return project
  const sameKind = project.tracks.filter((item) => item.kind === track.kind).length
  if (sameKind <= 1) return project
  return { ...project, tracks: project.tracks.filter((item) => item.id !== trackId) }
}

export function setTrackMuted(project, trackId, muted) {
  return mapTracks(project, (track) => (track.id === trackId ? { ...track, muted } : track))
}

/** Clip that should be visible on a given track at a given time. */
export function clipAt(track, time) {
  return track.clips.find((clip) => time >= clip.start && time < clip.start + clip.duration) || null
}

export function fadeAlpha(clip, localTime) {
  const fadeIn = clip.fadeIn || 0
  const fadeOut = clip.fadeOut || 0
  let alpha = 1
  if (fadeIn > 0 && localTime < fadeIn) alpha = Math.min(alpha, Math.max(0, localTime / fadeIn))
  const fromEnd = clip.duration - localTime
  if (fadeOut > 0 && fromEnd < fadeOut) alpha = Math.min(alpha, Math.max(0, fromEnd / fadeOut))
  return alpha
}
