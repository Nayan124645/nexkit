import { clamp } from '../lib/format'
import { connectElement } from './audio'

export function pauseAll(pool) {
  const elements = pool.current || pool
  Object.values(elements).forEach((element) => {
    try {
      element.pause()
    } catch {
      /* noop */
    }
  })
}

export function resetAll(pool, clips) {
  const elements = pool.current || pool
  clips.forEach((clip) => {
    const element = elements[clip.id]
    if (!element) return
    try {
      element.pause()
      element.currentTime = clip.trimIn || 0
    } catch {
      /* noop */
    }
  })
}

/**
 * Keep every media element aligned with the playhead.
 * Small drift is tolerated; anything above 220 ms is corrected with a seek.
 */
export function syncMedia(project, pool, time, playing) {
  const elements = pool.current || pool

  for (const track of project.tracks) {
    for (const clip of track.clips) {
      if (clip.type === 'text') continue
      const element = elements[clip.id]
      if (!element) continue

      const active = time >= clip.start && time < clip.start + clip.duration
      if (!active) {
        if (!element.paused) {
          try {
            element.pause()
          } catch {
            /* noop */
          }
        }
        continue
      }

      const assetTime = (clip.trimIn || 0) + (time - clip.start)
      const drift = Math.abs((element.currentTime || 0) - assetTime)
      if (drift > 0.22) {
        try {
          element.currentTime = assetTime
        } catch {
          /* seeking can fail before metadata */
        }
      }

      element.volume = track.muted ? 0 : clamp(clip.volume ?? 1, 0, 1)
      element.muted = track.muted

      if (playing) {
        connectElement(element)
        if (element.paused) element.play().catch(() => {})
      } else if (!element.paused) {
        try {
          element.pause()
        } catch {
          /* noop */
        }
      }
    }
  }
}

export function waitForMedia(pool, timeout = 6000) {
  const elements = Object.values(pool.current || pool)
  const pending = elements
    .filter((element) => element && element.tagName !== 'IMG' && element.readyState < 2)
    .map(
      (element) =>
        new Promise((resolve) => {
          if (element.readyState >= 2) return resolve()
          const done = () => {
            element.removeEventListener('loadeddata', done)
            element.removeEventListener('error', done)
            resolve()
          }
          element.addEventListener('loadeddata', done, { once: true })
          element.addEventListener('error', done, { once: true })
        }),
    )

  if (!pending.length) return Promise.resolve()
  return Promise.race([Promise.all(pending), new Promise((resolve) => setTimeout(resolve, timeout))])
}
