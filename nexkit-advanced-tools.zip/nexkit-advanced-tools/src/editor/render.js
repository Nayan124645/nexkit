import { fadeAlpha, projectSize } from './model'

const FONT_STACK = 'ui-sans-serif, -apple-system, "Segoe UI", Inter, Roboto, Helvetica, Arial, sans-serif'

function drawMedia(ctx, clip, element, width, height, alpha) {
  if (!element) return
  const sw = element.videoWidth || element.naturalWidth || 0
  const sh = element.videoHeight || element.naturalHeight || 0
  if (!sw || !sh) return

  const base = clip.fit === 'contain' ? Math.min(width / sw, height / sh) : Math.max(width / sw, height / sh)
  const scale = base * (clip.scale || 1)
  const dw = sw * scale
  const dh = sh * scale
  const dx = (width - dw) / 2 + (clip.offsetX || 0) * width
  const dy = (height - dh) / 2 + (clip.offsetY || 0) * height

  ctx.save()
  ctx.globalAlpha = alpha
  ctx.imageSmoothingEnabled = true
  ctx.imageSmoothingQuality = 'high'
  ctx.drawImage(element, dx, dy, dw, dh)
  ctx.restore()
}

function wrapText(ctx, text, maxWidth) {
  const paragraphs = String(text || '').split('\n')
  const lines = []
  for (const paragraph of paragraphs) {
    const words = paragraph.split(/\s+/).filter(Boolean)
    if (!words.length) {
      lines.push('')
      continue
    }
    let line = ''
    for (const word of words) {
      const candidate = line ? `${line} ${word}` : word
      if (ctx.measureText(candidate).width <= maxWidth || !line) {
        line = candidate
      } else {
        lines.push(line)
        line = word
      }
    }
    if (line) lines.push(line)
  }
  return lines.slice(0, 8)
}

function roundRect(ctx, x, y, width, height, radius) {
  const r = Math.min(radius, height / 2, width / 2)
  ctx.beginPath()
  ctx.moveTo(x + r, y)
  ctx.arcTo(x + width, y, x + width, y + height, r)
  ctx.arcTo(x + width, y + height, x, y + height, r)
  ctx.arcTo(x, y + height, x, y, r)
  ctx.arcTo(x, y, x + width, y, r)
  ctx.closePath()
}

function drawText(ctx, clip, width, height, alpha) {
  const text = clip.text
  if (!text?.content) return

  const fontSize = Math.max(14, (text.size || 72) * (width / 1080))
  const lineHeight = fontSize * 1.2
  ctx.save()
  ctx.globalAlpha = alpha
  ctx.font = `${text.weight || 700} ${fontSize}px ${FONT_STACK}`
  ctx.textAlign = text.align || 'center'
  ctx.textBaseline = 'middle'

  const maxWidth = width * 0.86
  const lines = wrapText(ctx, text.content, maxWidth)
  const blockHeight = Math.max(lineHeight, lines.length * lineHeight)

  const anchorX =
    text.align === 'left' ? width * 0.07 : text.align === 'right' ? width * 0.93 : width / 2
  const centerY =
    text.position === 'top'
      ? height * 0.12 + blockHeight / 2
      : text.position === 'bottom'
        ? height * 0.88 - blockHeight / 2
        : height / 2

  const firstY = centerY - ((lines.length - 1) * lineHeight) / 2

  if (text.bg) {
    const widest = Math.min(
      maxWidth,
      Math.max(...lines.map((line) => ctx.measureText(line).width), fontSize),
    )
    const padX = fontSize * 0.45
    const padY = fontSize * 0.3
    const boxX =
      text.align === 'left'
        ? anchorX - padX
        : text.align === 'right'
          ? anchorX - widest - padX
          : anchorX - widest / 2 - padX
    const boxY = firstY - lineHeight / 2 - padY + (lineHeight - fontSize) / 2
    ctx.fillStyle = 'rgba(6, 8, 14, 0.55)'
    roundRect(ctx, boxX, boxY, widest + padX * 2, blockHeight + padY * 1.4, fontSize * 0.28)
    ctx.fill()
  }

  ctx.fillStyle = text.color || '#ffffff'
  ctx.shadowColor = 'rgba(0,0,0,0.45)'
  ctx.shadowBlur = fontSize * 0.12
  ctx.shadowOffsetY = fontSize * 0.03
  lines.forEach((line, index) => {
    ctx.fillText(line, anchorX, firstY + index * lineHeight)
  })
  ctx.restore()
}

/** Render the whole composition at `time` (seconds). */
export function drawFrame(ctx, project, pool, time) {
  const { width, height } = projectSize(project)
  if (!ctx) return

  if (ctx.canvas.width !== width) ctx.canvas.width = width
  if (ctx.canvas.height !== height) ctx.canvas.height = height

  ctx.setTransform(1, 0, 0, 1, 0, 0)
  ctx.globalAlpha = 1
  ctx.fillStyle = '#05060a'
  ctx.fillRect(0, 0, width, height)

  // Track order is paint order: the first track is the base layer, later tracks sit on top.
  for (const track of project.tracks) {
    if (track.kind === 'audio') continue
    for (const clip of track.clips) {
      if (time < clip.start || time >= clip.start + clip.duration) continue
      const local = time - clip.start
      const alpha = fadeAlpha(clip, local)
      if (alpha <= 0.001) continue
      if (clip.type === 'text') {
        drawText(ctx, clip, width, height, alpha)
      } else {
        drawMedia(ctx, clip, pool.current?.[clip.id] || pool[clip.id], width, height, alpha)
      }
    }
  }
}

export function drawEmptyState(ctx, project, message = 'Add a clip to begin') {
  const { width, height } = projectSize(project)
  ctx.setTransform(1, 0, 0, 1, 0, 0)
  ctx.fillStyle = '#05060a'
  ctx.fillRect(0, 0, width, height)
  ctx.fillStyle = 'rgba(255,255,255,0.28)'
  ctx.font = `500 ${Math.round(width / 34)}px ${FONT_STACK}`
  ctx.textAlign = 'center'
  ctx.textBaseline = 'middle'
  ctx.fillText(message, width / 2, height / 2)
}
