import { projectDuration } from './model'

export function projectDelta(project) {
  return projectDuration(project)
}

export function snapTime(seconds, step = 0.05) {
  return Math.round(seconds / step) * step
}

export function xToTime(x, pps) {
  return Math.max(0, x / pps)
}

export function timeToX(time, pps) {
  return time * pps
}

export function formatTimecode(seconds, fps = 30) {
  const total = Math.max(0, seconds || 0)
  const minutes = Math.floor(total / 60)
  const secs = Math.floor(total % 60)
  const frames = Math.floor((total % 1) * (fps || 30))
  return `${minutes}:${String(secs).padStart(2, '0')}.${String(frames).padStart(2, '0')}`
}

export function tickStep(zoom) {
  if (zoom >= 3) return 0.5
  if (zoom >= 1.4) return 1
  if (zoom >= 0.7) return 2
  return 5
}
