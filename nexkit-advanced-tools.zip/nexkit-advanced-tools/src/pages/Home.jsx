import { useMemo, useState } from 'react'
import { Link } from 'react-router-dom'
import {
  ArrowRight,
  ChevronRight,
  Clapperboard,
  Cpu,
  HardDrive,
  Search,
  ShieldCheck,
  Sparkles,
  WandSparkles,
  X,
  Zap,
} from 'lucide-react'
import { Badge, Button, IconBadge, Panel, cx } from '../components/ui'
import { CATEGORIES } from '../data/tools'
import { config } from '../config'

const ENGINE_FACTS = [
  { icon: ShieldCheck, label: 'Processing', value: 'On this device' },
  { icon: Cpu, label: 'Engine', value: config.engine },
  { icon: HardDrive, label: 'Output', value: 'MP4 · H.264 · AAC' },
]

function ToolCard({ tool, category }) {
  return (
    <Link
      to={tool.path}
      className="group relative flex flex-col overflow-hidden rounded-2xl border border-white/[0.07] bg-white/[0.022] p-5 transition-all duration-300 ease-smooth hover:-translate-y-0.5 hover:border-white/15 hover:bg-white/[0.05] hover:shadow-lift"
    >
      <div className="flex items-start justify-between gap-3">
        <IconBadge icon={tool.icon} tone={tool.tone || category.tone} />
        <ArrowRight
          size={16}
          className="mt-1 text-slate-600 transition-all duration-300 group-hover:translate-x-0.5 group-hover:text-slate-300"
        />
      </div>
      <h3 className="mt-4 text-[15px] font-semibold tracking-[-0.015em] text-slate-100">{tool.name}</h3>
      <p className="mt-1.5 flex-1 text-[12.5px] leading-relaxed text-slate-400">{tool.description}</p>
      <div className="mt-4 flex flex-wrap gap-1.5">
        {tool.tags.map((tag) => (
          <span
            key={tag}
            className="rounded-md border border-white/[0.07] bg-white/[0.03] px-1.5 py-0.5 font-mono text-[10px] text-slate-500"
          >
            {tag}
          </span>
        ))}
      </div>
    </Link>
  )
}

function WagleSpotlight() {
  return (
    <Link
      to="/wagle"
      className="group relative block overflow-hidden rounded-3xl border border-wagle-400/20 bg-gradient-to-br from-wagle-400/[0.11] via-white/[0.03] to-ink-950 p-6 transition-all duration-300 hover:border-wagle-400/40 hover:shadow-[0_30px_70px_-40px_rgba(245,158,11,0.55)] sm:p-8"
    >
      <div className="pointer-events-none absolute -right-24 -top-24 h-64 w-64 rounded-full bg-wagle-400/20 blur-3xl" />
      <div className="relative flex flex-col gap-6 lg:flex-row lg:items-center lg:justify-between">
        <div className="max-w-2xl">
          <div className="flex flex-wrap items-center gap-2">
            <Badge tone="wagle">
              <WandSparkles size={11} /> Signature workflow
            </Badge>
            <Badge tone="slate">NXT Core pipeline</Badge>
          </div>
          <h2 className="mt-3 text-[clamp(1.35rem,2.6vw,1.9rem)] font-semibold tracking-tightest text-white">
            <span className="grad-wagle">WAGLE Method</span> — prepare the file TikTok receives
          </h2>
          <p className="mt-2.5 max-w-xl text-[13px] leading-relaxed text-slate-300/90">
            Analyse the source, then prepare quality, motion and colour with an honest pipeline: container passthrough
            when possible, H.264 when it is not, 1080×1920 delivery and a real before/after comparison. No promises
            about beating TikTok&apos;s own re-encode — just the cleanest upload file we can build locally.
          </p>
          <div className="mt-4 flex flex-wrap gap-2">
            {['Source analysis', 'HDR aware', '9:16 · 1080p', '30 / 60 fps', 'Before & after'].map((item) => (
              <span
                key={item}
                className="rounded-full border border-white/10 bg-white/[0.05] px-2.5 py-1 text-[11px] text-slate-300"
              >
                {item}
              </span>
            ))}
          </div>
        </div>
        <div className="flex shrink-0 items-center gap-3">
          <span className="inline-flex items-center gap-2 rounded-xl bg-gradient-to-br from-wagle-300 to-[#ff8a3d] px-4 py-3 text-[13px] font-semibold text-[#22160a] shadow-[0_16px_40px_-18px_rgba(245,158,11,0.9)] transition-transform duration-300 group-hover:translate-x-0.5">
            Open WAGLE Method
            <ArrowRight size={16} />
          </span>
        </div>
      </div>
    </Link>
  )
}

export default function Home() {
  const [query, setQuery] = useState('')

  const searchResults = useMemo(() => {
    const term = query.trim().toLowerCase()
    if (!term) return null
    return CATEGORIES.flatMap((category) =>
      category.tools
        .filter((tool) =>
          [tool.name, tool.description, ...(tool.tags || []), category.label]
            .join(' ')
            .toLowerCase()
            .includes(term),
        )
        .map((tool) => ({ tool, category })),
    )
  }, [query])

  return (
    <div className="mx-auto w-full max-w-7xl px-4 pb-24 pt-10 sm:px-6 lg:px-8">
      {/* Hero */}
      <section className="grid gap-8 lg:grid-cols-[minmax(0,1.45fr)_minmax(0,0.85fr)] lg:items-start">
        <div>
          <div className="flex flex-wrap items-center gap-2">
            <Badge tone="nxt">
              <Zap size={11} /> NXT Core engine
            </Badge>
            <Badge tone="slate">Browser-native</Badge>
            <Badge tone="success">No uploads</Badge>
          </div>

          <h1 className="mt-4 text-[clamp(2.2rem,5.2vw,3.6rem)] font-semibold leading-[1.03] tracking-tightest text-white">
            Advanced Tools for
            <br />
            <span className="grad-text">professional media work.</span>
          </h1>

          <p className="mt-4 max-w-xl text-[14px] leading-relaxed text-slate-400">
            Compress, convert, retime and inspect video. Extract and convert audio. Cut on a real timeline. Prepare an
            upload file with the WAGLE Method. Everything runs on your own machine.
          </p>

          <div className="relative mt-6 max-w-xl">
            <Search size={17} className="pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 text-slate-500" />
            <input
              type="search"
              value={query}
              onChange={(event) => setQuery(event.target.value)}
              placeholder="Search tools — compressor, fps, mp3, HDR, timeline…"
              aria-label="Search advanced tools"
              className="h-13 w-full rounded-2xl border border-white/10 bg-ink-900/70 pl-11 pr-11 text-[13.5px] text-slate-100 placeholder:text-slate-500 shadow-[inset_0_1px_3px_rgba(0,0,0,0.55)] transition focus:border-nxt-400/50 focus:outline-none focus:ring-2 focus:ring-nxt-500/20"
              style={{ height: 52 }}
            />
            {query ? (
              <button
                type="button"
                onClick={() => setQuery('')}
                aria-label="Clear search"
                className="absolute right-3 top-1/2 grid h-7 w-7 -translate-y-1/2 place-items-center rounded-lg text-slate-500 hover:bg-white/10 hover:text-slate-200"
              >
                <X size={14} />
              </button>
            ) : null}
          </div>

          <div className="mt-3 flex flex-wrap items-center gap-2 text-[11.5px] text-slate-500">
            <span>Popular:</span>
            {[
              { label: 'Compress', to: '/video/compressor' },
              { label: 'WAGLE Method', to: '/wagle' },
              { label: 'Editor', to: '/editor' },
              { label: 'Extract MP3', to: '/audio/extract' },
            ].map((item) => (
              <Link
                key={item.label}
                to={item.to}
                className="rounded-full border border-white/[0.08] px-2.5 py-1 text-slate-400 transition hover:border-white/20 hover:text-slate-200"
              >
                {item.label}
              </Link>
            ))}
          </div>
        </div>

        <Panel className="p-5">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-[10.5px] uppercase tracking-[0.18em] text-slate-500">Workspace</p>
              <p className="mt-1 text-[15px] font-semibold text-white">Engine overview</p>
            </div>
            <span className="inline-flex items-center gap-1.5 rounded-full border border-emerald-400/25 bg-emerald-500/[0.08] px-2.5 py-1 text-[10.5px] font-medium text-emerald-300">
              <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 shadow-[0_0_8px_rgba(52,211,153,0.8)]" />
              Ready
            </span>
          </div>

          <div className="mt-4 space-y-2">
            {ENGINE_FACTS.map((fact) => (
              <div
                key={fact.label}
                className="flex items-center justify-between gap-3 rounded-xl border border-white/[0.06] bg-white/[0.025] px-3.5 py-2.5"
              >
                <span className="flex items-center gap-2 text-[12px] text-slate-400">
                  <fact.icon size={14} className="text-slate-500" />
                  {fact.label}
                </span>
                <span className="font-mono text-[11.5px] text-slate-200">{fact.value}</span>
              </div>
            ))}
          </div>

          <div className="mt-4 rounded-xl border border-white/[0.06] bg-white/[0.02] p-3.5">
            <p className="text-[11px] uppercase tracking-[0.16em] text-slate-500">File limits</p>
            <ul className="mt-2 space-y-1.5 text-[11.5px] leading-relaxed text-slate-400">
              <li className="flex justify-between gap-3">
                <span>Comfortable</span>
                <span className="font-mono text-slate-300">≤ {config.limits.recommendedFileMB} MB</span>
              </li>
              <li className="flex justify-between gap-3">
                <span>Hard stop</span>
                <span className="font-mono text-slate-300">{config.limits.maxFileMB} MB</span>
              </li>
            </ul>
          </div>

          <Button as={Link} to="/wagle" variant="wagle" className="mt-4 w-full" icon={Sparkles}>
            Start with WAGLE Method
          </Button>
        </Panel>
      </section>

      {/* Search results or categories */}
      {searchResults ? (
        <section className="mt-12">
          <div className="flex items-baseline justify-between gap-4">
            <h2 className="text-[17px] font-semibold text-white">
              {searchResults.length} result{searchResults.length === 1 ? '' : 's'} for “{query.trim()}”
            </h2>
            <button
              type="button"
              onClick={() => setQuery('')}
              className="text-[12px] text-slate-500 transition hover:text-slate-300"
            >
              Clear
            </button>
          </div>

          {searchResults.length ? (
            <div className="mt-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
              {searchResults.map(({ tool, category }) => (
                <ToolCard key={tool.id} tool={tool} category={category} />
              ))}
            </div>
          ) : (
            <div className="mt-4 rounded-2xl border border-white/[0.07] bg-white/[0.02] p-8 text-center">
              <p className="text-sm text-slate-300">No tool matches that search.</p>
              <p className="mt-1 text-[12px] text-slate-500">
                Try “compress”, “fps”, “mp3”, “crop”, “HDR”, “timeline” or “TikTok”.
              </p>
            </div>
          )}
        </section>
      ) : (
        <>
          <section className="mt-12">
            <WagleSpotlight />
          </section>

          <section className="mt-14 space-y-12">
            {CATEGORIES.map((category) => (
              <div key={category.id} id={category.id}>
                <div className="flex flex-wrap items-end justify-between gap-3">
                  <div className="flex items-start gap-3">
                    <IconBadge icon={category.icon} tone={category.tone} size="md" />
                    <div>
                      <h2 className="text-[19px] font-semibold tracking-tight text-white">{category.label}</h2>
                      <p className="mt-1 max-w-xl text-[12.5px] leading-relaxed text-slate-400">{category.blurb}</p>
                    </div>
                  </div>
                  <span className="font-mono text-[11px] text-slate-600">
                    {category.tools.length} tool{category.tools.length === 1 ? '' : 's'}
                  </span>
                </div>

                <div
                  className={cx(
                    'mt-4 grid gap-3',
                    category.tools.length === 1 ? 'sm:max-w-md' : 'sm:grid-cols-2 lg:grid-cols-3',
                  )}
                >
                  {category.tools.map((tool) => (
                    <ToolCard key={tool.id} tool={tool} category={category} />
                  ))}
                </div>
              </div>
            ))}
          </section>
        </>
      )}

      {/* Closing strip */}
      <section className="mt-16 grid gap-4 md:grid-cols-3">
        {[
          {
            icon: ShieldCheck,
            title: 'Private by architecture',
            body: 'Files are read with the File API and encoded in a WebAssembly worker. No media leaves the tab.',
          },
          {
            icon: Cpu,
            title: 'Modular engine',
            body: 'The NXT Core adapter is isolated, so a native desktop encoder can replace the browser engine later.',
          },
          {
            icon: Clapperboard,
            title: 'Built to extend',
            body: 'Every tool shares the same panels, progress and result surfaces — new tools take minutes to add.',
          },
        ].map((item) => (
          <div key={item.title} className="rounded-2xl border border-white/[0.07] bg-white/[0.02] p-5">
            <item.icon size={18} className="text-nxt-300" />
            <h3 className="mt-3 text-[13.5px] font-semibold text-slate-100">{item.title}</h3>
            <p className="mt-1.5 text-[12px] leading-relaxed text-slate-400">{item.body}</p>
          </div>
        ))}
      </section>

      <div className="mt-10 flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-white/[0.07] bg-white/[0.02] px-5 py-4">
        <p className="text-[12px] text-slate-400">
          Ready to publish? Continue to{' '}
          <Link to="/tiktok" className="text-slate-200 underline decoration-white/20 underline-offset-4 hover:decoration-white/60">
            TikTok Studio
          </Link>
          .
        </p>
        <Link
          to="/tiktok"
          className="inline-flex items-center gap-1.5 text-[12px] font-medium text-slate-200 hover:text-white"
        >
          Prepare a post <ChevronRight size={14} />
        </Link>
      </div>
    </div>
  )
}
