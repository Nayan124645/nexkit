import { useEffect, useMemo, useState } from 'react'
import { Download, Music, Volume2 } from 'lucide-react'
import { OutputCard, SideNote, ToolGrid, ToolShell } from '../../components/ToolShell'
import {
  Badge,
  Button,
  Field,
  FileDrop,
  Notice,
  Panel,
  PanelHeader,
  Segmented,
  Slider,
  Stat,
} from '../../components/ui'
import { JobStatus } from '../../components/JobStatus'
import { FileLimitNotice, PrivacyNote } from '../../components/EngineHints'
import { useTask } from '../../lib/useTask'
import { runFFmpeg } from '../../lib/ffmpeg'
import { quickProbe } from '../../lib/mediaInfo'
import { audioOnlyArgs } from '../../lib/encode'
import { formatBytes, safeFileName } from '../../lib/format'

const TARGETS = [
  { id: 'm4a', label: 'M4A (AAC)', ext: 'm4a', mime: 'audio/mp4' },
  { id: 'mp3', label: 'MP3', ext: 'mp3', mime: 'audio/mpeg' },
]

export default function AudioCompressor() {
  const [file, setFile] = useState(null)
  const [quick, setQuick] = useState(null)
  const [result, setResult] = useState(null)

  const [format, setFormat] = useState('m4a')
  const [kbps, setKbps] = useState(128)

  const task = useTask()
  const spec = TARGETS.find((item) => item.id === format) || TARGETS[0]

  useEffect(() => {
    if (!file) {
      setQuick(null)
      return undefined
    }
    let alive = true
    quickProbe(file).then((data) => alive && setQuick(data))
    return () => {
      alive = false
    }
  }, [file])

  useEffect(() => {
    return () => {
      if (result?.url) URL.revokeObjectURL(result.url)
    }
  }, [result])

  const estimatedSize = useMemo(
    () => (quick?.duration ? Math.round((kbps * 1000 * quick.duration) / 8) : null),
    [quick, kbps],
  )

  const saving = file && estimatedSize ? file.size - estimatedSize : null
  const savingPercent = saving !== null && file?.size ? saving / file.size : null

  const reset = () => {
    if (result?.url) URL.revokeObjectURL(result.url)
    setResult(null)
    setFile(null)
    task.reset()
  }

  const start = async () => {
    if (!file) return
    if (result?.url) URL.revokeObjectURL(result.url)
    setResult(null)

    const outputName = safeFileName(`${file.name.replace(/\.[^.]+$/, '')}-${kbps}k`, spec.ext)

    const output = await task.run(async ({ onProgress, onPhase, isCancelled }) => {
      onPhase(`Compressing to ${kbps} kbps…`)
      const res = await runFFmpeg({
        file,
        args: [
          '-hide_banner',
          '-y',
          '-i',
          '@in',
          ...audioOnlyArgs({ format, kbps }),
          '@out',
        ],
        output: `compressed.${spec.ext}`,
        outputType: spec.mime,
        onProgress,
        onStatus: onPhase,
      })
      if (isCancelled()) return null
      return res
    })

    if (!output) return
    setResult({
      blob: output.blob,
      url: URL.createObjectURL(output.blob),
      size: output.size,
      name: outputName,
      meta: [
        { label: 'Format', value: spec.label },
        { label: 'Bitrate', value: `${kbps} kbps` },
        { label: 'Duration', value: quick?.duration ? `${quick.duration.toFixed(1)} s` : '—' },
      ],
    })
  }

  return (
    <ToolShell
      eyebrow="Audio Tools"
      title="Audio Compressor"
      description="Reduce audio file size with a bitrate target you control. See the estimated result before encoding and the real saving after it."
      icon={Download}
      badges={[{ label: 'Bitrate control', tone: 'cyan' }]}
    >
      <ToolGrid
        main={
          <>
            <Panel className="p-5">
              <PanelHeader title="Source audio" subtitle="Any audio container the engine can decode." icon={Music} />
              <div className="mt-4">
                <FileDrop
                  accept="audio/*,.mp3,.wav,.m4a,.aac,.ogg,.opus,.flac"
                  file={file}
                  onFile={(next) => {
                    setFile(next)
                    setResult(null)
                    task.reset()
                  }}
                  title="Drop an audio file"
                  subtitle="or click to browse"
                  disabled={task.isRunning}
                />
              </div>
              <FileLimitNotice file={file} className="mt-3" />
            </Panel>

            <Panel className="p-5">
              <PanelHeader title="Compression target" subtitle="Lower bitrate means a smaller file and softer detail." icon={Download} />

              <div className="mt-5">
                <Field label="Output format">
                  <Segmented
                    value={format}
                    onChange={setFormat}
                    options={TARGETS.map((item) => ({ id: item.id, label: item.label }))}
                  />
                </Field>
              </div>

              <div className="mt-5">
                <Slider
                  label="Target bitrate"
                  value={kbps}
                  min={48}
                  max={320}
                  step={16}
                  onChange={setKbps}
                  display={`${kbps} kbps`}
                  hint="Speech is fine at 96–128 kbps. Music benefits from 192 kbps or more."
                />
              </div>

              <div className="mt-3 flex flex-wrap gap-2">
                {[64, 96, 128, 192, 256, 320].map((value) => (
                  <button
                    key={value}
                    type="button"
                    onClick={() => setKbps(value)}
                    className={`rounded-lg border px-2.5 py-1 font-mono text-[11px] transition ${
                      kbps === value
                        ? 'border-nxt-400/50 bg-nxt-500/15 text-nxt-100'
                        : 'border-white/10 bg-white/[0.03] text-slate-400 hover:border-white/20 hover:text-slate-200'
                    }`}
                  >
                    {value}k
                  </button>
                ))}
              </div>

              {saving !== null ? (
                <Notice
                  tone={saving > 0 ? 'success' : 'warning'}
                  title={saving > 0 ? `Estimated saving: ${formatBytes(saving)}` : 'This may get larger'}
                  className="mt-4"
                >
                  {saving > 0
                    ? `${Math.round(savingPercent * 100)}% smaller than the source, at ${kbps} kbps ${spec.label}.`
                    : 'The bitrate you chose is higher than the source needs. Lower it or keep the original file.'}
                </Notice>
              ) : null}

              <div className="mt-5 flex flex-wrap items-center gap-2">
                <Button size="lg" icon={Download} onClick={start} disabled={!file || task.isRunning} loading={task.isRunning}>
                  {task.isRunning ? 'Compressing…' : 'Compress audio'}
                </Button>
                {file ? (
                  <Button variant="ghost" onClick={reset} disabled={task.isRunning}>
                    Reset
                  </Button>
                ) : null}
                <Badge tone="slate" className="ml-auto">
                  {kbps} kbps
                </Badge>
              </div>

              <div className="mt-4">
                <JobStatus task={task} runningLabel="Compressing audio…" />
              </div>
            </Panel>
          </>
        }
        side={
          <>
            <Panel className="p-5">
              <PanelHeader title="Size forecast" icon={Volume2} />
              <div className="mt-4 grid grid-cols-2 gap-2">
                <Stat label="Source size" value={file ? formatBytes(file.size) : '—'} />
                <Stat label="Estimated output" value={estimatedSize ? formatBytes(estimatedSize) : '—'} />
                <Stat label="Duration" value={quick?.duration ? `${quick.duration.toFixed(1)} s` : '—'} />
                <Stat label="Target" value={`${kbps} kbps`} />
              </div>
              <div className="mt-4">
                <OutputCard result={result} originalSize={file?.size} previewKind="audio" onReset={reset} />
              </div>
            </Panel>

            <Panel className="p-5">
              <SideNote title="What compression removes">
                <p>
                  A perceptual encoder discards detail the ear is unlikely to notice — mostly very quiet high
                  frequencies. Below roughly 96 kbps the artefacts become audible on music.
                </p>
                <p>Compressing an already-compressed file stacks loss. Start from the original when possible.</p>
              </SideNote>
              <PrivacyNote className="mt-3" />
            </Panel>
          </>
        }
      />
    </ToolShell>
  )
}
