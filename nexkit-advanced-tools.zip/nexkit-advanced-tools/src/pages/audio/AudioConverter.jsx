import { useEffect, useMemo, useState } from 'react'
import { AudioLines, Music, RefreshCw } from 'lucide-react'
import { OutputCard, SideNote, ToolGrid, ToolShell } from '../../components/ToolShell'
import {
  Badge,
  Button,
  Field,
  FileDrop,
  Notice,
  Panel,
  PanelHeader,
  Segmented,
  Select,
  Slider,
  Stat,
} from '../../components/ui'
import { JobStatus } from '../../components/JobStatus'
import { FileLimitNotice, PrivacyNote } from '../../components/EngineHints'
import { useTask } from '../../lib/useTask'
import { runFFmpeg } from '../../lib/ffmpeg'
import { quickProbe } from '../../lib/mediaInfo'
import { AUDIO_FORMATS, AUDIO_QUALITY } from '../../lib/presets'
import { audioOnlyArgs } from '../../lib/encode'
import { formatBytes, safeFileName } from '../../lib/format'

export default function AudioConverter() {
  const [file, setFile] = useState(null)
  const [quick, setQuick] = useState(null)
  const [result, setResult] = useState(null)

  const [format, setFormat] = useState('m4a')
  const [quality, setQuality] = useState('standard')
  const [kbps, setKbps] = useState(192)
  const [channels, setChannels] = useState('keep')
  const [sampleRate, setSampleRate] = useState('keep')

  const task = useTask()
  const spec = AUDIO_FORMATS.find((item) => item.id === format) || AUDIO_FORMATS[0]

  useEffect(() => {
    if (!file) {
      setQuick(null)
      return undefined
    }
    let alive = true
    quickProbe(file).then((data) => alive && setQuick(data))
    return () => {
      alive = false
    }
  }, [file])

  useEffect(() => {
    return () => {
      if (result?.url) URL.revokeObjectURL(result.url)
    }
  }, [result])

  const sourceFormat = (file?.name?.split('.').pop() || '').toLowerCase()
  const lossyToLossy =
    ['mp3', 'm4a', 'aac', 'ogg', 'opus'].includes(sourceFormat) && ['mp3', 'm4a', 'aac'].includes(format)

  const estimatedSize = useMemo(() => {
    if (!quick?.duration) return null
    if (format === 'wav') return Math.round(quick.duration * 48000 * 2 * (channels === 'mono' ? 1 : 2))
    return Math.round((kbps * 1000 * quick.duration) / 8)
  }, [quick, format, kbps, channels])

  const applyQuality = (id) => {
    setQuality(id)
    const preset = AUDIO_QUALITY.find((item) => item.id === id)
    if (preset) setKbps(preset.kbps)
  }

  const reset = () => {
    if (result?.url) URL.revokeObjectURL(result.url)
    setResult(null)
    setFile(null)
    task.reset()
  }

  const start = async () => {
    if (!file) return
    if (result?.url) URL.revokeObjectURL(result.url)
    setResult(null)

    const outputName = safeFileName(`${file.name.replace(/\.[^.]+$/, '')}-converted`, spec.ext)

    const output = await task.run(async ({ onProgress, onPhase, isCancelled }) => {
      onPhase(`Converting to ${spec.label}…`)
      const res = await runFFmpeg({
        file,
        args: [
          '-hide_banner',
          '-y',
          '-i',
          '@in',
          ...audioOnlyArgs({
            format,
            kbps,
            channels: channels === 'keep' ? null : channels === 'mono' ? 1 : 2,
            sampleRate: sampleRate === 'keep' ? null : Number(sampleRate),
          }),
          '@out',
        ],
        output: `converted.${spec.ext}`,
        outputType: spec.mime,
        onProgress,
        onStatus: onPhase,
      })
      if (isCancelled()) return null
      return res
    })

    if (!output) return
    setResult({
      blob: output.blob,
      url: URL.createObjectURL(output.blob),
      size: output.size,
      name: outputName,
      meta: [
        { label: 'Format', value: spec.label },
        { label: 'Bitrate', value: format === 'wav' ? 'uncompressed' : `${kbps} kbps` },
        { label: 'Channels', value: channels === 'keep' ? 'source' : channels },
        { label: 'Sample rate', value: sampleRate === 'keep' ? 'source' : `${sampleRate} Hz` },
      ],
    })
  }

  return (
    <ToolShell
      eyebrow="Audio Tools"
      title="Audio Converter"
      description="Convert between MP3, M4A/AAC and WAV with control over bitrate, channels and sample rate. Decoding and encoding both happen in this tab."
      icon={Music}
      badges={[{ label: 'MP3 · AAC · M4A · WAV', tone: 'nxt' }]}
    >
      <ToolGrid
        main={
          <>
            <Panel className="p-5">
              <PanelHeader title="Source audio" subtitle="MP3, WAV, M4A, AAC, OGG, Opus, FLAC." icon={RefreshCw} />
              <div className="mt-4">
                <FileDrop
                  accept="audio/*,.mp3,.wav,.m4a,.aac,.ogg,.opus,.flac,.aiff"
                  file={file}
                  onFile={(next) => {
                    setFile(next)
                    setResult(null)
                    task.reset()
                  }}
                  title="Drop an audio file"
                  subtitle="or click to browse"
                  disabled={task.isRunning}
                />
              </div>
              <FileLimitNotice file={file} className="mt-3" />
            </Panel>

            <Panel className="p-5">
              <PanelHeader title="Target format" subtitle="Choose the container and quality." icon={AudioLines} />

              <div className="mt-5 grid gap-5 sm:grid-cols-2">
                <Field label="Convert to">
                  <Select
                    value={format}
                    onChange={(event) => setFormat(event.target.value)}
                    options={AUDIO_FORMATS.map((item) => ({ value: item.id, label: item.label }))}
                  />
                </Field>
                <Field label="Quality preset">
                  <Segmented
                    value={format === 'wav' ? '' : quality}
                    onChange={(value) => format !== 'wav' && applyQuality(value)}
                    size="sm"
                    options={AUDIO_QUALITY.map((item) => ({ id: item.id, label: `${item.label} ${item.kbps}` }))}
                  />
                </Field>
              </div>

              <div className="mt-5">
                <Slider
                  label="Bitrate"
                  value={kbps}
                  min={64}
                  max={320}
                  step={32}
                  onChange={(value) => {
                    setKbps(value)
                    setQuality('custom')
                  }}
                  display={format === 'wav' ? 'uncompressed' : `${kbps} kbps`}
                  disabled={format === 'wav'}
                />
              </div>

              <div className="mt-5 grid gap-5 sm:grid-cols-2">
                <Field label="Channels">
                  <Select
                    value={channels}
                    onChange={(event) => setChannels(event.target.value)}
                    options={[
                      { value: 'keep', label: 'Keep source layout' },
                      { value: 'stereo', label: 'Stereo (2)' },
                      { value: 'mono', label: 'Mono (1)' },
                    ]}
                  />
                </Field>
                <Field label="Sample rate">
                  <Select
                    value={sampleRate}
                    onChange={(event) => setSampleRate(event.target.value)}
                    options={[
                      { value: 'keep', label: 'Keep source' },
                      { value: '44100', label: '44.1 kHz' },
                      { value: '48000', label: '48 kHz' },
                    ]}
                  />
                </Field>
              </div>

              {lossyToLossy ? (
                <Notice tone="warning" title="Lossy to lossy conversion" className="mt-4">
                  The source is already compressed, so this adds a second generation of loss. Convert back to WAV only if
                  you need an uncompressed working file — otherwise keep the original for archiving.
                </Notice>
              ) : null}

              <div className="mt-5 flex flex-wrap items-center gap-2">
                <Button size="lg" icon={Music} onClick={start} disabled={!file || task.isRunning} loading={task.isRunning}>
                  {task.isRunning ? 'Converting…' : 'Convert audio'}
                </Button>
                {file ? (
                  <Button variant="ghost" onClick={reset} disabled={task.isRunning}>
                    Reset
                  </Button>
                ) : null}
                <Badge tone="slate" className="ml-auto">
                  → {spec.ext.toUpperCase()}
                </Badge>
              </div>

              <div className="mt-4">
                <JobStatus task={task} runningLabel="Converting audio…" />
              </div>
            </Panel>
          </>
        }
        side={
          <>
            <Panel className="p-5">
              <PanelHeader title="Conversion" icon={RefreshCw} />
              <div className="mt-4 grid grid-cols-2 gap-2">
                <Stat label="Source format" value={sourceFormat ? sourceFormat.toUpperCase() : '—'} />
                <Stat label="Target format" value={spec.label} />
                <Stat label="Source size" value={file ? formatBytes(file.size) : '—'} />
                <Stat label="Estimated output" value={estimatedSize ? formatBytes(estimatedSize) : '—'} />
              </div>
              <div className="mt-4">
                <OutputCard result={result} originalSize={file?.size} previewKind="audio" onReset={reset} />
              </div>
            </Panel>

            <Panel className="p-5">
              <SideNote title="Choosing a format">
                <p><span className="text-slate-200">M4A / AAC</span> — best quality per byte; standard for phones and platforms.</p>
                <p><span className="text-slate-200">MP3</span> — universal compatibility, slightly less efficient.</p>
                <p><span className="text-slate-200">WAV</span> — uncompressed 16-bit PCM, ideal before further editing.</p>
              </SideNote>
              <PrivacyNote className="mt-3" />
            </Panel>
          </>
        }
      />
    </ToolShell>
  )
}
