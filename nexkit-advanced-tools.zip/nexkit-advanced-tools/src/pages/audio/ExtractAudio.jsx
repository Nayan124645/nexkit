import { useEffect, useMemo, useState } from 'react'
import { AudioLines, Music, Volume2 } from 'lucide-react'
import { OutputCard, SideNote, ToolGrid, ToolShell } from '../../components/ToolShell'
import {
  Badge,
  Button,
  Field,
  FileDrop,
  Notice,
  Panel,
  PanelHeader,
  Segmented,
  Select,
  Slider,
  Stat,
} from '../../components/ui'
import { JobStatus } from '../../components/JobStatus'
import { FileLimitNotice, PrivacyNote, SpeedNote } from '../../components/EngineHints'
import { useTask } from '../../lib/useTask'
import { runFFmpeg } from '../../lib/ffmpeg'
import { quickProbe } from '../../lib/mediaInfo'
import { AUDIO_FORMATS, AUDIO_QUALITY } from '../../lib/presets'
import { audioOnlyArgs } from '../../lib/encode'
import { formatBytes, safeFileName } from '../../lib/format'

export default function ExtractAudio() {
  const [file, setFile] = useState(null)
  const [quick, setQuick] = useState(null)
  const [result, setResult] = useState(null)

  const [format, setFormat] = useState('mp3')
  const [quality, setQuality] = useState('standard')
  const [kbps, setKbps] = useState(192)
  const [channels, setChannels] = useState('keep')
  const [sampleRate, setSampleRate] = useState('keep')

  const task = useTask()
  const spec = AUDIO_FORMATS.find((item) => item.id === format) || AUDIO_FORMATS[0]

  useEffect(() => {
    if (!file) {
      setQuick(null)
      return undefined
    }
    let alive = true
    quickProbe(file).then((data) => alive && setQuick(data))
    return () => {
      alive = false
    }
  }, [file])

  useEffect(() => {
    return () => {
      if (result?.url) URL.revokeObjectURL(result.url)
    }
  }, [result])

  const estimatedSize = useMemo(() => {
    if (!quick?.duration) return null
    if (format === 'wav') return Math.round(quick.duration * 48000 * 2 * (channels === 'mono' ? 1 : 2))
    return Math.round((kbps * 1000 * quick.duration) / 8)
  }, [quick, format, kbps, channels])

  const applyQuality = (id) => {
    setQuality(id)
    const preset = AUDIO_QUALITY.find((item) => item.id === id)
    if (preset) setKbps(preset.kbps)
  }

  const reset = () => {
    if (result?.url) URL.revokeObjectURL(result.url)
    setResult(null)
    setFile(null)
    task.reset()
  }

  const start = async () => {
    if (!file) return
    if (result?.url) URL.revokeObjectURL(result.url)
    setResult(null)

    const outputName = safeFileName(`${file.name.replace(/\.[^.]+$/, '')}-audio`, spec.ext)

    const output = await task.run(async ({ onProgress, onPhase, isCancelled }) => {
      onPhase(`Extracting audio as ${spec.label}…`)
      const res = await runFFmpeg({
        file,
        args: [
          '-hide_banner',
          '-y',
          '-i',
          '@in',
          ...audioOnlyArgs({
            format,
            kbps,
            channels: channels === 'keep' ? null : channels === 'mono' ? 1 : 2,
            sampleRate: sampleRate === 'keep' ? null : Number(sampleRate),
          }),
          `@out`,
        ],
        output: `audio.${spec.ext}`,
        outputType: spec.mime,
        onProgress,
        onStatus: onPhase,
      })
      if (isCancelled()) return null
      return res
    })

    if (!output) return
    setResult({
      blob: output.blob,
      url: URL.createObjectURL(output.blob),
      size: output.size,
      name: outputName,
      meta: [
        { label: 'Format', value: spec.label },
        { label: 'Bitrate', value: format === 'wav' ? 'uncompressed' : `${kbps} kbps` },
        { label: 'Channels', value: channels === 'keep' ? 'unchanged' : channels },
        { label: 'Sample rate', value: sampleRate === 'keep' ? 'unchanged' : `${sampleRate} Hz` },
      ],
    })
  }

  return (
    <ToolShell
      eyebrow="Audio Tools"
      title="Extract Audio"
      description="Separate the audio track from a video and save it as MP3, M4A, AAC or WAV. Choose the bitrate and channel layout, preview the result, then download."
      icon={AudioLines}
      badges={[{ label: 'MP3 · M4A · AAC · WAV', tone: 'cyan' }]}
    >
      <ToolGrid
        main={
          <>
            <Panel className="p-5">
              <PanelHeader title="Video source" subtitle="The video stream is discarded." icon={Volume2} />
              <div className="mt-4">
                <FileDrop
                  accept="video/*,.mkv,.mov,.webm,.avi,.m4v,.mpg,.mpeg,.ts"
                  file={file}
                  onFile={(next) => {
                    setFile(next)
                    setResult(null)
                    task.reset()
                  }}
                  title="Drop a video here"
                  subtitle="or click to browse"
                  hint="Only the first audio track is extracted."
                  disabled={task.isRunning}
                />
              </div>
              <FileLimitNotice file={file} className="mt-3" />
              {quick && !quick.width ? (
                <Notice tone="info" className="mt-3">
                  This looks like an audio file already — the Audio Converter may be a better fit.
                </Notice>
              ) : null}
            </Panel>

            <Panel className="p-5">
              <PanelHeader title="Audio output" subtitle="MP3 and AAC are lossy; WAV is uncompressed." icon={Music} />

              <div className="mt-5 grid gap-5 sm:grid-cols-2">
                <Field label="Format">
                  <Select
                    value={format}
                    onChange={(event) => setFormat(event.target.value)}
                    options={AUDIO_FORMATS.map((item) => ({ value: item.id, label: item.label }))}
                  />
                </Field>
                <Field label="Quality preset" hint={format === 'wav' ? 'not used for WAV' : undefined}>
                  <Segmented
                    value={format === 'wav' ? '' : quality}
                    onChange={(value) => format !== 'wav' && applyQuality(value)}
                    size="sm"
                    options={AUDIO_QUALITY.map((item) => ({ id: item.id, label: `${item.label} ${item.kbps}` }))}
                  />
                </Field>
              </div>

              <div className="mt-5">
                <Slider
                  label="Bitrate"
                  value={kbps}
                  min={64}
                  max={320}
                  step={32}
                  onChange={(value) => {
                    setKbps(value)
                    setQuality('custom')
                  }}
                  display={format === 'wav' ? 'uncompressed' : `${kbps} kbps`}
                  disabled={format === 'wav'}
                  hint="192 kbps is transparent enough for speech and most music; 320 kbps leaves more headroom."
                />
              </div>

              <div className="mt-5 grid gap-5 sm:grid-cols-2">
                <Field label="Channels">
                  <Select
                    value={channels}
                    onChange={(event) => setChannels(event.target.value)}
                    options={[
                      { value: 'keep', label: 'Keep source layout' },
                      { value: 'stereo', label: 'Stereo (2)' },
                      { value: 'mono', label: 'Mono (1)' },
                    ]}
                  />
                </Field>
                <Field label="Sample rate">
                  <Select
                    value={sampleRate}
                    onChange={(event) => setSampleRate(event.target.value)}
                    options={[
                      { value: 'keep', label: 'Keep source' },
                      { value: '44100', label: '44.1 kHz' },
                      { value: '48000', label: '48 kHz' },
                    ]}
                  />
                </Field>
              </div>

              {format === 'wav' ? (
                <Notice tone="info" title="WAV is uncompressed" className="mt-4">
                  A WAV file is typically 10–20× larger than a 192 kbps MP3 for the same clip. Choose it only when you need
                  a lossless working file.
                </Notice>
              ) : null}

              <div className="mt-5 flex flex-wrap items-center gap-2">
                <Button size="lg" icon={AudioLines} onClick={start} disabled={!file || task.isRunning} loading={task.isRunning}>
                  {task.isRunning ? 'Extracting…' : 'Extract audio'}
                </Button>
                {file ? (
                  <Button variant="ghost" onClick={reset} disabled={task.isRunning}>
                    Reset
                  </Button>
                ) : null}
                <Badge tone="slate" className="ml-auto">
                  {spec.ext.toUpperCase()}
                </Badge>
              </div>

              <div className="mt-4">
                <JobStatus task={task} runningLabel="Extracting audio…" />
              </div>
            </Panel>
          </>
        }
        side={
          <>
            <Panel className="p-5">
              <PanelHeader title="Result" subtitle="Preview and download below." icon={Volume2} />
              <div className="mt-4 grid grid-cols-2 gap-2">
                <Stat label="Source size" value={file ? formatBytes(file.size) : '—'} />
                <Stat label="Estimated audio" value={estimatedSize ? formatBytes(estimatedSize) : '—'} />
                <Stat label="Duration" value={quick?.duration ? `${quick.duration.toFixed(1)} s` : '—'} />
                <Stat label="Format" value={spec.label} />
              </div>
              <div className="mt-4">
                <OutputCard result={result} originalSize={file?.size} previewKind="audio" onReset={reset} />
              </div>
            </Panel>

            <Panel className="p-5">
              <SideNote title="Good to know">
                <p>MP3 is the most portable choice; M4A/AAC sounds slightly better at the same bitrate.</p>
                <p>WAV stores raw PCM — perfect for editing, heavy for sharing.</p>
                <p>Multi-track videos only contribute their first audio stream.</p>
              </SideNote>
              <SpeedNote className="mt-3" />
              <PrivacyNote className="mt-3" />
            </Panel>
          </>
        }
      />
    </ToolShell>
  )
}
