import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import { Link } from 'react-router-dom'
import {
  ArrowLeft,
  Clapperboard,
  Download,
  Pause,
  Play,
  RotateCcw,
  SkipBack,
  SkipForward,
  Type,
} from 'lucide-react'
import { Badge, Button, IconButton, Notice, Panel, Progress, cx } from '../../components/ui'
import { JobStatus } from '../../components/JobStatus'
import { FileLimitNotice } from '../../components/EngineHints'
import { OutputCard } from '../../components/ToolShell'
import Timeline from './Timeline'
import MediaBin from './MediaBin'
import Inspector from './Inspector'
import {
  ASPECTS,
  addClipToTrack,
  createProject,
  duplicateClip,
  findClip,
  makeClipFromAsset,
  makeTextClip,
  projectDuration,
  projectSize,
  removeClip,
  splitClip,
  targetTrackFor,
  uid,
  updateClip,
  updateText,
} from '../../editor/model'
import { drawEmptyState, drawFrame } from '../../editor/render'
import { pauseAll, syncMedia } from '../../editor/playback'
import { ensureAudioContext } from '../../editor/audio'
import { exportProject } from '../../editor/exporter'
import { useTask } from '../../lib/useTask'
import { clamp, safeFileName } from '../../lib/format'
import { config } from '../../config'

function readAsset(src, type) {
  return new Promise((resolve) => {
    if (type === 'image') {
      const image = new Image()
      image.onload = () => resolve({ duration: 5, width: image.naturalWidth, height: image.naturalHeight })
      image.onerror = () => resolve({ duration: 5, width: 0, height: 0 })
      image.src = src
      return
    }
    const element = document.createElement(type === 'audio' ? 'audio' : 'video')
    let settled = false
    const finish = () => {
      if (settled) return
      settled = true
      resolve({
        duration: Number.isFinite(element.duration) ? element.duration : 5,
        width: element.videoWidth || 0,
        height: element.videoHeight || 0,
      })
    }
    element.preload = 'metadata'
    element.onloadedmetadata = finish
    element.onerror = finish
    setTimeout(finish, 8000)
    element.src = src
  })
}

/** One media element per clip, kept outside React and reused by preview + export. */
function useMediaPool(project) {
  const poolRef = useRef({})
  const [version, setVersion] = useState(0)
  const clips = useMemo(() => project.tracks.flatMap((track) => track.clips), [project])

  useEffect(() => {
    const current = poolRef.current
    const ids = new Set(clips.map((clip) => clip.id))

    clips.forEach((clip) => {
      if (clip.type === 'text' || !clip.src) return
      const existing = current[clip.id]
      if (existing) {
        if (existing.dataset.src === clip.src) return
        try {
          existing.pause?.()
        } catch {
          /* noop */
        }
        delete current[clip.id]
      }

      let element
      if (clip.type === 'audio') element = new Audio()
      else if (clip.type === 'image') element = new Image()
      else {
        element = document.createElement('video')
        element.playsInline = true
        element.preload = 'auto'
      }
      element.dataset.src = clip.src
      const bump = () => setVersion((value) => value + 1)
      element.addEventListener('loadeddata', bump)
      element.addEventListener('loadedmetadata', bump)
      element.addEventListener('load', bump)
      element.src = clip.src
      current[clip.id] = element
    })

    Object.keys(current).forEach((id) => {
      if (ids.has(id)) return
      try {
        current[id].pause?.()
      } catch {
        /* noop */
      }
      delete current[id]
    })
  }, [clips])

  return { pool: poolRef, version }
}

export default function EditorPage() {
  const [project, setProject] = useState(() => createProject())
  const [assets, setAssets] = useState([])
  const [importError, setImportError] = useState(null)
  const [selectedId, setSelectedId] = useState(null)
  const [playing, setPlaying] = useState(false)
  const [displayTime, setDisplayTime] = useState(0)
  const [exportResult, setExportResult] = useState(null)

  const timeRef = useRef(0)
  const canvasRef = useRef(null)
  const assetUrls = useRef([])
  const exportTask = useTask()

  const { pool, version } = useMediaPool(project)
  const duration = projectDuration(project)
  const selected = selectedId ? findClip(project, selectedId) : null
  const size = projectSize(project)
  const totalSize = assets.reduce((sum, asset) => sum + (asset.size || 0), 0)

  /* ------------------------------------------------------------- rendering */

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    canvas.width = size.width
    canvas.height = size.height
    const ctx = canvas.getContext('2d')
    const hasClips = project.tracks.some((track) => track.clips.length > 0)
    if (!hasClips) {
      drawEmptyState(ctx, project, 'Import media, then add it to the timeline')
      return
    }
    drawFrame(ctx, project, pool, timeRef.current)
  }, [project, pool, version, size.width, size.height])

  useEffect(() => {
    return () => {
      assetUrls.current.forEach((url) => URL.revokeObjectURL(url))
      if (exportResult?.url) URL.revokeObjectURL(exportResult.url)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  /* -------------------------------------------------------------- playback */

  const seek = useCallback(
    (value) => {
      const next = clamp(value, 0, Math.max(duration, 0.01))
      timeRef.current = next
      setDisplayTime(next)
      const canvas = canvasRef.current
      if (canvas && project.tracks.some((track) => track.clips.length)) {
        syncMedia(project, pool, next, false)
        drawFrame(canvas.getContext('2d'), project, pool, next)
      }
    },
    [duration, project, pool],
  )

  const togglePlay = useCallback(() => {
    if (!duration) return
    if (playing) {
      setPlaying(false)
      return
    }
    ensureAudioContext()
    if (timeRef.current >= duration - 0.02) seek(0)
    setPlaying(true)
  }, [playing, duration, seek])

  useEffect(() => {
    if (!playing) {
      pauseAll(pool)
      return undefined
    }
    let raf = 0
    let last = performance.now()
    let lastUi = 0
    const canvas = canvasRef.current
    const ctx = canvas?.getContext('2d')

    const loop = (now) => {
      const dt = Math.min(0.12, (now - last) / 1000)
      last = now
      const next = timeRef.current + dt

      if (next >= duration) {
        timeRef.current = duration
        setDisplayTime(duration)
        if (ctx) drawFrame(ctx, project, pool, duration)
        pauseAll(pool)
        setPlaying(false)
        return
      }

      timeRef.current = next
      syncMedia(project, pool, next, true)
      if (ctx) drawFrame(ctx, project, pool, next)
      if (now - lastUi > 90) {
        lastUi = now
        setDisplayTime(next)
      }
      raf = requestAnimationFrame(loop)
    }

    raf = requestAnimationFrame(loop)
    return () => {
      cancelAnimationFrame(raf)
      pauseAll(pool)
    }
  }, [playing, duration, project, pool])

  /* ---------------------------------------------------------------- media */

  const importFiles = async (files) => {
    setImportError(null)
    const accepted = []
    for (const file of files) {
      const isVideo = file.type.startsWith('video/') || /\.(mp4|mov|webm|mkv|m4v|avi)$/i.test(file.name)
      const isAudio = file.type.startsWith('audio/') || /\.(mp3|wav|m4a|aac|ogg|opus|flac)$/i.test(file.name)
      const isImage = file.type.startsWith('image/')
      if (!isVideo && !isAudio && !isImage) {
        setImportError(`“${file.name}” is not a video, image or audio file.`)
        continue
      }
      if (file.size > config.limits.maxFileMB * 1024 * 1024) {
        setImportError(`“${file.name}” is larger than the ${config.limits.maxFileMB} MB limit.`)
        continue
      }
      const type = isImage ? 'image' : isAudio ? 'audio' : 'video'
      const src = URL.createObjectURL(file)
      assetUrls.current.push(src)
      const meta = await readAsset(src, type)
      accepted.push({
        id: uid('asset'),
        name: file.name,
        type,
        src,
        duration: meta.duration,
        width: meta.width,
        height: meta.height,
        size: file.size,
      })
    }
    if (accepted.length) setAssets((prev) => [...prev, ...accepted])
  }

  const addAsset = (asset) => {
    const kind = asset.type === 'audio' ? 'audio' : 'video'
    const track = targetTrackFor(project, kind)
    const clip = makeClipFromAsset(asset, timeRef.current)
    setProject(addClipToTrack(project, track.id, clip))
    setSelectedId(clip.id)
  }

  const addResult = async (result) => {
    const type = result.type === 'audio' ? 'audio' : 'video'
    const meta = await readAsset(result.src, type)
    const asset = {
      id: uid('asset'),
      name: result.name,
      type,
      src: result.src,
      duration: meta.duration,
      width: meta.width,
      height: meta.height,
      size: result.size,
    }
    setAssets((prev) => [...prev, asset])
    addAsset(asset)
  }

  const removeAsset = (asset) => {
    setAssets((prev) => prev.filter((item) => item.id !== asset.id))
  }

  const addText = () => {
    const track = targetTrackFor(project, 'overlay')
    const clip = makeTextClip(timeRef.current)
    setProject(addClipToTrack(project, track.id, clip))
    setSelectedId(clip.id)
  }

  /* ---------------------------------------------------------------- export */

  const handleExport = async () => {
    if (!duration) return
    setPlaying(false)
    pauseAll(pool)
    if (exportResult?.url) URL.revokeObjectURL(exportResult.url)
    setExportResult(null)

    const output = await exportTask.run(async ({ onProgress, onPhase, isCancelled }) => {
      return exportProject({
        project,
        pool,
        canvas: canvasRef.current,
        onProgress,
        onPhase,
        isCancelled,
      })
    })

    if (!output?.blob) return
    setExportResult({
      blob: output.blob,
      url: URL.createObjectURL(output.blob),
      name: safeFileName(project.name || 'nexkit-timeline', 'mp4'),
      size: output.blob.size,
      meta: [
        { label: 'Resolution', value: `${size.width}×${size.height}` },
        { label: 'Frame rate', value: `${project.fps} fps` },
        { label: 'Duration', value: `${duration.toFixed(1)} s` },
        { label: 'Container', value: 'MP4 · H.264 · AAC' },
      ],
    })
    seek(0)
  }

  const resetProject = () => {
    pauseAll(pool)
    setPlaying(false)
    setProject(createProject({ aspect: project.aspect, fps: project.fps }))
    setSelectedId(null)
    timeRef.current = 0
    setDisplayTime(0)
    if (exportResult?.url) URL.revokeObjectURL(exportResult.url)
    setExportResult(null)
  }

  return (
    <div className="mx-auto w-full max-w-[1680px] px-3 pb-6 pt-4 sm:px-5 lg:px-6">
      <div className="flex flex-wrap items-center gap-2">
        <Link
          to="/"
          className="inline-flex items-center gap-1.5 rounded-lg px-2 py-1.5 text-[12px] text-slate-400 transition hover:bg-white/[0.05] hover:text-slate-200"
        >
          <ArrowLeft size={13} /> Advanced Tools
        </Link>
        <span className="text-slate-700">/</span>
        <span className="inline-flex items-center gap-1.5 text-[12.5px] font-medium text-slate-200">
          <Clapperboard size={14} className="text-nxt-300" /> Timeline Editor
        </span>
        <Badge tone="nxt" className="hidden sm:inline-flex">
          {ASPECTS.find((item) => item.id === project.aspect)?.label || project.aspect}
        </Badge>
        <Badge tone="slate" className="hidden sm:inline-flex">
          {project.fps} fps
        </Badge>

        <div className="ml-auto flex items-center gap-2">
          <Button variant="secondary" size="sm" icon={Type} onClick={addText}>
            Add text
          </Button>
          <Button variant="ghost" size="sm" icon={RotateCcw} onClick={resetProject}>
            New
          </Button>
          <Button
            size="sm"
            icon={Download}
            onClick={handleExport}
            disabled={!duration || exportTask.isRunning}
            loading={exportTask.isRunning}
          >
            {exportTask.isRunning ? 'Exporting…' : 'Export MP4'}
          </Button>
        </div>
      </div>

      <div className="mt-3 grid gap-3 lg:grid-cols-[236px_minmax(0,1fr)_296px]">
        <Panel className="order-2 h-fit p-3 lg:order-1">
          <MediaBin
            assets={assets}
            onImport={importFiles}
            onAdd={addAsset}
            onRemove={removeAsset}
            importError={importError}
            disabled={exportTask.isRunning}
            onAddResult={addResult}
          />
          <FileLimitNotice file={assets.length ? { size: Math.max(...assets.map((a) => a.size || 0)) } : null} className="mt-2" />
        </Panel>

        <div className="order-1 space-y-3 lg:order-2">
          <Panel className="overflow-hidden p-0">
            <div className="flex items-center justify-between gap-2 border-b border-white/[0.06] px-3 py-2">
              <p className="text-[10.5px] uppercase tracking-[0.16em] text-slate-500">Preview</p>
              <span className="font-mono text-[10.5px] text-slate-500">
                {size.width} × {size.height}
              </span>
            </div>

            <div className="flex items-center justify-center bg-[radial-gradient(circle_at_50%_0%,rgba(99,102,241,0.12),transparent_60%)] px-3 py-4">
              <canvas
                ref={canvasRef}
                width={size.width}
                height={size.height}
                className="max-h-[44vh] w-auto max-w-full rounded-lg bg-black shadow-[0_20px_60px_-30px_rgba(0,0,0,0.9)]"
              />
            </div>

            <div className="flex flex-wrap items-center gap-2 border-t border-white/[0.06] px-3 py-2">
              <IconButton label="Go to start" icon={SkipBack} onClick={() => seek(0)} />
              <button
                type="button"
                onClick={togglePlay}
                disabled={!duration}
                aria-label={playing ? 'Pause' : 'Play'}
                className={cx(
                  'grid h-10 w-10 place-items-center rounded-full border border-white/15 text-white transition',
                  'bg-gradient-to-br from-nxt-500 to-cyanic-500 shadow-[0_10px_30px_-12px_rgba(79,70,229,0.9)]',
                  'disabled:opacity-40',
                )}
              >
                {playing ? <Pause size={16} /> : <Play size={16} className="ml-0.5" />}
              </button>
              <IconButton label="Go to end" icon={SkipForward} onClick={() => seek(duration)} />
              <span className="ml-1 font-mono text-[11.5px] text-slate-400">
                {displayTime.toFixed(2)} / {duration.toFixed(2)} s
              </span>
              <span className="ml-auto text-[10.5px] text-slate-600">
                {project.tracks.reduce((sum, track) => sum + track.clips.length, 0)} clips ·{' '}
                {project.tracks.length} tracks
              </span>
            </div>
          </Panel>

          {exportTask.status !== 'idle' ? (
            <Panel className="p-3">
              <JobStatus task={exportTask} runningLabel="Exporting timeline…" />
              {exportTask.status === 'running' ? (
                <p className="mt-2 text-[10.5px] leading-relaxed text-slate-500">
                  Export renders in real time, so a {duration.toFixed(0)}s timeline takes about{' '}
                  {duration.toFixed(0)}s, plus MP4 encoding. Keep this tab in the foreground.
                </p>
              ) : null}
            </Panel>
          ) : null}

          {exportResult ? (
            <Panel className="p-4">
              <OutputCard
                result={exportResult}
                onReset={() => {
                  if (exportResult?.url) URL.revokeObjectURL(exportResult.url)
                  setExportResult(null)
                }}
                note="Timeline exported to MP4. Download it, or hand it straight to TikTok Studio."
              />
            </Panel>
          ) : null}

          {!assets.length && !duration ? (
            <Notice tone="neutral" title="Build your first cut">
              Import a video, image or audio file on the left, then press the plus button to place it on the timeline.
              Drag clips to move them, drag their edges to trim, and use the scissors to split at the playhead.
            </Notice>
          ) : null}
        </div>

        <Panel className="order-3 h-fit p-3.5">
          <Inspector
            project={project}
            clip={selected?.clip || null}
            time={displayTime}
            onProjectChange={setProject}
            onClipChange={(patch) => selected && setProject(updateClip(project, selected.clip.id, patch))}
            onTextChange={(patch) => selected && setProject(updateText(project, selected.clip.id, patch))}
            onSplit={() => {
              if (!selected) return
              const next = splitClip(project, selected.clip.id, displayTime)
              setProject(next)
            }}
            onDuplicate={() => {
              if (!selected) return
              setProject(duplicateClip(project, selected.clip.id))
            }}
            onDelete={() => {
              if (!selected) return
              setProject(removeClip(project, selected.clip.id))
              setSelectedId(null)
            }}
            assetCount={project.tracks.reduce((sum, track) => sum + track.clips.length, 0)}
            duration={duration}
            totalSize={totalSize}
          />
        </Panel>
      </div>

      <div className="mt-3">
        <Timeline
          project={project}
          time={displayTime}
          duration={Math.max(duration, 1)}
          selectedId={selectedId}
          onSelect={setSelectedId}
          onSeek={seek}
          onProjectChange={setProject}
          playing={playing}
        />
      </div>
    </div>
  )
}
