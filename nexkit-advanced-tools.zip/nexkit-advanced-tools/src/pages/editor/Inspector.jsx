import { Copy, Scissors, Sparkles, Trash2 } from 'lucide-react'
import {
  Badge,
  Button,
  Divider,
  Field,
  Input,
  Notice,
  Segmented,
  Select,
  Slider,
  Textarea,
} from '../../components/ui'
import { ASPECTS, FPS_OPTIONS } from '../../editor/model'
import { formatBytes } from '../../lib/format'

export default function Inspector({
  project,
  clip,
  time,
  onProjectChange,
  onClipChange,
  onTextChange,
  onSplit,
  onDuplicate,
  onDelete,
  assetCount,
  duration,
  totalSize,
}) {
  if (!clip) {
    return (
      <div className="space-y-4">
        <div>
          <p className="text-[10.5px] uppercase tracking-[0.16em] text-slate-500">Project</p>
          <p className="mt-1 text-[13px] text-slate-300">Select a clip to edit it, or change the canvas below.</p>
        </div>

        <Field label="Aspect ratio">
          <Select
            value={project.aspect}
            onChange={(event) => onProjectChange({ ...project, aspect: event.target.value })}
            options={ASPECTS.map((item) => ({ value: item.id, label: item.label }))}
          />
        </Field>

        <Field label="Frame rate">
          <Segmented
            value={project.fps}
            onChange={(value) => onProjectChange({ ...project, fps: value })}
            options={FPS_OPTIONS.map((value) => ({ id: value, label: `${value}` }))}
            size="sm"
          />
        </Field>

        <Field label="Project name">
          <Input
            value={project.name}
            onChange={(event) => onProjectChange({ ...project, name: event.target.value })}
            maxLength={60}
          />
        </Field>

        <Divider />

        <div className="grid grid-cols-2 gap-2 text-[11.5px]">
          <div className="rounded-xl border border-white/[0.07] bg-white/[0.025] px-3 py-2">
            <p className="text-[10px] uppercase tracking-[0.12em] text-slate-500">Clips</p>
            <p className="mt-0.5 font-mono text-slate-200">{assetCount}</p>
          </div>
          <div className="rounded-xl border border-white/[0.07] bg-white/[0.025] px-3 py-2">
            <p className="text-[10px] uppercase tracking-[0.12em] text-slate-500">Duration</p>
            <p className="mt-0.5 font-mono text-slate-200">{duration.toFixed(1)}s</p>
          </div>
          <div className="col-span-2 rounded-xl border border-white/[0.07] bg-white/[0.025] px-3 py-2">
            <p className="text-[10px] uppercase tracking-[0.12em] text-slate-500">Source media size</p>
            <p className="mt-0.5 font-mono text-slate-200">{formatBytes(totalSize)}</p>
          </div>
        </div>

        <Notice tone="neutral" title="How editing works here">
          <ul className="space-y-1.5">
            <li>• Import media, then add it to the timeline at the playhead.</li>
            <li>• Drag clips to move, drag their edges to trim.</li>
            <li>• Split with the scissors, add text from the toolbar.</li>
            <li>• Export renders the canvas in real time, then encodes MP4.</li>
          </ul>
        </Notice>
      </div>
    )
  }

  const isText = clip.type === 'text'
  const hasAudio = clip.type === 'video' || clip.type === 'audio'
  const maxDuration = isText || clip.type === 'image' ? 120 : Math.max(0.2, (clip.sourceDuration || clip.duration) - (clip.trimIn || 0))
  const maxTrim = Math.max(0, (clip.sourceDuration || clip.duration) - clip.duration)

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between gap-2">
        <div className="min-w-0">
          <p className="text-[10.5px] uppercase tracking-[0.16em] text-slate-500">Selected clip</p>
          <p className="truncate text-[13px] font-medium text-slate-100">{clip.name}</p>
        </div>
        <Badge tone={isText ? 'wagle' : clip.type === 'audio' ? 'cyan' : 'nxt'}>{clip.type}</Badge>
      </div>

      {isText ? (
        <>
          <Field label="Text">
            <Textarea
              value={clip.text?.content || ''}
              rows={3}
              maxLength={280}
              onChange={(event) => onTextChange({ content: event.target.value })}
            />
          </Field>
          <Slider
            label="Font size"
            value={clip.text?.size || 72}
            min={24}
            max={180}
            step={2}
            onChange={(value) => onTextChange({ size: value })}
            display={`${clip.text?.size || 72}px`}
          />
          <div className="grid grid-cols-2 gap-3">
            <Field label="Colour">
              <input
                type="color"
                value={clip.text?.color || '#ffffff'}
                onChange={(event) => onTextChange({ color: event.target.value })}
                className="h-10 w-full cursor-pointer rounded-xl border border-white/10 bg-ink-900/70 p-1"
              />
            </Field>
            <Field label="Alignment">
              <Segmented
                value={clip.text?.align || 'center'}
                onChange={(value) => onTextChange({ align: value })}
                options={[
                  { id: 'left', label: 'L' },
                  { id: 'center', label: 'C' },
                  { id: 'right', label: 'R' },
                ]}
                size="sm"
              />
            </Field>
          </div>
          <Field label="Position">
            <Segmented
              value={clip.text?.position || 'bottom'}
              onChange={(value) => onTextChange({ position: value })}
              options={[
                { id: 'top', label: 'Top' },
                { id: 'middle', label: 'Middle' },
                { id: 'bottom', label: 'Bottom' },
              ]}
              size="sm"
            />
          </Field>
          <Field label="Background box">
            <Segmented
              value={clip.text?.bg ? 'on' : 'off'}
              onChange={(value) => onTextChange({ bg: value === 'on' })}
              options={[
                { id: 'on', label: 'On' },
                { id: 'off', label: 'Off' },
              ]}
              size="sm"
            />
          </Field>
        </>
      ) : (
        <>
          <Slider
            label="Duration"
            value={Math.min(clip.duration, maxDuration)}
            min={0.2}
            max={Math.min(120, Math.max(maxDuration, 1))}
            step={0.1}
            onChange={(value) => onClipChange({ duration: value })}
            display={`${clip.duration.toFixed(2)} s`}
          />
          {!isText && clip.type !== 'image' ? (
            <Slider
              label="Start offset in source"
              value={clip.trimIn || 0}
              min={0}
              max={Math.max(0.1, maxTrim)}
              step={0.05}
              onChange={(value) => onClipChange({ trimIn: value, start: clip.start })}
              display={`${(clip.trimIn || 0).toFixed(2)} s`}
              hint="Move the usable part of the clip without changing its position on the timeline."
            />
          ) : null}
        </>
      )}

      {clip.type !== 'text' ? (
        <>
          <Field label="Framing">
            <Segmented
              value={clip.fit}
              onChange={(value) => onClipChange({ fit: value })}
              options={[
                { id: 'cover', label: 'Fill frame' },
                { id: 'contain', label: 'Fit inside' },
              ]}
              size="sm"
            />
          </Field>
          <Slider
            label="Scale"
            value={clip.scale || 1}
            min={0.3}
            max={2.5}
            step={0.01}
            onChange={(value) => onClipChange({ scale: value })}
            display={`${(clip.scale * 100).toFixed(0)}%`}
          />
          <div className="grid grid-cols-2 gap-3">
            <Slider
              label="Position X"
              value={clip.offsetX || 0}
              min={-0.5}
              max={0.5}
              step={0.01}
              onChange={(value) => onClipChange({ offsetX: value })}
              display={`${((clip.offsetX || 0) * 100).toFixed(0)}%`}
            />
            <Slider
              label="Position Y"
              value={clip.offsetY || 0}
              min={-0.5}
              max={0.5}
              step={0.01}
              onChange={(value) => onClipChange({ offsetY: value })}
              display={`${((clip.offsetY || 0) * 100).toFixed(0)}%`}
            />
          </div>
        </>
      ) : null}

      {hasAudio ? (
        <Slider
          label="Volume"
          value={clip.volume ?? 1}
          min={0}
          max={1}
          step={0.01}
          onChange={(value) => onClipChange({ volume: value })}
          display={`${Math.round((clip.volume ?? 1) * 100)}%`}
        />
      ) : null}

      <div className="grid grid-cols-2 gap-3">
        <Slider
          label="Fade in"
          value={clip.fadeIn || 0}
          min={0}
          max={Math.max(0.2, Math.min(3, clip.duration / 2))}
          step={0.05}
          onChange={(value) => onClipChange({ fadeIn: value })}
          display={`${(clip.fadeIn || 0).toFixed(2)}s`}
        />
        <Slider
          label="Fade out"
          value={clip.fadeOut || 0}
          min={0}
          max={Math.max(0.2, Math.min(3, clip.duration / 2))}
          step={0.05}
          onChange={(value) => onClipChange({ fadeOut: value })}
          display={`${(clip.fadeOut || 0).toFixed(2)}s`}
        />
      </div>

      <p className="text-[10.5px] leading-relaxed text-slate-500">
        Clip starts at {clip.start.toFixed(2)}s and ends at {(clip.start + clip.duration).toFixed(2)}s. Fades are alpha
        ramps used as crossfades between overlapping clips.
      </p>

      <Divider />

      <div className="grid grid-cols-2 gap-2">
        <Button size="sm" variant="secondary" icon={Scissors} onClick={onSplit}>
          Split at playhead
        </Button>
        <Button size="sm" variant="secondary" icon={Copy} onClick={onDuplicate}>
          Duplicate
        </Button>
        <Button size="sm" variant="danger" icon={Trash2} onClick={onDelete} className="col-span-2">
          Delete clip
        </Button>
      </div>

      {time > clip.start + clip.duration ? (
        <Notice tone="neutral" icon={Sparkles}>
          The playhead is outside this clip. Move it inside to split.
        </Notice>
      ) : null}
    </div>
  )
}
