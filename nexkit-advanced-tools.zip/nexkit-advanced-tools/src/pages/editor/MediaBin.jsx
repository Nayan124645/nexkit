import { useEffect, useRef, useState } from 'react'
import { Image as ImageIcon, Music, Plus, Trash2, Upload, Video, WandSparkles } from 'lucide-react'
import { Button, IconBadge, Notice, cx } from '../../components/ui'
import { listResults, subscribeResults } from '../../lib/results'
import { formatBytes } from '../../lib/format'

const ICONS = { video: Video, audio: Music, image: ImageIcon }

function AssetRow({ asset, onAdd, onRemove, tone = 'nxt' }) {
  const Icon = ICONS[asset.type] || Video
  return (
    <div className="group flex items-center gap-2 rounded-xl border border-white/[0.07] bg-white/[0.025] p-2">
      <IconBadge icon={Icon} tone={tone} size="sm" />
      <div className="min-w-0 flex-1">
        <p className="truncate text-[11.5px] font-medium text-slate-200">{asset.name}</p>
        <p className="font-mono text-[10px] text-slate-500">
          {asset.duration ? `${asset.duration.toFixed(1)}s` : '—'}
          {asset.size ? ` · ${formatBytes(asset.size)}` : ''}
        </p>
      </div>
      <button
        type="button"
        onClick={() => onAdd(asset)}
        aria-label={`Add ${asset.name} to timeline`}
        className="grid h-7 w-7 shrink-0 place-items-center rounded-lg border border-white/10 text-slate-400 transition hover:border-nxt-400/40 hover:bg-nxt-500/15 hover:text-white"
      >
        <Plus size={13} />
      </button>
      {onRemove ? (
        <button
          type="button"
          onClick={() => onRemove(asset)}
          aria-label={`Remove ${asset.name}`}
          className="grid h-7 w-7 shrink-0 place-items-center rounded-lg text-slate-600 transition hover:text-rose-300"
        >
          <Trash2 size={12} />
        </button>
      ) : null}
    </div>
  )
}

export default function MediaBin({ assets, onImport, onAdd, onRemove, importError, disabled, onAddResult }) {
  const inputRef = useRef(null)
  const [dragging, setDragging] = useState(false)
  const [results, setResults] = useState(() => listResults())

  useEffect(() => subscribeResults(setResults), [])

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <p className="text-[10.5px] uppercase tracking-[0.16em] text-slate-500">Media</p>
        <Button size="sm" variant="secondary" icon={Upload} onClick={() => inputRef.current?.click()} disabled={disabled}>
          Import
        </Button>
      </div>

      <input
        ref={inputRef}
        type="file"
        multiple
        accept="video/*,audio/*,image/*"
        className="sr-only"
        onChange={(event) => {
          onImport(Array.from(event.target.files || []))
          event.target.value = ''
        }}
      />

      <div
        onDragOver={(event) => {
          event.preventDefault()
          setDragging(true)
        }}
        onDragLeave={() => setDragging(false)}
        onDrop={(event) => {
          event.preventDefault()
          setDragging(false)
          onImport(Array.from(event.dataTransfer.files || []))
        }}
        onClick={() => !disabled && inputRef.current?.click()}
        className={cx(
          'cursor-pointer rounded-xl border-2 border-dashed px-3 py-5 text-center transition',
          dragging ? 'border-nxt-400/60 bg-nxt-500/10' : 'border-white/10 bg-white/[0.02] hover:border-white/20',
        )}
      >
        <p className="text-[11.5px] font-medium text-slate-300">Drop video, image or audio</p>
        <p className="mt-0.5 text-[10.5px] text-slate-500">or click to import</p>
      </div>

      {importError ? <Notice tone="danger">{importError}</Notice> : null}

      {assets.length ? (
        <div className="space-y-1.5">
          {assets.map((asset) => (
            <AssetRow key={asset.id} asset={asset} onAdd={onAdd} onRemove={onRemove} />
          ))}
        </div>
      ) : (
        <p className="rounded-xl border border-white/[0.06] bg-white/[0.02] px-3 py-4 text-center text-[11px] text-slate-500">
          No media yet. Import a clip to start building.
        </p>
      )}

      {results.length ? (
        <div className="space-y-1.5">
          <p className="flex items-center gap-1.5 text-[10.5px] uppercase tracking-[0.16em] text-slate-500">
            <WandSparkles size={11} /> From other tools
          </p>
          {results.slice(0, 4).map((item) => (
            <AssetRow
              key={item.id}
              asset={{ id: item.id, name: item.name, type: item.kind === 'audio' ? 'audio' : 'video', src: item.url, duration: null, size: item.size }}
              tone="wagle"
              onAdd={(asset) => onAddResult(asset)}
            />
          ))}
        </div>
      ) : null}
    </div>
  )
}
