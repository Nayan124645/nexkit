import { useMemo, useRef, useState } from 'react'
import {
  Copy,
  Layers,
  Music,
  Plus,
  Scissors,
  Trash2,
  Type,
  Volume2,
  VolumeX,
  ZoomIn,
  ZoomOut,
} from 'lucide-react'
import { IconButton, cx } from '../../components/ui'
import {
  addTrack,
  duplicateClip,
  removeClip,
  removeTrack,
  setTrackMuted,
  splitClip,
  updateClip,
} from '../../editor/model'
import { formatTimecode, snapTime, tickStep } from '../../editor/timelineMath'
import { clamp } from '../../lib/format'

const BASE_PPS = 26

const TRACK_ACCENT = {
  video: 'from-nxt-500/35 to-nxt-500/10 border-nxt-400/30',
  overlay: 'from-wagle-400/30 to-wagle-400/10 border-wagle-400/30',
  audio: 'from-cyanic-400/30 to-cyanic-400/10 border-cyanic-400/30',
}

const TRACK_ICON = { video: Layers, overlay: Type, audio: Music }

function ClipBlock({ clip, pps, selected, onSelect, onChange, project, laneRef }) {
  const startDrag = (event, mode) => {
    event.stopPropagation()
    onSelect(clip.id)
    if (event.button !== 0 && event.pointerType === 'mouse') return
    const startX = event.clientX
    const origin = { start: clip.start, duration: clip.duration, trimIn: clip.trimIn }
    const maxDuration =
      (clip.sourceDuration ?? 600) - (clip.trimIn || 0) > 0.1
        ? (clip.sourceDuration ?? 600) - (clip.trimIn || 0)
        : 600

    const move = (moveEvent) => {
      const delta = (moveEvent.clientX - startX) / pps
      if (mode === 'move') {
        onChange(updateClip(project, clip.id, { start: Math.max(0, snapTime(origin.start + delta)) }))
        return
      }
      if (mode === 'left') {
        const maxLeft = origin.duration - 0.1
        const d = clamp(delta, -(origin.trimIn || 0), maxLeft)
        onChange(
          updateClip(project, clip.id, {
            start: Math.max(0, origin.start + d),
            trimIn: (origin.trimIn || 0) + d,
            duration: origin.duration - d,
          }),
        )
        return
      }
      const d = clamp(delta, -origin.duration + 0.1, maxDuration - origin.duration)
      onChange(updateClip(project, clip.id, { duration: Math.max(0.1, origin.duration + d) }))
    }

    const up = () => {
      window.removeEventListener('pointermove', move)
      window.removeEventListener('pointerup', up)
      window.removeEventListener('pointercancel', up)
    }
    window.addEventListener('pointermove', move)
    window.addEventListener('pointerup', up)
    window.addEventListener('pointercancel', up)
  }

  return (
    <div
      onPointerDown={(event) => startDrag(event, 'move')}
      className={cx(
        'group absolute top-1.5 flex h-[calc(100%-12px)] select-none items-center overflow-hidden rounded-lg border bg-gradient-to-br px-2',
        TRACK_ACCENT[clip.type === 'text' ? 'overlay' : clip.type === 'audio' ? 'audio' : 'video'],
        selected ? 'ring-2 ring-white/70' : 'hover:border-white/40',
      )}
      style={{
        left: clip.start * pps,
        width: Math.max(10, clip.duration * pps),
        touchAction: 'none',
      }}
      title={`${clip.name} · ${clip.duration.toFixed(2)}s`}
    >
      <span
        role="separator"
        onPointerDown={(event) => startDrag(event, 'left')}
        className="absolute inset-y-0 left-0 w-2 cursor-ew-resize bg-white/0 hover:bg-white/25"
        style={{ touchAction: 'none' }}
      />
      <span className="pointer-events-none truncate text-[10.5px] font-medium text-white/90">{clip.name}</span>
      <span
        role="separator"
        onPointerDown={(event) => startDrag(event, 'right')}
        className="absolute inset-y-0 right-0 w-2 cursor-ew-resize bg-white/0 hover:bg-white/25"
        style={{ touchAction: 'none' }}
      />
    </div>
  )
}

export default function Timeline({
  project,
  time,
  duration,
  selectedId,
  onSelect,
  onSeek,
  onProjectChange,
  playing,
}) {
  const [zoom, setZoom] = useState(1)
  const lanesRef = useRef(null)
  const pps = BASE_PPS * zoom
  const laneWidth = Math.max(600, duration * pps + 120)
  const step = tickStep(zoom)

  const ticks = useMemo(() => {
    const count = Math.ceil(laneWidth / (step * pps)) + 1
    return Array.from({ length: count }, (_, index) => index * step)
  }, [laneWidth, step, pps])

  const seekFromEvent = (event) => {
    const rect = lanesRef.current?.getBoundingClientRect()
    if (!rect) return
    const x = event.clientX - rect.left
    onSeek(clamp(x / pps, 0, Math.max(duration, 0.1)))
  }

  const selectedClip = selectedId
    ? project.tracks.flatMap((track) => track.clips).find((clip) => clip.id === selectedId)
    : null

  return (
    <div className="rounded-2xl border border-white/[0.07] bg-ink-900/60 p-3">
      <div className="mb-2 flex flex-wrap items-center gap-1.5">
        <span className="mr-1 font-mono text-[11px] text-slate-500">
          {formatTimecode(time, project.fps)} / {formatTimecode(duration, project.fps)}
        </span>
        <div className="ml-auto flex items-center gap-1.5">
          <IconButton
            label="Split selected clip at playhead"
            icon={Scissors}
            disabled={!selectedClip}
            onClick={() => selectedId && onProjectChange(splitClip(project, selectedId, time))}
          />
          <IconButton
            label="Duplicate selected clip"
            icon={Copy}
            disabled={!selectedClip}
            onClick={() => selectedId && onProjectChange(duplicateClip(project, selectedId))}
          />
          <IconButton
            label="Delete selected clip"
            icon={Trash2}
            disabled={!selectedClip}
            onClick={() => {
              if (!selectedId) return
              onProjectChange(removeClip(project, selectedId))
              onSelect(null)
            }}
          />
          <span className="mx-1 h-5 w-px bg-white/10" />
          <IconButton label="Add video track" icon={Plus} onClick={() => onProjectChange(addTrack(project, 'video'))} />
          <IconButton label="Add text overlay track" icon={Type} onClick={() => onProjectChange(addTrack(project, 'overlay'))} />
          <IconButton label="Add audio track" icon={Music} onClick={() => onProjectChange(addTrack(project, 'audio'))} />
          <span className="mx-1 h-5 w-px bg-white/10" />
          <IconButton label="Zoom out" icon={ZoomOut} onClick={() => setZoom((value) => Math.max(0.4, value / 1.35))} />
          <IconButton label="Zoom in" icon={ZoomIn} onClick={() => setZoom((value) => Math.min(6, value * 1.35))} />
        </div>
      </div>

      <div className="overflow-x-auto rounded-xl border border-white/[0.06] bg-ink-950/60">
        <div className="relative" style={{ width: 104 + laneWidth }}>
          {/* Ruler */}
          <div className="flex border-b border-white/[0.06]">
            <div className="sticky left-0 z-10 w-[104px] shrink-0 bg-ink-950/95 px-2 py-1.5 text-[10px] uppercase tracking-[0.12em] text-slate-600">
              Tracks
            </div>
            <div
              ref={lanesRef}
              className="relative h-7 flex-1 cursor-pointer"
              style={{ width: laneWidth }}
              onPointerDown={seekFromEvent}
            >
              {ticks.map((tick) => (
                <span
                  key={tick}
                  className="absolute top-0 h-full border-l border-white/[0.08] pl-1 font-mono text-[9.5px] leading-7 text-slate-600"
                  style={{ left: tick * pps }}
                >
                  {formatTimecode(tick, project.fps)}
                </span>
              ))}
            </div>
          </div>

          {/* Tracks */}
          {project.tracks.map((track) => {
            const Icon = TRACK_ICON[track.kind] || Layers
            const sameKind = project.tracks.filter((item) => item.kind === track.kind).length
            return (
              <div key={track.id} className="flex border-b border-white/[0.05] last:border-0">
                <div className="sticky left-0 z-10 flex w-[104px] shrink-0 items-center gap-1 bg-ink-950/95 px-2 py-2">
                  <Icon size={12} className="shrink-0 text-slate-500" />
                  <span className="min-w-0 flex-1 truncate text-[10.5px] text-slate-400">{track.name}</span>
                  <button
                    type="button"
                    aria-label={track.muted ? `Unmute ${track.name}` : `Mute ${track.name}`}
                    onClick={() => onProjectChange(setTrackMuted(project, track.id, !track.muted))}
                    className={cx(
                      'grid h-5 w-5 shrink-0 place-items-center rounded',
                      track.muted ? 'text-rose-300' : 'text-slate-600 hover:text-slate-300',
                    )}
                  >
                    {track.muted ? <VolumeX size={11} /> : <Volume2 size={11} />}
                  </button>
                  {sameKind > 1 ? (
                    <button
                      type="button"
                      aria-label={`Remove ${track.name}`}
                      onClick={() => onProjectChange(removeTrack(project, track.id))}
                      className="grid h-5 w-5 shrink-0 place-items-center rounded text-slate-700 hover:text-rose-300"
                    >
                      <Trash2 size={10} />
                    </button>
                  ) : null}
                </div>
                <div
                  className="timeline-lane relative h-14 flex-1"
                  style={{ width: laneWidth, ['--lane-step']: `${pps}px` }}
                  onPointerDown={(event) => {
                    if (event.target === event.currentTarget) onSelect(null)
                  }}
                >
                  {track.clips.map((clip) => (
                    <ClipBlock
                      key={clip.id}
                      clip={clip}
                      pps={pps}
                      project={project}
                      selected={clip.id === selectedId}
                      onSelect={onSelect}
                      onChange={onProjectChange}
                    />
                  ))}
                </div>
              </div>
            )
          })}

          {/* Playhead */}
          <div
            className="pointer-events-none absolute top-0 z-20 w-px bg-gradient-to-b from-rose-400 to-rose-500/40"
            style={{ left: 104 + time * pps, height: '100%' }}
          >
            <span className="absolute -left-1 top-0 h-2 w-2 rounded-full bg-rose-400 shadow-[0_0_8px_rgba(251,113,133,0.8)]" />
          </div>
        </div>
      </div>

      <p className="mt-2 text-[10.5px] text-slate-600">
        Drag a clip to move it · drag its edges to trim · click the ruler to scrub · {playing ? 'playing' : 'paused'}
      </p>
    </div>
  )
}
