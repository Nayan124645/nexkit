import { useEffect, useMemo, useState } from 'react'
import { useLocation } from 'react-router-dom'
import {
  AlertTriangle,
  ArrowUpRight,
  Check,
  Clipboard,
  ExternalLink,
  KeyRound,
  Link2,
  ListChecks,
  Send,
  ShieldCheck,
  Sparkles,
  Unplug,
  Upload,
  Video,
} from 'lucide-react'
import { SideNote, ToolShell } from '../../components/ToolShell'
import {
  Badge,
  Button,
  Checkbox,
  Field,
  FileDrop,
  IconBadge,
  Input,
  Notice,
  Panel,
  PanelHeader,
  Select,
  Stat,
  Textarea,
  cx,
} from '../../components/ui'
import { JobStatus } from '../../components/JobStatus'
import { PrivacyNote } from '../../components/EngineHints'
import { useTask } from '../../lib/useTask'
import { copyText } from '../../lib/files'
import { downloadBlob } from '../../lib/files'
import { listResults, subscribeResults } from '../../lib/results'
import { config, tiktokManualUploadUrl } from '../../config'
import { formatBytes } from '../../lib/format'
import {
  TIKTOK_LIMITS,
  TIKTOK_PRIVACY,
  checkService,
  connectUrl,
  disconnect,
  fetchAccount,
  fetchCreatorInfo,
  isBackendConfigured,
  pollStatus,
  publishVideo,
  statusLabel,
} from '../../lib/tiktok'

function ConnectionPanel({ service, account, onRefresh, busy }) {
  if (!isBackendConfigured) {
    return (
      <Panel className="p-5">
        <PanelHeader
          title="Connect TikTok"
          subtitle="Publishing needs a small server component that holds your TikTok credentials."
          icon={Link2}
          action={<Badge tone="warning">Not configured</Badge>}
        />
        <Notice tone="warning" title="The publishing service is not configured" className="mt-4">
          Direct publishing and draft upload use TikTok&apos;s official Content Posting API, which requires an approved
          developer app and a server to keep the client secret out of the browser. Set{' '}
          <code className="rounded bg-black/40 px-1 py-0.5 font-mono text-[11px]">VITE_TIKTOK_API_BASE</code> and deploy{' '}
          <code className="rounded bg-black/40 px-1 py-0.5 font-mono text-[11px]">/server</code> to enable it.
        </Notice>
        <div className="mt-4 rounded-xl border border-white/[0.07] bg-white/[0.02] p-4">
          <p className="text-[12px] font-medium text-slate-200">What still works right now</p>
          <ul className="mt-2 space-y-1.5 text-[11.5px] leading-relaxed text-slate-400">
            <li>• Prepare the video and caption here.</li>
            <li>• Download the file with one click.</li>
            <li>• Copy the caption and hashtags.</li>
            <li>• Open TikTok Studio&apos;s upload page and finish there.</li>
          </ul>
        </div>
      </Panel>
    )
  }

  if (account) {
    return (
      <Panel className="p-5">
        <PanelHeader
          title="TikTok account"
          subtitle="Authorised through TikTok OAuth. NeXkiT never sees your password."
          icon={ShieldCheck}
          action={<Badge tone="success">Connected</Badge>}
        />
        <div className="mt-4 flex items-center gap-3 rounded-xl border border-emerald-400/20 bg-emerald-500/[0.05] p-3.5">
          {account.avatarUrl ? (
            <img src={account.avatarUrl} alt="" className="h-11 w-11 rounded-full object-cover" />
          ) : (
            <IconBadge icon={Video} tone="slate" />
          )}
          <div className="min-w-0 flex-1">
            <p className="truncate text-[13px] font-medium text-slate-100">{account.displayName || account.username}</p>
            <p className="truncate font-mono text-[11px] text-slate-400">@{account.username || 'unknown'}</p>
          </div>
          <div className="hidden gap-4 text-right sm:flex">
            <div>
              <p className="text-[10px] uppercase tracking-[0.12em] text-slate-500">Followers</p>
              <p className="font-mono text-[12px] text-slate-200">{account.followerCount ?? '—'}</p>
            </div>
            <div>
              <p className="text-[10px] uppercase tracking-[0.12em] text-slate-500">Videos</p>
              <p className="font-mono text-[12px] text-slate-200">{account.videoCount ?? '—'}</p>
            </div>
          </div>
        </div>
        <div className="mt-3 flex flex-wrap gap-2">
          <Button variant="secondary" size="sm" icon={KeyRound} onClick={onRefresh} loading={busy}>
            Refresh account
          </Button>
          <Button
            variant="danger"
            size="sm"
            icon={Unplug}
            onClick={async () => {
              await disconnect().catch(() => {})
              onRefresh()
            }}
          >
            Disconnect
          </Button>
        </div>
        <p className="mt-3 text-[11px] leading-relaxed text-slate-500">
          Disconnecting removes the stored access token on the server. To revoke app access completely, use TikTok →
          Settings → Security &amp; permissions → Manage app permissions.
        </p>
      </Panel>
    )
  }

  return (
    <Panel className="p-5">
      <PanelHeader
        title="Connect TikTok"
        subtitle="Official OAuth — the authorisation screen is hosted by TikTok."
        icon={Link2}
        action={<Badge tone="slate">Not connected</Badge>}
      />
      <div className="mt-4 space-y-2.5 text-[12px] leading-relaxed text-slate-400">
        <p>
          Publishing requires two scopes: <span className="font-mono text-[11px] text-slate-300">video.publish</span> for
          direct posting and <span className="font-mono text-[11px] text-slate-300">video.upload</span> for drafts. Your
          app must be approved for them in the TikTok developer portal.
        </p>
        <p>We never ask for your TikTok password and never read browser cookies or sessions.</p>
      </div>
      {service.state === 'unreachable' ? (
        <Notice tone="danger" title="The publishing service is unreachable" className="mt-4">
          {service.error}
        </Notice>
      ) : null}
      <Button
        as="a"
        href={connectUrl() || '#'}
        icon={ExternalLink}
        className="mt-4 w-full"
        disabled={service.state !== 'ready'}
      >
        {service.state === 'ready' ? 'Connect TikTok account' : 'Service unavailable'}
      </Button>
      {service.state === 'ready' && service.configured === false ? (
        <Notice tone="warning" title="Server is running without TikTok credentials" className="mt-3">
          The service answered, but TIKTOK_CLIENT_KEY / TIKTOK_CLIENT_SECRET are missing on the server. Add them and
          restart it.
        </Notice>
      ) : null}
    </Panel>
  )
}

export default function TikTokStudio() {
  const location = useLocation()
  const [service, setService] = useState({ state: isBackendConfigured ? 'checking' : 'unconfigured' })
  const [account, setAccount] = useState(null)
  const [accountBusy, setAccountBusy] = useState(false)

  const [video, setVideo] = useState(null)
  const [caption, setCaption] = useState('')
  const [hashtagInput, setHashtagInput] = useState('')
  const [hashtags, setHashtags] = useState([])
  const [privacy, setPrivacy] = useState('PUBLIC_TO_EVERYONE')
  const [allowComments, setAllowComments] = useState(true)
  const [allowDuet, setAllowDuet] = useState(true)
  const [allowStitch, setAllowStitch] = useState(true)
  const [mode, setMode] = useState('direct')
  const [confirmed, setConfirmed] = useState(false)
  const [results, setResults] = useState(() => listResults())
  const [copied, setCopied] = useState(false)
  const [publishState, setPublishState] = useState(null)

  const task = useTask()

  const fullCaption = useMemo(() => {
    const tags = hashtags.map((tag) => (tag.startsWith('#') ? tag : `#${tag}`)).join(' ')
    return [caption.trim(), tags].filter(Boolean).join(' ').trim()
  }, [caption, hashtags])

  useEffect(() => subscribeResults(setResults), [])

  const refreshAccount = async () => {
    if (!isBackendConfigured) return
    setAccountBusy(true)
    try {
      const me = await fetchAccount()
      setAccount(me)
    } catch {
      setAccount(null)
    } finally {
      setAccountBusy(false)
    }
  }

  useEffect(() => {
    if (!isBackendConfigured) return
    let alive = true
    checkService().then((state) => alive && setService(state))
    fetchAccount()
      .then((me) => alive && setAccount(me))
      .catch(() => {})
    return () => {
      alive = false
    }
  }, [])

  useEffect(() => {
    const params = new URLSearchParams(location.search)
    if (params.get('connected') === '1') {
      refreshAccount()
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [location.search])

  useEffect(() => {
    if (!account) return
    fetchCreatorInfo()
      .then((payload) => {
        const options = payload?.creatorInfo?.privacyLevelOptions
        if (Array.isArray(options) && options.length && !options.includes(privacy)) {
          setPrivacy(options[0])
        }
      })
      .catch(() => {})
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [account])

  const addHashtag = () => {
    const raw = hashtagInput.trim().replace(/^#/, '').replace(/\s+/g, '')
    if (!raw) return
    if (hashtags.length >= TIKTOK_LIMITS.hashtags) return
    if (!hashtags.includes(raw)) setHashtags((prev) => [...prev, raw])
    setHashtagInput('')
  }

  const pickResult = (item) => {
    if (item.type && !item.type.startsWith('video/')) return
    setVideo({
      file: new File([item.blob], item.name, { type: item.type || 'video/mp4' }),
      name: item.name,
      size: item.size,
      url: item.url,
      fromResult: true,
    })
    setPublishState(null)
  }

  const canPublish = Boolean(account && video && fullCaption.length > 0 && confirmed && !task.isRunning)

  const doPublish = async () => {
    if (!canPublish) return
    setPublishState(null)
    const meta = {
      caption: fullCaption,
      privacyLevel: privacy,
      disableComment: !allowComments,
      disableDuet: !allowDuet,
      disableStitch: !allowStitch,
    }

    const outcome = await task.run(async ({ onProgress, onPhase, isCancelled }) => {
      onPhase(
        mode === 'direct'
          ? 'Sending to TikTok for direct publishing…'
          : 'Sending to TikTok as a draft…',
      )
      const response = await publishVideo({
        file: video.file,
        meta,
        mode,
        onProgress,
        isCancelled,
      })
      onProgress(0.65)
      onPhase('TikTok is processing the upload…')
      const final = await pollStatus(response.publishId, { onPhase, isCancelled })
      return { publishId: response.publishId, status: final?.status, message: final?.message, postIds: final?.postIds }
    })

    if (outcome) setPublishState(outcome)
  }

  const copyCaption = async () => {
    const ok = await copyText(fullCaption)
    setCopied(ok)
    setTimeout(() => setCopied(false), 1800)
  }

  const publishBusy = task.isRunning

  return (
    <ToolShell
      eyebrow="TikTok Studio"
      title="TikTok Studio"
      description="Prepare the post, then publish through TikTok's official Content Posting API — or hand the finished video and caption to TikTok Studio manually. No browser automation, no password collection, no unofficial tricks."
      icon={Sparkles}
      tone="wagle"
      badges={[
        { label: 'Official API', tone: 'wagle' },
        { label: 'OAuth', tone: 'slate' },
        { label: isBackendConfigured ? 'Service configured' : 'Manual mode', tone: isBackendConfigured ? 'success' : 'warning' },
      ]}
    >
      <div className="grid gap-5 lg:grid-cols-[minmax(0,1.35fr)_minmax(0,1fr)]">
        <div className="space-y-5">
          <ConnectionPanel service={service} account={account} onRefresh={refreshAccount} busy={accountBusy} />

          <Panel className="p-5">
            <PanelHeader
              title="1 · Video"
              subtitle="Pick something you processed in this session, or upload a file from disk."
              icon={Video}
            />

            {results.length ? (
              <div className="mt-4 space-y-2">
                <p className="text-[10.5px] uppercase tracking-[0.16em] text-slate-500">From this session</p>
                {results.map((item) => {
                  const active = video?.url === item.url
                  const isVideo = !item.type || item.type.startsWith('video/')
                  return (
                    <button
                      key={item.id}
                      type="button"
                      disabled={!isVideo}
                      onClick={() => pickResult(item)}
                      className={cx(
                        'flex w-full items-center justify-between gap-3 rounded-xl border p-3 text-left transition',
                        active
                          ? 'border-wagle-400/40 bg-wagle-400/[0.08]'
                          : 'border-white/10 bg-white/[0.025] hover:border-white/20',
                        !isVideo && 'opacity-45',
                      )}
                    >
                      <span className="min-w-0">
                        <span className="block truncate text-[12px] text-slate-200">{item.name}</span>
                        <span className="font-mono text-[10.5px] text-slate-500">
                          {formatBytes(item.size)} · {item.source === 'editor' ? 'editor export' : 'processed file'}
                        </span>
                      </span>
                      {active ? <Check size={14} className="shrink-0 text-wagle-300" /> : null}
                    </button>
                  )
                })}
              </div>
            ) : (
              <p className="mt-4 rounded-xl border border-white/[0.07] bg-white/[0.02] px-3 py-3 text-[11.5px] text-slate-500">
                Nothing processed yet in this session. Use the WAGLE Method or the editor first, or upload a file below.
              </p>
            )}

            <div className="mt-4">
              <FileDrop
                accept="video/*,.mp4,.mov,.webm,.mkv"
                file={video?.fromResult ? null : video?.file || null}
                onFile={(file) => {
                  if (!file) {
                    setVideo(null)
                    return
                  }
                  setVideo({
                    file,
                    name: file.name,
                    size: file.size,
                    url: URL.createObjectURL(file),
                  })
                  setPublishState(null)
                }}
                title="Upload the video to publish"
                subtitle="MP4 recommended · max 4 GB"
                compact
                disabled={publishBusy}
              />
            </div>

            {video ? (
              <div className="mt-4 grid gap-3 sm:grid-cols-[minmax(0,160px)_minmax(0,1fr)]">
                <video
                  key={video.url}
                  src={video.url}
                  controls
                  playsInline
                  className="max-h-[220px] w-full rounded-xl border border-white/10 bg-black object-contain"
                />
                <div className="grid grid-cols-2 gap-2 self-start">
                  <Stat label="File" value={video.name} mono={false} />
                  <Stat label="Size" value={formatBytes(video.size)} />
                  <Stat label="Destination" value={mode === 'direct' ? 'Direct post' : 'Draft'} />
                  <Stat label="Privacy" value={TIKTOK_PRIVACY.find((item) => item.id === privacy)?.label || privacy} />
                </div>
              </div>
            ) : null}
          </Panel>

          <Panel className="p-5">
            <PanelHeader title="2 · Post details" subtitle="Caption, hashtags and interaction settings." icon={ListChecks} />

            <div className="mt-4 space-y-4">
              <Field label="Caption" hint={`${fullCaption.length} / ${TIKTOK_LIMITS.caption}`}>
                <Textarea
                  rows={4}
                  value={caption}
                  maxLength={TIKTOK_LIMITS.caption}
                  onChange={(event) => setCaption(event.target.value)}
                  placeholder="Write the caption for your post…"
                />
              </Field>

              <Field label="Hashtags" hint={`${hashtags.length} / ${TIKTOK_LIMITS.hashtags}`}>
                <div className="flex gap-2">
                  <Input
                    value={hashtagInput}
                    onChange={(event) => setHashtagInput(event.target.value)}
                    onKeyDown={(event) => {
                      if (event.key === 'Enter' || event.key === ',' || event.key === ' ') {
                        event.preventDefault()
                        addHashtag()
                      }
                    }}
                    placeholder="fyp"
                  />
                  <Button variant="secondary" onClick={addHashtag} type="button">
                    Add
                  </Button>
                </div>
              </Field>

              {hashtags.length ? (
                <div className="flex flex-wrap gap-1.5">
                  {hashtags.map((tag) => (
                    <button
                      key={tag}
                      type="button"
                      onClick={() => setHashtags((prev) => prev.filter((item) => item !== tag))}
                      className="rounded-full border border-white/10 bg-white/[0.05] px-2.5 py-1 text-[11px] text-slate-300 transition hover:border-rose-400/30 hover:text-rose-200"
                      title="Remove"
                    >
                      #{tag} ×
                    </button>
                  ))}
                </div>
              ) : null}

              <div className="grid gap-4 sm:grid-cols-2">
                <Field label="Who can watch" hint={account ? 'as allowed by your account' : 'applies on publish'}>
                  <Select
                    value={privacy}
                    onChange={(event) => setPrivacy(event.target.value)}
                    options={TIKTOK_PRIVACY.map((item) => ({ value: item.id, label: item.label }))}
                  />
                </Field>
                <div className="space-y-2">
                  <Checkbox
                    checked={allowComments}
                    onChange={setAllowComments}
                    label="Allow comments"
                    hint="TikTok may override this for under-18 accounts."
                  />
                </div>
              </div>

              <div className="grid gap-2 sm:grid-cols-2">
                <Checkbox checked={allowDuet} onChange={setAllowDuet} label="Allow Duet" />
                <Checkbox checked={allowStitch} onChange={setAllowStitch} label="Allow Stitch" />
              </div>

              <div className="flex flex-wrap items-center gap-2">
                <Button variant="secondary" size="sm" icon={Clipboard} onClick={copyCaption} disabled={!fullCaption}>
                  {copied ? 'Copied' : 'Copy caption'}
                </Button>
                <Button
                  variant="secondary"
                  size="sm"
                  icon={Upload}
                  onClick={() => video && downloadBlob(video.file, video.name)}
                  disabled={!video}
                >
                  Download video
                </Button>
                <Button
                  as="a"
                  href={tiktokManualUploadUrl}
                  target="_blank"
                  rel="noreferrer noopener"
                  variant="ghost"
                  size="sm"
                  icon={ArrowUpRight}
                >
                  Open TikTok upload
                </Button>
              </div>
            </div>
          </Panel>

          <Panel className="p-5">
            <PanelHeader
              title="3 · Publish"
              subtitle="Direct post publishes immediately; draft upload leaves the post in your TikTok inbox."
              icon={Send}
            />

            <div className="mt-4 space-y-3">
              <div className="grid gap-2 sm:grid-cols-2">
                {[
                  {
                    id: 'direct',
                    title: 'Direct post',
                    body: 'Publishes to your profile using the video.publish scope.',
                    scope: 'video.publish',
                  },
                  {
                    id: 'draft',
                    title: 'Upload as draft',
                    body: 'Sends the file to your TikTok inbox so you can finish editing in the app.',
                    scope: 'video.upload',
                  },
                ].map((option) => (
                  <button
                    key={option.id}
                    type="button"
                    onClick={() => setMode(option.id)}
                    className={cx(
                      'rounded-xl border p-3.5 text-left transition',
                      mode === option.id
                        ? 'border-wagle-400/40 bg-wagle-400/[0.08]'
                        : 'border-white/10 bg-white/[0.025] hover:border-white/20',
                    )}
                  >
                    <span className="flex items-center justify-between gap-2">
                      <span className="text-[12.5px] font-medium text-slate-100">{option.title}</span>
                      <span className="font-mono text-[10px] text-slate-500">{option.scope}</span>
                    </span>
                    <span className="mt-1 block text-[11px] leading-relaxed text-slate-400">{option.body}</span>
                  </button>
                ))}
              </div>

              <Checkbox
                checked={confirmed}
                onChange={setConfirmed}
                label="I confirm I have the rights to publish this video"
                hint="Publishing is an explicit action: nothing is sent until you press the button below."
              />

              {!account ? (
                <Notice tone="warning" title="Connect an account to enable publishing">
                  Without a connected TikTok account and an approved app, direct publishing is unavailable. Everything
                  above still works for a manual upload.
                </Notice>
              ) : null}

              {service.state === 'ready' && service.configured === false ? (
                <Notice tone="warning" title="Server credentials missing">
                  The publishing service is running but has no TikTok client credentials configured.
                </Notice>
              ) : null}

              <div className="flex flex-wrap items-center gap-2">
                <Button
                  size="lg"
                  variant="wagle"
                  icon={Send}
                  onClick={doPublish}
                  disabled={!canPublish}
                  loading={publishBusy}
                >
                  {publishBusy ? 'Publishing…' : mode === 'direct' ? 'Publish to TikTok' : 'Send draft to TikTok'}
                </Button>
                <Badge tone="slate">{mode === 'direct' ? 'video.publish' : 'video.upload'}</Badge>
                {!isBackendConfigured ? <Badge tone="warning">manual mode</Badge> : null}
              </div>

              <JobStatus task={task} runningLabel="Working with TikTok…" tone="wagle" />

              {publishState ? (
                <Notice
                  tone={publishState.status === 'FAILED' ? 'danger' : 'success'}
                  title={
                    publishState.status === 'PUBLISH_COMPLETE'
                      ? 'Published to TikTok'
                      : publishState.status === 'SEND_TO_USER_INBOX'
                        ? 'Draft delivered to your TikTok inbox'
                        : publishState.status === 'FAILED'
                          ? 'TikTok could not complete the post'
                          : 'TikTok is still processing'
                  }
                  icon={publishState.status === 'FAILED' ? AlertTriangle : Check}
                >
                  <p>{publishState.message || statusLabel(publishState.status)}</p>
                  <p className="mt-1 font-mono text-[10.5px] text-slate-400">publish_id: {publishState.publishId}</p>
                  {publishState.postIds?.length ? (
                    <p className="mt-1 font-mono text-[10.5px] text-slate-400">
                      post id: {publishState.postIds.join(', ')}
                    </p>
                  ) : null}
                </Notice>
              ) : null}
            </div>
          </Panel>
        </div>

        <div className="space-y-5">
          <Panel className="p-5">
            <PanelHeader title="Post summary" icon={Sparkles} />
            <div className="mt-3 space-y-1.5">
              {[
                { label: 'Account', value: account ? `@${account.username || 'connected'}` : 'not connected' },
                { label: 'Video', value: video ? formatBytes(video.size) : 'none selected' },
                { label: 'Caption', value: fullCaption ? `${fullCaption.length} chars` : 'empty' },
                { label: 'Privacy', value: TIKTOK_PRIVACY.find((item) => item.id === privacy)?.label || privacy },
                { label: 'Publishing', value: isBackendConfigured ? 'official API' : 'manual handoff' },
              ].map((row) => (
                <div key={row.label} className="flex items-baseline justify-between gap-3 border-b border-white/[0.05] py-1.5 last:border-0">
                  <span className="text-[12px] text-slate-500">{row.label}</span>
                  <span className="text-right font-mono text-[11.5px] text-slate-200">{row.value}</span>
                </div>
              ))}
            </div>
          </Panel>

          <Panel className="p-5">
            <PanelHeader title="Manual upload" subtitle="Always available, even without API approval." icon={ExternalLink} />
            <ol className="mt-3 space-y-2.5 text-[11.5px] leading-relaxed text-slate-400">
              <li>
                <span className="font-mono text-slate-300">1.</span> Prepare the file with the{' '}
                <a href="#/wagle" className="text-wagle-300 underline decoration-wagle-300/40 underline-offset-2">
                  WAGLE Method
                </a>
                .
              </li>
              <li>
                <span className="font-mono text-slate-300">2.</span> Download the video and copy the caption above.
              </li>
              <li>
                <span className="font-mono text-slate-300">3.</span> Open TikTok Studio&apos;s upload page and post it
                there.
              </li>
            </ol>
            <Button
              as="a"
              href={tiktokManualUploadUrl}
              target="_blank"
              rel="noreferrer noopener"
              variant="secondary"
              icon={ExternalLink}
              className="mt-4 w-full"
            >
              Open TikTok Studio upload
            </Button>
          </Panel>

          <Panel className="p-5">
            <PanelHeader title="Requirements for direct publishing" icon={ShieldCheck} />
            <ul className="mt-3 space-y-2 text-[11.5px] leading-relaxed text-slate-400">
              <li>• A TikTok developer app approved for <span className="font-mono text-slate-300">video.publish</span> and/or <span className="font-mono text-slate-300">video.upload</span>.</li>
              <li>• A deployed backend holding the client secret (never in this bundle).</li>
              <li>• A public HTTPS origin registered as the OAuth redirect URI.</li>
              <li>• Until TikTok audits your app, every post is forced to private viewing.</li>
              <li>• Rate limit: 6 publish/status requests per minute per user token.</li>
            </ul>
            <div className="mt-4 rounded-xl border border-white/[0.07] bg-white/[0.02] p-3">
              <p className="text-[11px] font-medium text-slate-300">Current API base</p>
              <p className="mt-1 break-all font-mono text-[10.5px] text-slate-500">
                {config.tiktokApiBase || 'not set — manual mode'}
              </p>
            </div>
          </Panel>

          <Panel className="p-5">
            <SideNote title="Privacy and limits">
              <p>No credentials, cookies or session tokens are read from your browser. The server stores only the OAuth tokens it needs.</p>
              <p>Video files travel only to TikTok, through our own service, at the moment you press publish.</p>
            </SideNote>
            <PrivacyNote className="mt-3" />
          </Panel>
        </div>
      </div>
    </ToolShell>
  )
}
