import { useEffect, useMemo, useState } from 'react'
import { Crop, Gauge, Sparkles, Zap } from 'lucide-react'
import { ToolGrid, OutputCard, SideNote, ToolShell } from '../../components/ToolShell'
import { FileDrop } from '../../components/ui'
import {
  Badge,
  Button,
  Field,
  Notice,
  Panel,
  PanelHeader,
  Segmented,
  Select,
  Slider,
  Stat,
} from '../../components/ui'
import { JobStatus } from '../../components/JobStatus'
import { FileLimitNotice, PrivacyNote, SpeedNote } from '../../components/EngineHints'
import { useTask } from '../../lib/useTask'
import { runFFmpeg } from '../../lib/ffmpeg'
import { quickProbe, estimateVideoKbps, estimateSizeBytes } from '../../lib/mediaInfo'
import {
  QUALITY_PRESETS,
  RESOLUTIONS,
  SPEED_PRESETS,
  even,
  scaleFilterForHeight,
} from '../../lib/presets'
import { audioEncoderArgs, videoEncoderArgs } from '../../lib/encode'
import { formatBytes, safeFileName } from '../../lib/format'

export default function Compressor() {
  const [file, setFile] = useState(null)
  const [quick, setQuick] = useState(null)
  const [result, setResult] = useState(null)

  const [resolution, setResolution] = useState('1080p')
  const [quality, setQuality] = useState('balanced')
  const [mode, setMode] = useState('quality')
  const [crf, setCrf] = useState(23)
  const [targetKbps, setTargetKbps] = useState(8000)
  const [audioKbps, setAudioKbps] = useState(160)
  const [speed, setSpeed] = useState('veryfast')

  const task = useTask()

  useEffect(() => {
    if (!file) {
      setQuick(null)
      return undefined
    }
    let alive = true
    quickProbe(file).then((info) => {
      if (alive) setQuick(info)
    })
    return () => {
      alive = false
    }
  }, [file])

  useEffect(() => {
    return () => {
      if (result?.url) URL.revokeObjectURL(result.url)
    }
  }, [result])

  const resolutionPreset = RESOLUTIONS.find((item) => item.id === resolution) || RESOLUTIONS[0]

  const target = useMemo(() => {
    if (!quick?.width || !quick?.height) return null
    if (resolution === 'source') return { width: quick.width, height: quick.height }
    const height = even(resolutionPreset.height)
    return { width: even((quick.width * height) / quick.height), height }
  }, [quick, resolution, resolutionPreset])

  const upscaling = Boolean(target && quick?.height && target.height > quick.height)

  const estimatedKbps = useMemo(() => {
    if (!target) return null
    if (mode === 'bitrate') return targetKbps
    return estimateVideoKbps({
      width: target.width,
      height: target.height,
      fps: quick?.fps || 30,
      crf,
    })
  }, [mode, target, targetKbps, quick, crf])

  const estimatedSize = useMemo(() => {
    if (!estimatedKbps || !quick?.duration) return null
    return estimateSizeBytes({ videoKbps: estimatedKbps, audioKbps, duration: quick.duration })
  }, [estimatedKbps, audioKbps, quick])

  const applyQuality = (id) => {
    setQuality(id)
    const preset = QUALITY_PRESETS.find((item) => item.id === id)
    if (preset && id !== 'custom') {
      setCrf(preset.crf)
      setAudioKbps(preset.audioKbps)
    }
  }

  const reset = () => {
    if (result?.url) URL.revokeObjectURL(result.url)
    setResult(null)
    setFile(null)
    task.reset()
  }

  const start = async () => {
    if (!file) return
    if (result?.url) URL.revokeObjectURL(result.url)
    setResult(null)

    const outputName = safeFileName(`${file.name.replace(/\.[^.]+$/, '')}-compressed`, 'mp4')
    const filters = resolution === 'source' ? [] : [scaleFilterForHeight(resolutionPreset.height)]

    const output = await task.run(async ({ onProgress, onPhase, isCancelled }) => {
      onPhase('Encoding MP4 with H.264…')
      const res = await runFFmpeg({
        file,
        args: [
          '-hide_banner',
          '-y',
          '-i',
          '@in',
          ...videoEncoderArgs({
            crf,
            targetKbps: mode === 'bitrate' ? targetKbps : null,
            speed,
            filters,
          }),
          ...audioEncoderArgs({ kbps: audioKbps }),
          '@out',
        ],
        output: 'compressed.mp4',
        outputType: 'video/mp4',
        onProgress,
        onStatus: onPhase,
      })
      if (isCancelled()) return null
      return res
    })

    if (!output) return
    setResult({
      blob: output.blob,
      url: URL.createObjectURL(output.blob),
      size: output.size,
      name: outputName,
      meta: [
        { label: 'Resolution', value: target ? `${target.width}×${target.height}` : 'source' },
        { label: 'Codec', value: 'H.264 / AAC' },
        { label: 'Mode', value: mode === 'bitrate' ? `${targetKbps} kbps` : `CRF ${crf}` },
        { label: 'Preset', value: speed },
      ],
    })
  }

  const runDisabled = !file || task.isRunning

  return (
    <ToolShell
      eyebrow="Video Tools"
      title="Video Compressor"
      description="Reduce file size with H.264 in an MP4 container. Pick a resolution, control quality with CRF or a target bitrate, and see the estimated output size before you start."
      icon={Gauge}
      badges={[{ label: 'MP4', tone: 'nxt' }, { label: 'H.264', tone: 'slate' }]}
    >
      <ToolGrid
        main={
          <>
            <Panel className="p-5">
              <PanelHeader
                title="Source file"
                subtitle="MP4, MOV, WebM, MKV — anything the engine can decode."
                icon={Zap}
              />
              <div className="mt-4">
                <FileDrop
                  accept="video/*,.mkv,.mov,.webm,.avi,.m4v,.mpg,.mpeg,.ts"
                  file={file}
                  onFile={(next) => {
                    setFile(next)
                    setResult(null)
                    task.reset()
                  }}
                  title="Drop a video here"
                  subtitle="or click to browse"
                  hint="Processed locally. Your file never leaves this browser."
                  disabled={task.isRunning}
                />
              </div>
              <FileLimitNotice file={file} className="mt-3" />
            </Panel>

            <Panel className="p-5">
              <PanelHeader title="Encoding settings" subtitle="Everything below is applied by NXT Core." icon={Sparkles} />

              <div className="mt-5 grid gap-5 sm:grid-cols-2">
                <Field label="Resolution" hint={resolution === 'source' ? 'unchanged' : resolutionPreset.note}>
                  <Select
                    value={resolution}
                    onChange={(event) => setResolution(event.target.value)}
                    options={RESOLUTIONS.map((item) => ({
                      value: item.id,
                      label: item.id === 'source' ? 'Source resolution' : `${item.label} — ${item.note}`,
                    }))}
                  />
                </Field>

                <Field label="Quality preset" hint={QUALITY_PRESETS.find((q) => q.id === quality)?.note}>
                  <Select
                    value={quality}
                    onChange={(event) => applyQuality(event.target.value)}
                    options={QUALITY_PRESETS.map((item) => ({ value: item.id, label: item.label }))}
                  />
                </Field>
              </div>

              <div className="mt-5">
                <Field label="Rate control">
                  <Segmented
                    value={mode}
                    onChange={setMode}
                    options={[
                      { id: 'quality', label: 'Constant quality (CRF)' },
                      { id: 'bitrate', label: 'Target bitrate' },
                    ]}
                  />
                </Field>
              </div>

              <div className="mt-5 space-y-5">
                {mode === 'quality' ? (
                  <Slider
                    label="CRF — lower is better quality"
                    value={crf}
                    min={16}
                    max={34}
                    step={1}
                    onChange={(value) => {
                      setCrf(value)
                      setQuality('custom')
                    }}
                    display={`CRF ${crf}`}
                    hint="18 ≈ visually near-lossless · 23 balanced · 28 small. CRF adapts the bitrate per scene."
                  />
                ) : (
                  <Slider
                    label="Target video bitrate"
                    value={targetKbps}
                    min={500}
                    max={30000}
                    step={250}
                    onChange={setTargetKbps}
                    display={`${(targetKbps / 1000).toFixed(1)} Mbps`}
                    hint="Constant-ish bitrate with a capped peak. Use this when a platform specifies a number."
                  />
                )}

                <Slider
                  label="Audio bitrate"
                  value={audioKbps}
                  min={64}
                  max={320}
                  step={32}
                  onChange={setAudioKbps}
                  display={`${audioKbps} kbps AAC`}
                />

                <Field label="Encoder speed" hint="Faster presets trade a little detail for time">
                  <Segmented
                    value={speed}
                    onChange={setSpeed}
                    options={SPEED_PRESETS.map((item) => ({ id: item.id, label: item.label }))}
                  />
                </Field>
              </div>

              {upscaling ? (
                <Notice tone="warning" title="This preset upscales the source" className="mt-5">
                  The source is {quick.width}×{quick.height}, so encoding at {target.height}p adds pixels but no new
                  detail. Choose a lower preset, or source resolution, for a better result.
                </Notice>
              ) : null}

              <div className="mt-5 flex flex-wrap items-center gap-2">
                <Button size="lg" icon={Gauge} onClick={start} disabled={runDisabled} loading={task.isRunning}>
                  {task.isRunning ? 'Compressing…' : 'Compress video'}
                </Button>
                {file ? (
                  <Button variant="ghost" onClick={reset} disabled={task.isRunning}>
                    Reset
                  </Button>
                ) : null}
                <span className="ml-auto flex items-center gap-2">
                  {resolution !== 'source' ? <Badge tone="slate">{resolutionPreset.label}</Badge> : null}
                  <Badge tone="slate">{mode === 'bitrate' ? 'CBR target' : `CRF ${crf}`}</Badge>
                </span>
              </div>

              <div className="mt-4">
                <JobStatus task={task} runningLabel="Compressing…" />
              </div>
            </Panel>
          </>
        }
        side={
          <>
            <Panel className="p-5">
              <PanelHeader title="Output estimate" subtitle="Before encoding — based on duration and settings." icon={Crop} />
              <div className="mt-4 grid grid-cols-2 gap-2">
                <Stat label="Source size" value={file ? formatBytes(file.size) : '—'} />
                <Stat
                  label="Estimated output"
                  value={estimatedSize ? formatBytes(estimatedSize) : '—'}
                  hint={estimatedKbps ? `≈ ${(estimatedKbps / 1000).toFixed(1)} Mbps video` : undefined}
                />
                <Stat
                  label="Target resolution"
                  value={target ? `${target.width} × ${target.height}` : '—'}
                  hint={quick?.aspect ? `source ${quick.aspect}` : undefined}
                />
                <Stat label="Duration" value={quick?.duration ? `${quick.duration.toFixed(1)} s` : '—'} />
              </div>

              {estimatedSize && file ? (
                <p className="mt-3 text-[11.5px] leading-relaxed text-slate-500">
                  Estimated saving:{' '}
                  <span className={estimatedSize < file.size ? 'text-emerald-300' : 'text-amber-300'}>
                    {formatBytes(Math.abs(file.size - estimatedSize))}{' '}
                    {estimatedSize < file.size ? 'smaller' : 'larger'}
                  </span>
                  . Real output depends on scene complexity; estimates are typically within 20%.
                </p>
              ) : null}

              <div className="mt-4">
                <OutputCard result={result} originalSize={file?.size} onReset={reset} />
              </div>
            </Panel>

            <Panel className="p-5">
              <SideNote title="What this tool does">
                <p>Re-encodes the video stream with libx264 inside an MP4 container and keeps the aspect ratio intact.</p>
                <p>Audio is converted to AAC at the bitrate you choose. Subtitles and data streams are dropped.</p>
                <p>HDR sources are tone-mapped by the encoder — use the WAGLE Method if you need HDR-aware handling.</p>
              </SideNote>
              <SpeedNote className="mt-3" />
              <PrivacyNote className="mt-3" />
            </Panel>
          </>
        }
      />
    </ToolShell>
  )
}
