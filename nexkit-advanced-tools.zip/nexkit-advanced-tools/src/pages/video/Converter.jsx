import { useEffect, useState } from 'react'
import { Film, RefreshCw, Sparkles } from 'lucide-react'
import { OutputCard, SideNote, ToolGrid, ToolShell } from '../../components/ToolShell'
import {
  Badge,
  Button,
  Field,
  FileDrop,
  Notice,
  Panel,
  PanelHeader,
  Segmented,
  Select,
  Slider,
  Stat,
} from '../../components/ui'
import { JobStatus } from '../../components/JobStatus'
import { FileLimitNotice, PrivacyNote, SpeedNote } from '../../components/EngineHints'
import { useTask } from '../../lib/useTask'
import { runFFmpeg } from '../../lib/ffmpeg'
import { quickProbe } from '../../lib/mediaInfo'
import { QUALITY_PRESETS, SPEED_PRESETS } from '../../lib/presets'
import { audioEncoderArgs, videoEncoderArgs } from '../../lib/encode'
import { formatBytes, safeFileName } from '../../lib/format'

const SUPPORTED = ['mp4', 'mov', 'm4v', 'webm', 'mkv', 'avi', 'mpg', 'mpeg', 'ts', 'mts', '3gp', 'ogv', 'flv']

const CODECS = [
  { id: 'h264', label: 'H.264 (AVC) — most compatible' },
  { id: 'hevc', label: 'H.265 (HEVC) — experimental' },
  { id: 'copy', label: 'Copy streams — remux only' },
]

export default function Converter() {
  const [file, setFile] = useState(null)
  const [quick, setQuick] = useState(null)
  const [result, setResult] = useState(null)

  const [codec, setCodec] = useState('h264')
  const [quality, setQuality] = useState('balanced')
  const [crf, setCrf] = useState(23)
  const [audioMode, setAudioMode] = useState('aac')
  const [audioKbps, setAudioKbps] = useState(160)
  const [speed, setSpeed] = useState('veryfast')

  const task = useTask()

  useEffect(() => {
    if (!file) {
      setQuick(null)
      return undefined
    }
    let alive = true
    quickProbe(file).then((info) => alive && setQuick(info))
    return () => {
      alive = false
    }
  }, [file])

  useEffect(() => {
    return () => {
      if (result?.url) URL.revokeObjectURL(result.url)
    }
  }, [result])

  const extension = file?.name?.split('.').pop()?.toLowerCase() || ''
  const extensionLooksOdd = Boolean(extension) && !SUPPORTED.includes(extension)

  const applyQuality = (id) => {
    setQuality(id)
    const preset = QUALITY_PRESETS.find((item) => item.id === id)
    if (preset && id !== 'custom') {
      setCrf(preset.crf)
      setAudioKbps(preset.audioKbps)
    }
  }

  const reset = () => {
    if (result?.url) URL.revokeObjectURL(result.url)
    setResult(null)
    setFile(null)
    task.reset()
  }

  const start = async () => {
    if (!file) return
    if (result?.url) URL.revokeObjectURL(result.url)
    setResult(null)

    const outputName = safeFileName(`${file.name.replace(/\.[^.]+$/, '')}-nexkit`, 'mp4')

    const output = await task.run(async ({ onProgress, onPhase, isCancelled }) => {
      onPhase(codec === 'copy' ? 'Remuxing into MP4 (no re-encode)…' : 'Transcoding to MP4…')

      const encoderArgs =
        codec === 'copy'
          ? ['-c:v', 'copy']
          : codec === 'hevc'
            ? ['-c:v', 'libx265', '-preset', speed, '-crf', String(crf), '-pix_fmt', 'yuv420p', '-tag:v', 'hvc1']
            : videoEncoderArgs({ crf, speed })

      const audioArgs =
        audioMode === 'none'
          ? ['-an']
          : audioMode === 'copy'
            ? ['-c:a', 'copy']
            : audioEncoderArgs({ kbps: audioKbps })

      const res = await runFFmpeg({
        file,
        args: ['-hide_banner', '-y', '-i', '@in', ...encoderArgs, ...audioArgs, '-movflags', '+faststart', '@out'],
        output: 'converted.mp4',
        outputType: 'video/mp4',
        onProgress,
        onStatus: onPhase,
      })
      if (isCancelled()) return null
      return res
    })

    if (!output) return
    setResult({
      blob: output.blob,
      url: URL.createObjectURL(output.blob),
      size: output.size,
      name: outputName,
      meta: [
        { label: 'Container', value: 'MP4' },
        {
          label: 'Video',
          value: codec === 'copy' ? 'copied (untouched)' : codec === 'hevc' ? 'H.265 / HEVC' : `H.264 CRF ${crf}`,
        },
        { label: 'Audio', value: audioMode === 'none' ? 'removed' : audioMode === 'copy' ? 'copied' : `AAC ${audioKbps}k` },
        { label: 'Faststart', value: 'enabled' },
      ],
    })
  }

  return (
    <ToolShell
      eyebrow="Video Tools"
      title="Video Converter"
      description="Turn MOV, WebM, MKV and other containers into a clean MP4 that plays everywhere. Choose H.264 for compatibility, HEVC for smaller files, or remux without touching the streams."
      icon={Film}
      badges={[{ label: '→ MP4', tone: 'nxt' }, { label: 'Faststart', tone: 'slate' }]}
    >
      <ToolGrid
        main={
          <>
            <Panel className="p-5">
              <PanelHeader title="Source file" subtitle="Any container the bundled FFmpeg build can decode." icon={RefreshCw} />
              <div className="mt-4">
                <FileDrop
                  accept="video/*,.mkv,.mov,.webm,.avi,.m4v,.mpg,.mpeg,.ts,.mts,.3gp,.ogv,.flv"
                  file={file}
                  onFile={(next) => {
                    setFile(next)
                    setResult(null)
                    task.reset()
                  }}
                  title="Drop a video to convert"
                  subtitle="MOV · WebM · MKV · AVI · M4V"
                  hint="Everything is decoded locally. Unsupported formats fail with a readable explanation, never a silent error."
                  disabled={task.isRunning}
                />
              </div>
              <FileLimitNotice file={file} className="mt-3" />
              {extensionLooksOdd ? (
                <Notice tone="warning" title={`“.${extension}” is not a common video container`} className="mt-3">
                  It may still decode if it contains a standard video stream. If the engine rejects it, convert the file
                  with a desktop tool first.
                </Notice>
              ) : null}
            </Panel>

            <Panel className="p-5">
              <PanelHeader title="Conversion settings" subtitle="Output is always MP4 with faststart." icon={Sparkles} />

              <div className="mt-5 space-y-5">
                <Field label="Video codec">
                  <Select
                    value={codec}
                    onChange={(event) => setCodec(event.target.value)}
                    options={CODECS.map((item) => ({ value: item.id, label: item.label }))}
                  />
                </Field>

                {codec === 'copy' ? (
                  <Notice tone="info" title="Stream copy — no quality loss, no re-encode">
                    The video and audio streams are moved into a new MP4 container without decoding. This only works when
                    the source codecs are MP4-friendly (H.264/H.265 video, AAC audio). Resolution, frame rate and
                    bitrate stay exactly as they are.
                  </Notice>
                ) : (
                  <>
                    <Field label="Quality preset" hint={QUALITY_PRESETS.find((q) => q.id === quality)?.note}>
                      <Select
                        value={quality}
                        onChange={(event) => applyQuality(event.target.value)}
                        options={QUALITY_PRESETS.filter((item) => item.id !== 'custom').map((item) => ({
                          value: item.id,
                          label: item.label,
                        }))}
                      />
                    </Field>

                    <Slider
                      label="CRF — lower is better quality"
                      value={crf}
                      min={16}
                      max={32}
                      step={1}
                      onChange={(value) => {
                        setCrf(value)
                        setQuality('custom')
                      }}
                      display={`CRF ${crf}`}
                    />

                    <Field label="Encoder speed">
                      <Segmented
                        value={speed}
                        onChange={setSpeed}
                        options={SPEED_PRESETS.map((item) => ({ id: item.id, label: item.label }))}
                      />
                    </Field>
                  </>
                )}

                <Field label="Audio handling">
                  <Segmented
                    value={audioMode}
                    onChange={setAudioMode}
                    options={[
                      { id: 'aac', label: 'AAC' },
                      { id: 'copy', label: 'Copy' },
                      { id: 'none', label: 'Remove' },
                    ]}
                  />
                </Field>

                {audioMode === 'aac' ? (
                  <Slider
                    label="Audio bitrate"
                    value={audioKbps}
                    min={64}
                    max={320}
                    step={32}
                    onChange={setAudioKbps}
                    display={`${audioKbps} kbps`}
                  />
                ) : null}

                {codec === 'hevc' ? (
                  <Notice tone="warning" title="HEVC is experimental in this build">
                    Not every browser build of the engine ships an x265 encoder, and HEVC playback depends on the viewer&apos;s
                    device. If the encode fails, switch to H.264. For TikTok and general sharing, H.264 is still the safe
                    choice.
                  </Notice>
                ) : null}
              </div>

              <div className="mt-5 flex flex-wrap items-center gap-2">
                <Button size="lg" icon={Film} onClick={start} disabled={!file || task.isRunning} loading={task.isRunning}>
                  {task.isRunning ? 'Converting…' : 'Convert to MP4'}
                </Button>
                {file ? (
                  <Button variant="ghost" onClick={reset} disabled={task.isRunning}>
                    Reset
                  </Button>
                ) : null}
                <Badge tone="slate" className="ml-auto">
                  {SUPPORTED.length}+ containers
                </Badge>
              </div>

              <div className="mt-4">
                <JobStatus task={task} runningLabel="Converting…" />
              </div>
            </Panel>
          </>
        }
        side={
          <>
            <Panel className="p-5">
              <PanelHeader title="Source details" subtitle="Read instantly from the file header." icon={Film} />
              <div className="mt-4 grid grid-cols-2 gap-2">
                <Stat label="File size" value={file ? formatBytes(file.size) : '—'} />
                <Stat label="Duration" value={quick?.duration ? `${quick.duration.toFixed(1)} s` : '—'} />
                <Stat label="Resolution" value={quick?.width ? `${quick.width} × ${quick.height}` : '—'} />
                <Stat label="Aspect" value={quick?.aspect || '—'} />
              </div>
              {quick?.unsupported ? (
                <Notice tone="danger" title="The browser cannot preview this container" className="mt-3">
                  Preview failed, but the engine may still decode it. Try the conversion — errors are explained in plain
                  language.
                </Notice>
              ) : null}
              <div className="mt-4">
                <OutputCard result={result} originalSize={file?.size} onReset={reset} />
              </div>
            </Panel>

            <Panel className="p-5">
              <SideNote title="Compatibility notes">
                <p>MP4 + H.264 + AAC + faststart plays on iOS, Android, browsers, TVs and every major platform uploader.</p>
                <p>MOV files from iPhones often carry HEVC or ProRes; those are re-encoded to H.264 here.</p>
                <p>WebM/VP9 sources are decoded and re-encoded — expect slower processing than an MP4 source.</p>
              </SideNote>
              <SpeedNote className="mt-3" />
              <PrivacyNote className="mt-3" />
            </Panel>
          </>
        }
      />
    </ToolShell>
  )
}
