import { useEffect, useState } from 'react'
import { AlertTriangle, Gauge, Scan, Sparkles } from 'lucide-react'
import { OutputCard, SideNote, ToolGrid, ToolShell } from '../../components/ToolShell'
import {
  Badge,
  Button,
  Field,
  FileDrop,
  Notice,
  Panel,
  PanelHeader,
  Segmented,
  Slider,
  Stat,
} from '../../components/ui'
import { JobStatus } from '../../components/JobStatus'
import { FileLimitNotice, PrivacyNote } from '../../components/EngineHints'
import { MediaInfoGrid } from '../../components/MediaInfoGrid'
import { useTask } from '../../lib/useTask'
import { readMediaReport, runFFmpeg } from '../../lib/ffmpeg'
import { parseMediaReport, quickProbe } from '../../lib/mediaInfo'
import { FPS_OPTIONS, QUALITY_PRESETS, SPEED_PRESETS } from '../../lib/presets'
import { audioEncoderArgs, videoEncoderArgs } from '../../lib/encode'
import { formatBytes, safeFileName } from '../../lib/format'

const METHODS = [
  { id: 'duplicate', label: 'Frame duplication / drop' },
  { id: 'interpolate', label: 'Motion interpolation' },
]

export default function FpsConverter() {
  const [file, setFile] = useState(null)
  const [quick, setQuick] = useState(null)
  const [info, setInfo] = useState(null)
  const [result, setResult] = useState(null)

  const [fps, setFps] = useState(30)
  const [method, setMethod] = useState('duplicate')
  const [quality, setQuality] = useState('balanced')
  const [crf, setCrf] = useState(23)
  const [speed, setSpeed] = useState('veryfast')
  const [audioKbps, setAudioKbps] = useState(160)

  const task = useTask()
  const probe = useTask()

  useEffect(() => {
    if (!file) {
      setQuick(null)
      setInfo(null)
      return undefined
    }
    let alive = true
    quickProbe(file).then((data) => alive && setQuick(data))
    return () => {
      alive = false
    }
  }, [file])

  useEffect(() => {
    return () => {
      if (result?.url) URL.revokeObjectURL(result.url)
    }
  }, [result])

  // Analysis is explicit: the engine is only loaded when the user asks for it.
  const runProbe = async () => {
    if (!file) return
    setInfo(null)
    const parsed = await probe.run(async () => {
      const report = await readMediaReport(file)
      return parseMediaReport(report)
    })
    if (parsed) setInfo(parsed)
  }

  const applyQuality = (id) => {
    setQuality(id)
    const preset = QUALITY_PRESETS.find((item) => item.id === id)
    if (preset && id !== 'custom') {
      setCrf(preset.crf)
      setAudioKbps(preset.audioKbps)
    }
  }

  const sourceFps = info?.video?.fps || null
  const interpolatingUpscale = method === 'interpolate' && sourceFps && fps <= sourceFps
  const heavyInterpolation = method === 'interpolate' && (quick?.duration || 0) > 30

  const reset = () => {
    if (result?.url) URL.revokeObjectURL(result.url)
    setResult(null)
    setFile(null)
    setInfo(null)
    task.reset()
    probe.reset()
  }

  const start = async () => {
    if (!file) return
    if (result?.url) URL.revokeObjectURL(result.url)
    setResult(null)

    const outputName = safeFileName(`${file.name.replace(/\.[^.]+$/, '')}-${fps}fps`, 'mp4')
    const interpolate = method === 'interpolate'

    const output = await task.run(async ({ onProgress, onPhase, isCancelled }) => {
      onPhase(interpolate ? 'Interpolating frames (slow)…' : 'Retiming to constant frame rate…')
      const res = await runFFmpeg({
        file,
        args: [
          '-hide_banner',
          '-y',
          '-i',
          '@in',
          ...videoEncoderArgs({
            crf,
            speed,
            fps: interpolate ? null : fps,
            filters: interpolate
              ? [`minterpolate=fps=${fps}:mi_mode=mci:mc_mode=aobmc:me_mode=bidir:vsbmc=1`]
              : [],
            extra: interpolate ? ['-r', String(fps), '-fps_mode', 'cfr'] : [],
          }),
          ...audioEncoderArgs({ kbps: audioKbps }),
          '@out',
        ],
        output: 'fps.mp4',
        outputType: 'video/mp4',
        onProgress,
        onStatus: onPhase,
      })
      if (isCancelled()) return null
      return res
    })

    if (!output) return
    setResult({
      blob: output.blob,
      url: URL.createObjectURL(output.blob),
      size: output.size,
      name: outputName,
      meta: [
        { label: 'Frame rate', value: `${fps} fps CFR` },
        { label: 'Method', value: interpolate ? 'motion interpolation' : 'duplication / drop' },
        { label: 'Codec', value: `H.264 CRF ${crf}` },
        { label: 'Audio', value: `AAC ${audioKbps}k` },
      ],
    })
  }

  return (
    <ToolShell
      eyebrow="Video Tools"
      title="FPS Converter"
      description="Retime footage to 24, 25, 30, 50 or 60 frames per second. Frame duplication and motion interpolation are different operations — this tool labels them honestly and never presents duplicated frames as new motion."
      icon={Gauge}
      badges={[{ label: 'Constant frame rate', tone: 'nxt' }]}
    >
      <ToolGrid
        main={
          <>
            <Panel className="p-5">
              <PanelHeader title="Source clip" subtitle="Short clips only when using interpolation." icon={Scan} />
              <div className="mt-4">
                <FileDrop
                  accept="video/*,.mkv,.mov,.webm,.avi,.m4v"
                  file={file}
                  onFile={(next) => {
                    setFile(next)
                    setInfo(null)
                    setResult(null)
                    task.reset()
                    probe.reset()
                  }}
                  title="Drop a video here"
                  subtitle="or click to browse"
                  disabled={task.isRunning}
                />
              </div>
              <FileLimitNotice file={file} className="mt-3" />
              <div className="mt-3 flex flex-wrap items-center gap-2">
                <Button variant="secondary" size="sm" icon={Scan} onClick={runProbe} disabled={!file || probe.isRunning} loading={probe.isRunning}>
                  Detect source frame rate
                </Button>
                {sourceFps ? <Badge tone="cyan">source {sourceFps.toFixed(2)} fps</Badge> : null}
                {quick?.duration ? <Badge tone="slate">{quick.duration.toFixed(1)} s</Badge> : null}
              </div>
              {info ? (
                <div className="mt-4">
                  <MediaInfoGrid info={info} compact />
                </div>
              ) : null}
              {probe.status === 'error' ? (
                <Notice tone="danger" title="Could not analyse the file" className="mt-3">
                  {probe.error}
                </Notice>
              ) : null}
            </Panel>

            <Panel className="p-5">
              <PanelHeader title="Output frame rate" subtitle="All five rates are constant (CFR) outputs." icon={Sparkles} />

              <div className="mt-5 grid gap-5 sm:grid-cols-2">
                <Field label="Target frame rate">
                  <Segmented
                    value={fps}
                    onChange={setFps}
                    options={FPS_OPTIONS.map((value) => ({ id: value, label: String(value) }))}
                  />
                </Field>
                <Field label="Quality preset">
                  <Segmented
                    value={quality === 'custom' ? 'balanced' : quality}
                    onChange={applyQuality}
                    options={QUALITY_PRESETS.filter((item) => item.id !== 'custom').map((item) => ({
                      id: item.id,
                      label: item.label.split(' ')[0],
                    }))}
                  />
                </Field>
              </div>

              <div className="mt-5">
                <Field label="Method">
                  <Segmented value={method} onChange={setMethod} options={METHODS} />
                </Field>
              </div>

              {method === 'duplicate' ? (
                <Notice tone="info" title="Frame duplication / drop — no new motion" className="mt-4">
                  Every output frame is either a copy of an existing frame or a dropped one. Going from 24 to 60 fps adds
                  duplicated frames; the clip lasts the same time and the motion is exactly as smooth as the source. This
                  is what a plain FPS change does, and it is the right choice for compatibility.
                </Notice>
              ) : (
                <Notice
                  tone={heavyInterpolation ? 'danger' : 'warning'}
                  title="Motion interpolation — genuinely new frames, with caveats"
                  icon={AlertTriangle}
                  className="mt-4"
                >
                  <p>
                    Frames are synthesised by estimating motion between existing frames. This is real interpolation, not
                    duplication, but it can introduce warping around edges, text and fast occlusion, and it is very
                    CPU-heavy in a browser.
                  </p>
                  {heavyInterpolation ? (
                    <p className="mt-2 font-medium text-rose-200">
                      This clip is {(quick?.duration || 0).toFixed(0)} s long. Interpolation may take many minutes or run
                      out of memory. Trim it to a few seconds first.
                    </p>
                  ) : null}
                </Notice>
              )}

              {interpolatingUpscale ? (
                <Notice tone="warning" title="Nothing to interpolate up to" className="mt-3">
                  The source is already {sourceFps.toFixed(2)} fps, so going to {fps} fps gains no new motion information.
                  Frame duplication is the honest option here.
                </Notice>
              ) : null}

              <div className="mt-5 space-y-5">
                <Slider label="CRF — lower is better quality" value={crf} min={16} max={32} step={1} onChange={(value) => { setCrf(value); setQuality('custom') }} display={`CRF ${crf}`} />
                <Field label="Encoder speed">
                  <Segmented value={speed} onChange={setSpeed} options={SPEED_PRESETS.map((item) => ({ id: item.id, label: item.label }))} />
                </Field>
                <Slider label="Audio bitrate" value={audioKbps} min={64} max={320} step={32} onChange={setAudioKbps} display={`${audioKbps} kbps`} />
              </div>

              <div className="mt-5 flex flex-wrap items-center gap-2">
                <Button size="lg" icon={Gauge} onClick={start} disabled={!file || task.isRunning} loading={task.isRunning}>
                  {task.isRunning ? 'Processing…' : `Convert to ${fps} fps`}
                </Button>
                {file ? (
                  <Button variant="ghost" onClick={reset} disabled={task.isRunning}>
                    Reset
                  </Button>
                ) : null}
              </div>

              <div className="mt-4">
                <JobStatus task={task} runningLabel="Retiming…" />
              </div>
            </Panel>
          </>
        }
        side={
          <>
            <Panel className="p-5">
              <PanelHeader title="Retiming result" icon={Gauge} />
              <div className="mt-4 grid grid-cols-2 gap-2">
                <Stat label="Source FPS" value={sourceFps ? sourceFps.toFixed(2) : 'not analysed'} />
                <Stat label="Output FPS" value={`${fps} CFR`} />
                <Stat label="Method" value={method === 'duplicate' ? 'duplication' : 'interpolation'} />
                <Stat label="Source size" value={file ? formatBytes(file.size) : '—'} />
              </div>
              <div className="mt-4">
                <OutputCard result={result} originalSize={file?.size} onReset={reset} />
              </div>
            </Panel>

            <Panel className="p-5">
              <SideNote title="Duplication vs interpolation">
                <p>
                  <span className="text-slate-200">Duplication:</span> the encoder repeats frames to reach the target
                  rate. Fast, predictable, no artefacts, no invented detail.
                </p>
                <p>
                  <span className="text-slate-200">Interpolation:</span> an optical-flow style filter builds intermediate
                  frames. Real new frames, but generated — not recovered from the original shot.
                </p>
                <p>Neither method adds detail that was not filmed. Prefer shooting at the rate you want to deliver.</p>
              </SideNote>
              <PrivacyNote className="mt-3" />
            </Panel>
          </>
        }
      />
    </ToolShell>
  )
}
