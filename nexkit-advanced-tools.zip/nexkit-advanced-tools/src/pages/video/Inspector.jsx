import { useEffect, useState } from 'react'
import { AlertTriangle, Copy, FileVideo, Scan, ShieldCheck } from 'lucide-react'
import { SideNote, ToolGrid, ToolShell } from '../../components/ToolShell'
import {
  Badge,
  Button,
  FileDrop,
  Notice,
  Panel,
  PanelHeader,
  Progress,
  Stat,
} from '../../components/ui'
import { PrivacyNote } from '../../components/EngineHints'
import { MediaInfoGrid } from '../../components/MediaInfoGrid'
import { readMediaReport } from '../../lib/ffmpeg'
import { parseMediaReport, quickProbe } from '../../lib/mediaInfo'
import { copyText } from '../../lib/files'
import { formatBitrate, formatBytes, formatDuration } from '../../lib/format'

const IMPORTANT_KEYS = ['Stream #0', 'Duration', 'Input #0']

export default function Inspector() {
  const [file, setFile] = useState(null)
  const [quick, setQuick] = useState(null)
  const [info, setInfo] = useState(null)
  const [status, setStatus] = useState('idle')
  const [progress, setProgress] = useState(0)
  const [error, setError] = useState(null)
  const [copied, setCopied] = useState(false)

  useEffect(() => {
    if (!file) {
      setQuick(null)
      setInfo(null)
      setStatus('idle')
      return undefined
    }
    let alive = true
    setStatus('analysing')
    setProgress(0)
    setError(null)
    setInfo(null)

    quickProbe(file).then((data) => alive && setQuick(data))

    readMediaReport(file)
      .then((report) => {
        if (!alive) return
        setInfo(parseMediaReport(report))
        setStatus('done')
        setProgress(1)
      })
      .catch((err) => {
        if (!alive) return
        setError(err?.message || 'The engine could not read this file.')
        setStatus('error')
      })

    return () => {
      alive = false
    }
  }, [file])

  const copyReport = async () => {
    if (!info?.raw) return
    const ok = await copyText(info.raw)
    setCopied(ok)
    setTimeout(() => setCopied(false), 2000)
  }

  const headline = info || null
  const video = headline?.video
  const audio = headline?.audio

  return (
    <ToolShell
      eyebrow="Video Tools"
      title="Video Metadata Inspector"
      description="Read the real stream information from a file: resolution, frame rate, codec, bitrate, duration, audio layout, colour primaries and HDR signalling. Useful before you decide how to compress or prepare an upload."
      icon={Scan}
      badges={[{ label: 'HDR aware', tone: 'wagle' }, { label: 'Local', tone: 'success' }]}
    >
      <ToolGrid
        main={
          <>
            <Panel className="p-5">
              <PanelHeader title="Inspect a file" subtitle="The file is read locally — never uploaded." icon={FileVideo} />
              <div className="mt-4">
                <FileDrop
                  accept="video/*,audio/*,.mkv,.mov,.webm,.avi,.m4v,.mp3,.wav,.m4a,.aac"
                  file={file}
                  onFile={(next) => setFile(next)}
                  title="Drop a video or audio file"
                  subtitle="MP4 · MOV · MKV · WebM · MP3 · WAV"
                  hint="Deep analysis loads the NXT Core engine once (~32 MB, cached afterwards)."
                />
              </div>

              {status === 'analysing' ? (
                <div className="mt-4">
                  <Progress value={progress} label="Reading stream headers…" indeterminate={progress < 0.02} />
                </div>
              ) : null}

              {status === 'error' ? (
                <Notice tone="danger" title="Could not read this file" icon={AlertTriangle} className="mt-4">
                  {error}
                </Notice>
              ) : null}
            </Panel>

            {headline ? (
              <Panel className="p-5">
                <PanelHeader
                  title="Stream report"
                  subtitle={headline.container ? `Container: ${headline.container}` : undefined}
                  icon={Scan}
                  action={
                    <Button variant="secondary" size="sm" icon={Copy} onClick={copyReport}>
                      {copied ? 'Copied' : 'Copy report'}
                    </Button>
                  }
                />
                <div className="mt-4">
                  <MediaInfoGrid info={headline} />
                </div>

                <div className="mt-5 grid grid-cols-2 gap-2 sm:grid-cols-4">
                  <Stat label="File size" value={formatBytes(file.size)} />
                  <Stat label="Duration" value={formatDuration(headline.duration)} />
                  <Stat label="Total bitrate" value={formatBitrate(headline.overallBitrate)} />
                  <Stat label="Streams" value={`${video ? 'video' : ''}${video && audio ? ' + ' : ''}${audio ? 'audio' : ''}`} />
                </div>

                {video?.isHDR ? (
                  <Notice tone="warning" title={`HDR source detected — ${video.hdr}`} className="mt-4">
                    Re-encoding to H.264 converts this to SDR unless the pipeline explicitly preserves HDR. Use the WAGLE
                    Method for HDR-aware preparation, and expect tone-mapped output if you choose an SDR export.
                  </Notice>
                ) : null}

                <details className="mt-4 rounded-xl border border-white/[0.07] bg-black/25 p-3.5">
                  <summary className="cursor-pointer text-[12px] font-medium text-slate-300">Raw FFmpeg report</summary>
                  <pre className="mt-3 max-h-64 overflow-auto whitespace-pre-wrap break-words font-mono text-[10.5px] leading-relaxed text-slate-400">
                    {info.raw
                      .split('\n')
                      .filter((line) => IMPORTANT_KEYS.some((key) => line.includes(key)) || line.trim().startsWith('Metadata') || line.includes(':'))
                      .join('\n')}
                  </pre>
                </details>
              </Panel>
            ) : null}
          </>
        }
        side={
          <>
            <Panel className="p-5">
              <PanelHeader title="Instant header read" subtitle="Available before the engine loads." icon={ShieldCheck} />
              <div className="mt-4 grid grid-cols-2 gap-2">
                <Stat label="Duration" value={quick?.duration ? `${quick.duration.toFixed(2)} s` : '—'} />
                <Stat label="Resolution" value={quick?.width ? `${quick.width} × ${quick.height}` : quick ? 'audio only' : '—'} />
                <Stat label="Aspect" value={quick?.aspect || '—'} />
                <Stat label="Container" value={quick?.mimeType || '—'} />
              </div>
              {quick?.unsupported ? (
                <Notice tone="warning" title="Preview unsupported" className="mt-3">
                  The browser cannot decode this container for preview, but the engine may still read the stream headers.
                </Notice>
              ) : null}
            </Panel>

            <Panel className="p-5">
              <SideNote title="What the report means">
                <p>
                  <span className="text-slate-200">Bitrate</span> is the amount of data per second — the single strongest
                  predictor of how much detail survives compression.
                </p>
                <p>
                  <span className="text-slate-200">Colour primaries / transfer</span> tell you whether the file is SDR
                  (bt709) or HDR (bt2020 with PQ or HLG).
                </p>
                <p>
                  <span className="text-slate-200">Pixel format</span> with 10-bit indicates higher precision; it does not
                  guarantee HDR, and browsers usually decode it as SDR.
                </p>
              </SideNote>
              <PrivacyNote className="mt-3" />
            </Panel>

            {info?.video?.fps && info.video.fps > 60 ? (
              <Panel className="p-5">
                <Badge tone="warning">Above 60 fps</Badge>
                <p className="mt-2 text-[12px] leading-relaxed text-slate-400">
                  Both TikTok and most feed platforms cap uploads at 60 fps. Consider retiming with the FPS Converter
                  before publishing.
                </p>
              </Panel>
            ) : null}
          </>
        }
      />
    </ToolShell>
  )
}
