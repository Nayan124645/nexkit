import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import { Crop, Maximize2, Sparkles } from 'lucide-react'
import { OutputCard, SideNote, ToolGrid, ToolShell } from '../../components/ToolShell'
import {
  Badge,
  Button,
  Field,
  FileDrop,
  Input,
  Notice,
  Panel,
  PanelHeader,
  Segmented,
  Slider,
  Stat,
} from '../../components/ui'
import { JobStatus } from '../../components/JobStatus'
import { FileLimitNotice, PrivacyNote, SpeedNote } from '../../components/EngineHints'
import { useTask } from '../../lib/useTask'
import { runFFmpeg } from '../../lib/ffmpeg'
import { quickProbe } from '../../lib/mediaInfo'
import { ASPECT_PRESETS, SPEED_PRESETS, even } from '../../lib/presets'
import { audioEncoderArgs, videoEncoderArgs } from '../../lib/encode'
import { formatBytes, safeFileName } from '../../lib/format'

function Preview({ url, width, height, mode, focusX, focusY }) {
  const videoRef = useRef(null)
  const canvasRef = useRef(null)
  const [duration, setDuration] = useState(0)
  const [time, setTime] = useState(0)
  const [ready, setReady] = useState(false)

  const draw = useCallback(() => {
    const video = videoRef.current
    const canvas = canvasRef.current
    if (!video || !canvas || !video.videoWidth || !width || !height) return

    if (canvas.width !== width) canvas.width = width
    if (canvas.height !== height) canvas.height = height

    const ctx = canvas.getContext('2d')
    ctx.fillStyle = '#000'
    ctx.fillRect(0, 0, width, height)

    const sw = video.videoWidth
    const sh = video.videoHeight
    const scale =
      mode === 'crop' ? Math.max(width / sw, height / sh) : Math.min(width / sw, height / sh)
    const dw = sw * scale
    const dh = sh * scale
    const dx = (width - dw) * (mode === 'crop' ? focusX : 0.5)
    const dy = (height - dh) * (mode === 'crop' ? focusY : 0.5)

    ctx.imageSmoothingQuality = 'high'
    ctx.drawImage(video, dx, dy, dw, dh)
  }, [width, height, mode, focusX, focusY])

  useEffect(() => {
    draw()
  }, [draw, ready, time])

  return (
    <div className="space-y-3">
      <div className="relative overflow-hidden rounded-xl border border-white/10 bg-black">
        <video
          ref={videoRef}
          src={url}
          muted
          playsInline
          preload="auto"
          className="hidden"
          onLoadedMetadata={(event) => {
            setDuration(event.currentTarget.duration || 0)
            event.currentTarget.currentTime = 0
          }}
          onLoadedData={() => {
            setReady(true)
            draw()
          }}
          onSeeked={draw}
        />
        <canvas ref={canvasRef} className="mx-auto block max-h-[360px] w-auto max-w-full" />
        <div className="pointer-events-none absolute left-2 top-2 flex gap-1">
          <span className="rounded-md bg-black/65 px-1.5 py-0.5 font-mono text-[10px] text-white/80">
            {width}×{height}
          </span>
          <span className="rounded-md bg-black/65 px-1.5 py-0.5 font-mono text-[10px] text-white/80">{mode}</span>
        </div>
      </div>
      {duration > 0 ? (
        <Slider
          label="Preview frame"
          value={time}
          min={0}
          max={Math.max(0.1, duration - 0.05)}
          step={0.05}
          onChange={(value) => {
            setTime(value)
            if (videoRef.current) videoRef.current.currentTime = value
          }}
          display={`${time.toFixed(2)} / ${duration.toFixed(2)} s`}
        />
      ) : (
        <p className="text-[11px] text-slate-500">Loading preview…</p>
      )}
    </div>
  )
}

export default function Resizer() {
  const [file, setFile] = useState(null)
  const [quick, setQuick] = useState(null)
  const [result, setResult] = useState(null)
  const [sourceUrl, setSourceUrl] = useState(null)

  const [aspect, setAspect] = useState('9:16')
  const [customWidth, setCustomWidth] = useState(1080)
  const [customHeight, setCustomHeight] = useState(1920)
  const [mode, setMode] = useState('crop')
  const [focusX, setFocusX] = useState(0.5)
  const [focusY, setFocusY] = useState(0.5)
  const [crf, setCrf] = useState(22)
  const [speed, setSpeed] = useState('veryfast')
  const [audioKbps, setAudioKbps] = useState(160)

  const task = useTask()

  useEffect(() => {
    if (!file) {
      setQuick(null)
      setSourceUrl(null)
      return undefined
    }
    const url = URL.createObjectURL(file)
    setSourceUrl(url)
    let alive = true
    quickProbe(file).then((data) => alive && setQuick(data))
    return () => {
      alive = false
      URL.revokeObjectURL(url)
    }
  }, [file])

  useEffect(() => {
    return () => {
      if (result?.url) URL.revokeObjectURL(result.url)
    }
  }, [result])

  const preset = ASPECT_PRESETS.find((item) => item.id === aspect)

  const target = useMemo(() => {
    if (aspect === 'custom') {
      return { width: even(customWidth), height: even(customHeight) }
    }
    if (aspect === 'source' && quick?.width) {
      return { width: even(quick.width), height: even(quick.height) }
    }
    return { width: preset.width, height: preset.height }
  }, [aspect, customWidth, customHeight, preset, quick])

  const filter =
    mode === 'crop'
      ? `scale=${target.width}:${target.height}:force_original_aspect_ratio=increase:flags=lanczos,crop=${target.width}:${target.height}:(iw-${target.width})*${focusX}:(ih-${target.height})*${focusY}`
      : `scale=${target.width}:${target.height}:force_original_aspect_ratio=decrease:flags=lanczos,pad=${target.width}:${target.height}:(ow-iw)/2:(oh-ih)/2:color=black`

  const upscaling = Boolean(quick?.height && target.height > quick.height)

  const reset = () => {
    if (result?.url) URL.revokeObjectURL(result.url)
    setResult(null)
    setFile(null)
    task.reset()
  }

  const start = async () => {
    if (!file) return
    if (result?.url) URL.revokeObjectURL(result.url)
    setResult(null)

    const outputName = safeFileName(`${file.name.replace(/\.[^.]+$/, '')}-${target.width}x${target.height}`, 'mp4')

    const output = await task.run(async ({ onProgress, onPhase, isCancelled }) => {
      onPhase(mode === 'crop' ? 'Scaling and cropping…' : 'Scaling and padding…')
      const res = await runFFmpeg({
        file,
        args: [
          '-hide_banner',
          '-y',
          '-i',
          '@in',
          ...videoEncoderArgs({ crf, speed, filters: [filter] }),
          ...audioEncoderArgs({ kbps: audioKbps }),
          '@out',
        ],
        output: 'resized.mp4',
        outputType: 'video/mp4',
        onProgress,
        onStatus: onPhase,
      })
      if (isCancelled()) return null
      return res
    })

    if (!output) return
    setResult({
      blob: output.blob,
      url: URL.createObjectURL(output.blob),
      size: output.size,
      name: outputName,
      meta: [
        { label: 'Output size', value: `${target.width} × ${target.height}` },
        { label: 'Framing', value: mode === 'crop' ? 'crop to fill' : 'fit with padding' },
        { label: 'Aspect', value: aspect === 'custom' ? 'custom' : preset?.label || aspect },
        { label: 'Codec', value: `H.264 CRF ${crf}` },
      ],
    })
  }

  return (
    <ToolShell
      eyebrow="Video Tools"
      title="Video Resizer"
      description="Reframe footage to vertical, square, classic or custom dimensions. Choose crop to fill the frame or fit with padding, preview the exact framing, then export."
      icon={Crop}
      badges={[{ label: '9:16', tone: 'nxt' }, { label: 'Custom size', tone: 'slate' }]}
    >
      <ToolGrid
        main={
          <>
            <Panel className="p-5">
              <PanelHeader title="Source clip" subtitle="Preview updates as you change the framing." icon={Maximize2} />
              <div className="mt-4">
                <FileDrop
                  accept="video/*,.mkv,.mov,.webm,.avi,.m4v"
                  file={file}
                  onFile={(next) => {
                    setFile(next)
                    setResult(null)
                    task.reset()
                  }}
                  title="Drop a video here"
                  subtitle="or click to browse"
                  compact
                  disabled={task.isRunning}
                />
              </div>
              <FileLimitNotice file={file} className="mt-3" />
            </Panel>

            <Panel className="p-5">
              <PanelHeader title="Framing" subtitle="Preview renders the same maths the encoder uses." icon={Crop} />

              <div className="mt-4 grid gap-5 sm:grid-cols-2">
                <Field label="Aspect preset">
                  <Segmented
                    value={aspect}
                    onChange={setAspect}
                    options={[...ASPECT_PRESETS.map((item) => ({ id: item.id, label: item.label })), { id: 'custom', label: 'Custom' }]}
                    size="sm"
                  />
                </Field>
                <Field label="Mode">
                  <Segmented
                    value={mode}
                    onChange={setMode}
                    options={[
                      { id: 'crop', label: 'Crop to fill' },
                      { id: 'fit', label: 'Fit (padding)' },
                    ]}
                    size="sm"
                  />
                </Field>
              </div>

              {aspect === 'custom' ? (
                <div className="mt-4 grid grid-cols-2 gap-3">
                  <Field label="Width (px)">
                    <Input
                      type="number"
                      min={64}
                      max={4096}
                      step={2}
                      value={customWidth}
                      onChange={(event) => setCustomWidth(Number(event.target.value) || 64)}
                    />
                  </Field>
                  <Field label="Height (px)">
                    <Input
                      type="number"
                      min={64}
                      max={4096}
                      step={2}
                      value={customHeight}
                      onChange={(event) => setCustomHeight(Number(event.target.value) || 64)}
                    />
                  </Field>
                </div>
              ) : null}

              {mode === 'crop' ? (
                <div className="mt-4 space-y-4">
                  <Field label="Horizontal focus">
                    <Segmented
                      value={focusX}
                      onChange={setFocusX}
                      size="sm"
                      options={[
                        { id: 0, label: 'Left' },
                        { id: 0.5, label: 'Center' },
                        { id: 1, label: 'Right' },
                      ]}
                    />
                  </Field>
                  <Field label="Vertical focus">
                    <Segmented
                      value={focusY}
                      onChange={setFocusY}
                      size="sm"
                      options={[
                        { id: 0, label: 'Top' },
                        { id: 0.5, label: 'Center' },
                        { id: 1, label: 'Bottom' },
                      ]}
                    />
                  </Field>
                </div>
              ) : null}

              <div className="mt-5 grid gap-5 sm:grid-cols-2">
                <Slider label="CRF — lower is better quality" value={crf} min={16} max={32} step={1} onChange={setCrf} display={`CRF ${crf}`} />
                <Field label="Encoder speed">
                  <Segmented value={speed} onChange={setSpeed} options={SPEED_PRESETS.map((item) => ({ id: item.id, label: item.label }))} size="sm" />
                </Field>
              </div>

              <div className="mt-4">
                <Slider label="Audio bitrate" value={audioKbps} min={64} max={320} step={32} onChange={setAudioKbps} display={`${audioKbps} kbps`} />
              </div>

              {upscaling ? (
                <Notice tone="warning" title="Upscaling does not add detail" className="mt-4">
                  The source is {quick.width}×{quick.height}. A {target.height}p canvas adds pixels but no new information.
                </Notice>
              ) : null}

              {file && sourceUrl ? (
                <div className="mt-5">
                  <Preview url={sourceUrl} width={target.width} height={target.height} mode={mode} focusX={focusX} focusY={focusY} />
                </div>
              ) : null}

              <div className="mt-5 flex flex-wrap items-center gap-2">
                <Button size="lg" icon={Crop} onClick={start} disabled={!file || task.isRunning} loading={task.isRunning}>
                  {task.isRunning ? 'Exporting…' : 'Export resized video'}
                </Button>
                {file ? (
                  <Button variant="ghost" onClick={reset} disabled={task.isRunning}>
                    Reset
                  </Button>
                ) : null}
                <Badge tone="slate" className="ml-auto">
                  {target.width} × {target.height}
                </Badge>
              </div>

              <div className="mt-4">
                <JobStatus task={task} runningLabel="Rendering…" />
              </div>
            </Panel>
          </>
        }
        side={
          <>
            <Panel className="p-5">
              <PanelHeader title="Export summary" icon={Sparkles} />
              <div className="mt-4 grid grid-cols-2 gap-2">
                <Stat label="Source" value={quick?.width ? `${quick.width} × ${quick.height}` : '—'} />
                <Stat label="Output" value={`${target.width} × ${target.height}`} />
                <Stat label="Mode" value={mode === 'crop' ? 'crop' : 'fit'} />
                <Stat label="File size" value={file ? formatBytes(file.size) : '—'} />
              </div>
              <div className="mt-4">
                <OutputCard result={result} originalSize={file?.size} onReset={reset} />
              </div>
            </Panel>

            <Panel className="p-5">
              <SideNote title="Crop or fit?">
                <p>
                  <span className="text-slate-200">Crop</span> keeps the full frame height or width and cuts the rest —
                  best when the subject is centred and you need a true full-bleed vertical video.
                </p>
                <p>
                  <span className="text-slate-200">Fit</span> keeps the whole frame and adds black bars — nothing is lost,
                  but the video no longer fills a phone screen.
                </p>
                <p>The preview uses the same scale maths as the encoder, so what you frame is what you export.</p>
              </SideNote>
              <SpeedNote className="mt-3" />
              <PrivacyNote className="mt-3" />
            </Panel>
          </>
        }
      />
    </ToolShell>
  )
}
