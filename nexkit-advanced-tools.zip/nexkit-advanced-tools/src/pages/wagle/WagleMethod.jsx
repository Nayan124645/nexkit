import { useEffect, useMemo, useRef, useState } from 'react'
import {
  AlertTriangle,
  ArrowLeft,
  ArrowRight,
  Check,
  ChevronRight,
  Info,
  Palette,
  Scan,
  ShieldCheck,
  Sparkles,
  Timer,
  WandSparkles,
  Zap,
} from 'lucide-react'
import { OutputCard, SideNote } from '../../components/ToolShell'
import {
  Badge,
  Button,
  Checkbox,
  Field,
  FileDrop,
  IconBadge,
  Notice,
  Panel,
  PanelHeader,
  Progress,
  Segmented,
  Select,
  Slider,
  Stat,
  cx,
} from '../../components/ui'
import { JobStatus } from '../../components/JobStatus'
import { FileLimitNotice, PrivacyNote } from '../../components/EngineHints'
import { MediaInfoGrid } from '../../components/MediaInfoGrid'
import { useTask } from '../../lib/useTask'
import { readMediaReport, runFFmpeg } from '../../lib/ffmpeg'
import {
  estimateSizeBytes,
  estimateVideoKbps,
  parseMediaReport,
  quickProbe,
} from '../../lib/mediaInfo'
import {
  HDR_SDR_FILTER,
  RESOLUTIONS,
  SPEED_PRESETS,
  STEPS_WAGLE,
  TIKTOK_PRESETS,
  TONEMAP_NOTE,
  containFilter,
  coverFilter,
  scaleFilterForHeight,
} from '../../lib/presets'
import { audioEncoderArgs, videoEncoderArgs } from '../../lib/encode'
import { formatBitrate, formatBytes, prettyCodec, safeFileName } from '../../lib/format'

const STEPS = STEPS_WAGLE
const STEP_ICONS = { source: Scan, quality: Sparkles, motion: Timer, colour: Palette, deliver: WandSparkles }

const FRAMING = [
  { id: 'crop', label: 'Crop to fill' },
  { id: 'fit', label: 'Fit (bars)' },
]

export default function WagleMethod() {
  const [step, setStep] = useState(0)
  const [file, setFile] = useState(null)
  const [quick, setQuick] = useState(null)
  const [info, setInfo] = useState(null)
  const [analysisError, setAnalysisError] = useState(null)
  const [analysing, setAnalysing] = useState(false)
  const [result, setResult] = useState(null)

  const [preset, setPreset] = useState('tiktok-1080p60')
  const [framing, setFraming] = useState('crop')
  const [forceEncode, setForceEncode] = useState(false)
  const [crf, setCrf] = useState(20)
  const [speed, setSpeed] = useState('veryfast')
  const [denoise, setDenoise] = useState(false)
  const [sharpen, setSharpen] = useState(true)
  const [resizeHeight, setResizeHeight] = useState('none')
  const [fpsMode, setFpsMode] = useState('keep')
  const [fpsMethod, setFpsMethod] = useState('duplicate')
  const [audioKbps, setAudioKbps] = useState(160)
  const [hdrAction, setHdrAction] = useState('tonemap')
  const [hdrAcknowledged, setHdrAcknowledged] = useState(false)

  const task = useTask()
  const analysedRef = useRef(null)

  const selectedPreset = TIKTOK_PRESETS.find((item) => item.id === preset) || TIKTOK_PRESETS[1]
  const sourceIsHDR = Boolean(info?.video?.isHDR)
  const sourceFps = info?.video?.fps || null

  useEffect(() => {
    if (!file) {
      setQuick(null)
      setInfo(null)
      setResult(null)
      analysedRef.current = null
      return undefined
    }
    let alive = true
    quickProbe(file).then((data) => alive && setQuick(data))
    return () => {
      alive = false
    }
  }, [file])

  useEffect(() => {
    return () => {
      if (result?.url) URL.revokeObjectURL(result.url)
    }
  }, [result])

  const analyse = async (target) => {
    if (!target) return
    setAnalysing(true)
    setAnalysisError(null)
    setInfo(null)
    try {
      const report = await readMediaReport(target)
      if (analysedRef.current !== target) return
      const parsed = parseMediaReport(report)
      setInfo(parsed)
      if (parsed.video?.isHDR) setHdrAction('tonemap')
    } catch (error) {
      if (analysedRef.current !== target) return
      setAnalysisError(error?.message || 'Could not read this file.')
    } finally {
      setAnalysing(false)
    }
  }

  const handleFile = (next) => {
    setFile(next)
    setResult(null)
    setStep(0)
    setInfo(null)
    setAnalysisError(null)
    task.reset()
    analysedRef.current = next
    if (next) analyse(next)
  }

  /* ------------------------------------------------------------- planning */

  const canPassthrough = useMemo(() => {
    if (!info?.video?.codec) return false
    if (!['h264', 'hevc'].includes(info.video.codec)) return false
    if (info.audio && !['aac'].includes(info.audio.codec)) return false
    return true
  }, [info])

  const needsResize = Boolean(
    info?.video?.width &&
      selectedPreset.width &&
      (info.video.width !== selectedPreset.width || info.video.height !== selectedPreset.height),
  )
  const needsRetime = fpsMode !== 'keep' && String(sourceFps?.toFixed(2)) !== Number(fpsMode).toFixed(2)

  const transformsRequired =
    needsResize || needsRetime || denoise || sharpen || resizeHeight !== 'none' || (sourceIsHDR && hdrAction === 'tonemap')

  const mode = !forceEncode && canPassthrough && !transformsRequired ? 'passthrough' : 'encode'

  const targetDimensions = useMemo(() => {
    if (resizeHeight !== 'none') {
      const height = Number(resizeHeight)
      if (!info?.video?.width) return { width: null, height }
      const width = Math.round((info.video.width * height) / info.video.height / 2) * 2
      return { width, height }
    }
    if (selectedPreset.width) return { width: selectedPreset.width, height: selectedPreset.height }
    return { width: info?.video?.width || null, height: info?.video?.height || null }
  }, [resizeHeight, selectedPreset, info])

  const targetFps = fpsMode === 'keep' ? sourceFps : Number(fpsMode)

  const bitrateCap = selectedPreset.videoKbps || null

  const estimatedVideoKbps = useMemo(() => {
    if (mode === 'passthrough') return info?.video?.bitrate || info?.overallBitrate || null
    const base = estimateVideoKbps({
      width: targetDimensions.width || 1080,
      height: targetDimensions.height || 1920,
      fps: targetFps || 30,
      crf,
    })
    return bitrateCap ? Math.min(base, bitrateCap) : base
  }, [mode, info, targetDimensions, targetFps, crf, bitrateCap])

  const estimatedSize = useMemo(
    () =>
      estimateSizeBytes({
        videoKbps: estimatedVideoKbps || 8000,
        audioKbps,
        duration: info?.duration || quick?.duration || 0,
      }),
    [estimatedVideoKbps, audioKbps, info, quick],
  )

  const hdrNeedsAcknowledgement = mode === 'encode' && sourceIsHDR && hdrAction === 'tonemap' && !hdrAcknowledged

  const filters = useMemo(() => {
    const chain = []
    if (mode === 'encode') {
      if (sourceIsHDR && hdrAction === 'tonemap') chain.push(HDR_SDR_FILTER)
      if (denoise) chain.push('hqdn3d=1.6:1.4:6:6')
      if (resizeHeight !== 'none') chain.push(scaleFilterForHeight(Number(resizeHeight)))
      else if (needsResize && selectedPreset.width)
        chain.push(
          framing === 'crop'
            ? coverFilter(selectedPreset.width, selectedPreset.height)
            : containFilter(selectedPreset.width, selectedPreset.height),
        )
      if (fpsMode !== 'keep') {
        chain.push(
          fpsMethod === 'interpolate' && Number(fpsMode) > (sourceFps || 0)
            ? `minterpolate=fps=${fpsMode}:mi_mode=mci:mc_mode=aobmc:me_mode=bidir:vsbmc=1`
            : `fps=${fpsMode}`,
        )
      }
      if (sharpen) chain.push('unsharp=5:5:0.55:3:3:0.2')
    }
    return chain
  }, [
    mode,
    sourceIsHDR,
    hdrAction,
    denoise,
    resizeHeight,
    needsResize,
    selectedPreset,
    framing,
    fpsMode,
    fpsMethod,
    sourceFps,
    sharpen,
  ])

  const planSummary = [
    { label: 'Pipeline', value: mode === 'passthrough' ? 'Container passthrough' : 'H.264 re-encode' },
    { label: 'Output', value: targetDimensions.width ? `${targetDimensions.width}×${targetDimensions.height}` : 'source' },
    { label: 'Frame rate', value: fpsMode === 'keep' ? `${sourceFps ? sourceFps.toFixed(2) : '—'} fps` : `${fpsMode} fps` },
    {
      label: 'HDR',
      value: mode === 'passthrough' ? (sourceIsHDR ? 'preserved in stream' : 'SDR') : sourceIsHDR && hdrAction === 'tonemap' ? 'tone-mapped to SDR' : 'SDR',
    },
    { label: 'Audio', value: `${audioKbps} kbps AAC` },
    { label: 'Estimated size', value: estimatedSize ? formatBytes(estimatedSize) : '—' },
  ]

  /* ---------------------------------------------------------------- action */

  const run = async () => {
    if (!file || !info) return
    if (result?.url) URL.revokeObjectURL(result.url)
    setResult(null)

    const suffix = fpsMode === 'keep' ? 'wagle' : `wagle-${fpsMode}fps`
    const outputName = safeFileName(`${file.name.replace(/\.[^.]+$/, '')}-${suffix}`, 'mp4')

    const output = await task.run(async ({ onProgress, onPhase, isCancelled }) => {
      onPhase(mode === 'passthrough' ? 'Rewriting container (no re-encode)…' : 'Preparing and encoding…')

      const audioArgs =
        info.audio == null
          ? ['-an']
          : mode === 'passthrough' && info.audio.codec === 'aac'
            ? ['-c:a', 'copy']
            : audioEncoderArgs({ kbps: audioKbps, sampleRate: 48000 })

      const videoArgs =
        mode === 'passthrough'
          ? ['-c:v', 'copy', ...(info.video.codec === 'hevc' ? ['-tag:v', 'hvc1'] : [])]
          : videoEncoderArgs({
              crf,
              speed,
              filters,
              extra: [
                '-level', '4.2',
                ...(bitrateCap ? ['-maxrate', `${bitrateCap}k`, '-bufsize', `${bitrateCap * 2}k`] : []),
                '-g', String(Math.round((targetFps || 30) * 2)),
              ],
            })

      const res = await runFFmpeg({
        file,
        args: ['-hide_banner', '-y', '-i', '@in', ...videoArgs, ...audioArgs, '-movflags', '+faststart', '@out'],
        output: 'wagle.mp4',
        outputType: 'video/mp4',
        onProgress,
        onStatus: onPhase,
      })
      if (isCancelled()) return null
      return res
    })

    if (!output) return
    setResult({
      blob: output.blob,
      url: URL.createObjectURL(output.blob),
      size: output.size,
      name: outputName,
      meta: [
        { label: 'Pipeline', value: mode === 'passthrough' ? 'passthrough' : 'H.264 encode' },
        { label: 'Resolution', value: targetDimensions.width ? `${targetDimensions.width}×${targetDimensions.height}` : 'source' },
        { label: 'Frame rate', value: fpsMode === 'keep' ? `${sourceFps ? sourceFps.toFixed(1) : '—'} fps` : `${fpsMode} fps` },
        { label: 'Container', value: 'MP4 · faststart' },
      ],
      plan: { mode, targetDimensions, targetFps, fpsMode, audioKbps, hdrAction, sourceIsHDR },
    })
  }

  const reset = () => {
    if (result?.url) URL.revokeObjectURL(result.url)
    setResult(null)
    setFile(null)
    setInfo(null)
    setStep(0)
    setHdrAcknowledged(false)
    task.reset()
    analysedRef.current = null
  }

  const stepValid = step === 0 ? Boolean(info) && !analysing : true
  const canRun = Boolean(file && info) && !task.isRunning && !hdrNeedsAcknowledgement

  return (
    <div className="mx-auto w-full max-w-6xl px-4 pb-20 pt-6 sm:px-6 lg:px-8">
      {/* Header */}
      <nav aria-label="Breadcrumb" className="mb-5 flex items-center gap-1.5 text-[12px] text-slate-500">
        <a href="#/" className="inline-flex items-center gap-1.5 transition hover:text-slate-200">
          <ArrowLeft size={13} /> Advanced Tools
        </a>
        <ChevronRight size={12} className="opacity-50" />
        <span className="text-slate-400">TikTok Studio</span>
      </nav>

      <header className="flex flex-col gap-4 sm:flex-row sm:items-start">
        <IconBadge icon={WandSparkles} tone="wagle" size="lg" />
        <div className="min-w-0">
          <div className="flex flex-wrap items-center gap-2">
            <h1 className="text-[clamp(1.6rem,3.4vw,2.3rem)] font-semibold tracking-tightest text-white">
              WAGLE Method
            </h1>
            <Badge tone="wagle">Signature workflow</Badge>
            <Badge tone="slate">NXT Core</Badge>
          </div>
          <p className="mt-2 max-w-2xl text-[13.5px] leading-relaxed text-slate-400">
            Our preparation method for social uploads: analyse the source, then change only what improves the file that
            reaches the platform — container, resolution, frame rate, colour and bitrate. Independently developed, with no
            claims about defeating server-side re-encoding.
          </p>
        </div>
      </header>

      {/* Steps */}
      <ol className="mt-7 flex gap-1 overflow-x-auto rounded-2xl border border-white/[0.07] bg-white/[0.02] p-1.5 no-scrollbar">
        {STEPS.map((item, index) => {
          const Icon = STEP_ICONS[item.id]
          const active = step === index
          const done = step > index
          return (
            <li key={item.id} className="flex-1">
              <button
                type="button"
                onClick={() => setStep(index)}
                className={cx(
                  'flex w-full min-w-[104px] items-center justify-center gap-1.5 rounded-xl px-2 py-2 text-[12px] font-medium transition',
                  active
                    ? 'bg-gradient-to-br from-white/[0.14] to-white/[0.05] text-white shadow-[0_2px_10px_rgba(0,0,0,0.4)]'
                    : 'text-slate-400 hover:bg-white/[0.04] hover:text-slate-200',
                )}
                aria-current={active ? 'step' : undefined}
              >
                {done ? <Check size={13} className="text-emerald-400" /> : <Icon size={13} />}
                <span className="whitespace-nowrap">{item.label}</span>
              </button>
            </li>
          )
        })}
      </ol>

      <div className="mt-5 grid gap-5 lg:grid-cols-[minmax(0,1.4fr)_minmax(0,1fr)]">
        {/* Main column */}
        <div className="space-y-5">
          {step === 0 ? (
            <Panel className="p-5">
              <PanelHeader
                title="Analyse the source"
                subtitle="Resolution, frame rate, bitrate, codec, HDR and aspect ratio — read from the file itself."
                icon={Scan}
              />
              <div className="mt-4">
                <FileDrop
                  accept="video/*,.mkv,.mov,.webm,.avi,.m4v"
                  file={file}
                  onFile={handleFile}
                  title="Drop the video you want to prepare"
                  subtitle="MP4 · MOV · MKV · WebM"
                  hint="Analysis and encoding happen locally. The file is never uploaded."
                />
              </div>
              <FileLimitNotice file={file} className="mt-3" />

              {analysing ? (
                <div className="mt-4">
                  <Progress value={0.35} indeterminate label="Loading the engine and reading stream headers…" tone="wagle" />
                </div>
              ) : null}

              {analysisError ? (
                <Notice tone="danger" title="Analysis failed" icon={AlertTriangle} className="mt-4">
                  {analysisError}
                </Notice>
              ) : null}

              {info ? (
                <div className="mt-5 space-y-4">
                  <MediaInfoGrid info={info} />

                  {info.video?.isHDR ? (
                    <Notice tone="warning" title={`HDR source detected — ${info.video.hdr}`}>
                      HDR metadata is preserved only when the stream is copied without re-encoding. Encoding to H.264
                      requires tone-mapping, which you will confirm in the colour step.
                    </Notice>
                  ) : (
                    <Notice tone="success" title="SDR source" icon={ShieldCheck}>
                      Standard bt709 colour. No tone-mapping needed, so an H.264 export keeps the original look.
                    </Notice>
                  )}
                </div>
              ) : null}

              <div className="mt-5 flex items-center justify-between gap-3">
                <p className="text-[11.5px] text-slate-500">
                  {info ? 'Source analysed. Continue to prepare quality settings.' : 'Add a file to begin.'}
                </p>
                <Button
                  iconRight={ArrowRight}
                  disabled={!stepValid}
                  onClick={() => setStep(1)}
                >
                  Quality
                </Button>
              </div>
            </Panel>
          ) : null}

          {step === 1 ? (
            <Panel className="p-5">
              <PanelHeader
                title="Quality preparation"
                subtitle="Start from passthrough when possible: copying the stream changes nothing and loses nothing."
                icon={Sparkles}
              />
              <div className="mt-4 space-y-4">
                <Notice
                  tone={canPassthrough ? 'success' : 'info'}
                  title={canPassthrough ? 'Container passthrough is available' : 'Passthrough not available for this source'}
                >
                  {canPassthrough
                    ? 'The source streams are already MP4-compatible. With passthrough enabled and no resize, retime, denoise or sharpen, only the container is rewritten — zero quality loss.'
                    : 'The video or audio codec cannot be copied into an MP4, so the file must be re-encoded to H.264 + AAC.'}
                </Notice>

                <Checkbox
                  checked={forceEncode}
                  onChange={setForceEncode}
                  label="Force a full re-encode"
                  hint="Use this when you want new pixels regardless: quality tuning, denoise or sharpening applied."
                  disabled={!canPassthrough}
                />

                {mode === 'passthrough' ? (
                  <div className="rounded-xl border border-emerald-400/20 bg-emerald-500/[0.05] p-3.5 text-[12px] leading-relaxed text-slate-300">
                    <p className="font-medium text-emerald-200">Passthrough plan</p>
                    <p className="mt-1">
                      Video and audio streams are copied, only the MP4 container is rebuilt with faststart. Resolution,
                      frame rate, bitrate and HDR signalling stay exactly as they were exported.
                    </p>
                  </div>
                ) : (
                  <>
                    <Slider
                      label="Quality — CRF (lower is better)"
                      value={crf}
                      min={16}
                      max={30}
                      step={1}
                      onChange={setCrf}
                      display={`CRF ${crf}`}
                      hint={
                        bitrateCap
                          ? `Capped at ${(bitrateCap / 1000).toFixed(0)} Mbps by the TikTok preset, so heavy scenes cannot balloon the file.`
                          : 'CRF adapts the bitrate to scene complexity.'
                      }
                    />

                    <Field label="Encoder speed">
                      <Segmented
                        value={speed}
                        onChange={setSpeed}
                        options={SPEED_PRESETS.map((item) => ({ id: item.id, label: item.label }))}
                        size="sm"
                      />
                    </Field>

                    <div className="grid gap-3 sm:grid-cols-2">
                      <Checkbox
                        checked={denoise}
                        onChange={setDenoise}
                        label="Light denoise"
                        hint="Removes sensor grain before encoding — helps bitrate, softens fine texture."
                      />
                      <Checkbox
                        checked={sharpen}
                        onChange={setSharpen}
                        label="Light sharpening"
                        hint="Recovers perceived edge detail after scaling. Does not create real detail."
                      />
                    </div>

                    <Field label="Optional resize" hint="Overrides the TikTok preset resolution">
                      <Select
                        value={resizeHeight}
                        onChange={(event) => setResizeHeight(event.target.value)}
                        options={[
                          { value: 'none', label: 'Use deliver preset' },
                          ...RESOLUTIONS.filter((item) => item.height).map((item) => ({
                            value: String(item.height),
                            label: `Scale to ${item.label} (${item.height}p)`,
                          })),
                        ]}
                      />
                    </Field>
                  </>
                )}
              </div>

              <div className="mt-5 flex items-center justify-between gap-3">
                <Button variant="ghost" icon={ArrowLeft} onClick={() => setStep(0)}>
                  Source
                </Button>
                <Button iconRight={ArrowRight} onClick={() => setStep(2)}>
                  Motion
                </Button>
              </div>
            </Panel>
          ) : null}

          {step === 2 ? (
            <Panel className="p-5">
              <PanelHeader
                title="Frame rate preparation"
                subtitle="30 and 60 fps are the useful targets. Duplication and interpolation are labelled as what they are."
                icon={Timer}
              />
              <div className="mt-4 space-y-4">
                <div className="grid gap-2 sm:grid-cols-2">
                  <Stat label="Source frame rate" value={sourceFps ? `${sourceFps.toFixed(3)} fps` : 'not detected'} />
                  <Stat label="Source motion" value={sourceFps ? (sourceFps >= 55 ? 'already smooth' : sourceFps >= 28 ? 'standard' : 'cinematic') : '—'} />
                </div>

                <Field label="Target frame rate">
                  <Segmented
                    value={fpsMode}
                    onChange={setFpsMode}
                    options={[
                      { id: 'keep', label: 'Keep source' },
                      { id: '30', label: '30 fps' },
                      { id: '60', label: '60 fps' },
                    ]}
                  />
                </Field>

                {fpsMode !== 'keep' ? (
                  <Field label="Method">
                    <Segmented
                      value={fpsMethod}
                      onChange={setFpsMethod}
                      options={[
                        { id: 'duplicate', label: 'Duplicate / drop frames' },
                        { id: 'interpolate', label: 'Motion interpolation' },
                      ]}
                      size="sm"
                    />
                  </Field>
                ) : null}

                {fpsMode !== 'keep' && fpsMethod === 'duplicate' ? (
                  <Notice tone="info" title="Frame duplication — no new motion">
                    The encoder repeats or drops frames to reach {fpsMode} fps. The clip plays at the same speed with the
                    same motion information. This is the reliable choice and what most tools actually do.
                  </Notice>
                ) : null}

                {fpsMode !== 'keep' && fpsMethod === 'interpolate' ? (
                  <Notice tone="warning" title="Interpolation generates frames — slow and imperfect" icon={AlertTriangle}>
                    Optical-flow style interpolation is computed by the engine. It produces genuinely new frames, but can
                    warp edges, text and overlapping motion, and a browser encode may take many minutes.
                    {sourceFps && Number(fpsMode) <= sourceFps
                      ? ' The source is already at least this fast, so there is nothing to add.'
                      : ''}
                  </Notice>
                ) : null}

                {fpsMode === 'keep' ? (
                  <Notice tone="neutral" title="Keeping the source rate">
                    No retiming is applied. If the source is variable frame rate, the encode is written as constant frame
                    rate at the detected average.
                  </Notice>
                ) : null}
              </div>

              <div className="mt-5 flex items-center justify-between gap-3">
                <Button variant="ghost" icon={ArrowLeft} onClick={() => setStep(1)}>
                  Quality
                </Button>
                <Button iconRight={ArrowRight} onClick={() => setStep(3)}>
                  HDR &amp; colour
                </Button>
              </div>
            </Panel>
          ) : null}

          {step === 3 ? (
            <Panel className="p-5">
              <PanelHeader
                title="HDR and colour"
                subtitle="Nothing is converted silently. If the pipeline would drop HDR, you decide."
                icon={Palette}
              />
              <div className="mt-4 space-y-4">
                {info?.video ? (
                  <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
                    <Stat label="Primaries" value={info.video.colorPrimaries || 'unknown'} />
                    <Stat label="Transfer" value={info.video.colorTransfer || 'unknown'} />
                    <Stat label="Matrix" value={info.video.colorMatrix || 'unknown'} />
                    <Stat label="Bit depth" value={info.video.pixFmt || 'unknown'} />
                  </div>
                ) : (
                  <p className="text-[12px] text-slate-500">Analyse a source first.</p>
                )}

                {!sourceIsHDR ? (
                  <Notice tone="success" title="SDR source — nothing to convert" icon={ShieldCheck}>
                    The export stays in bt709. No tone-mapping is applied, so colours and levels are preserved.
                  </Notice>
                ) : (
                  <>
                    <Notice tone={mode === 'passthrough' ? 'success' : 'warning'} title={`HDR source — ${info.video.hdr}`}>
                      {mode === 'passthrough'
                        ? 'Passthrough copies the HDR stream untouched, so its metadata survives in the MP4 container. This is the only mode that keeps HDR intact here.'
                        : hdrAction === 'preserve'
                          ? 'A re-encode cannot preserve these HDR grades: H.264 8-bit drops the PQ/HLG transfer and bt2020 primaries. Either accept tone-mapping, or go back to quality and keep passthrough.'
                          : TONEMAP_NOTE}
                    </Notice>

                    <Field label="Colour handling">
                      <Segmented
                        value={hdrAction}
                        onChange={(value) => {
                          setHdrAction(value)
                          if (value !== 'tonemap') setHdrAcknowledged(false)
                        }}
                        options={[
                          { id: 'tonemap', label: 'Tone-map to SDR (bt709)' },
                          { id: 'preserve', label: 'Preserve HDR (passthrough only)' },
                        ]}
                      />
                    </Field>

                    {hdrAction === 'preserve' ? (
                      mode === 'passthrough' ? (
                        <Notice tone="success" title="HDR stays intact">
                          The video stream is copied, not re-encoded, so the HDR metadata travels with it. No resolution,
                          frame-rate or sharpening changes are allowed in this mode.
                        </Notice>
                      ) : (
                        <Notice tone="danger" title="This plan cannot preserve HDR">
                          Resizing, retiming, denoising or sharpening requires a re-encode, and an 8-bit H.264 re-encode
                          cannot carry PQ/HLG. Turn those options off so passthrough applies, or accept tone-mapping.
                        </Notice>
                      )
                    ) : (
                      <Checkbox
                        checked={hdrAcknowledged}
                        onChange={setHdrAcknowledged}
                        label="I understand the export will be SDR"
                        hint="Tone-mapping maps HDR highlights into the SDR range. The result is a clean, compatible file — not an HDR file."
                      />
                    )}
                  </>
                )}
              </div>

              <div className="mt-5 flex items-center justify-between gap-3">
                <Button variant="ghost" icon={ArrowLeft} onClick={() => setStep(2)}>
                  Motion
                </Button>
                <Button iconRight={ArrowRight} onClick={() => setStep(4)}>
                  Deliver
                </Button>
              </div>
            </Panel>
          ) : null}

          {step === 4 ? (
            <>
              <Panel className="p-5">
                <PanelHeader
                  title="TikTok delivery preset"
                  subtitle="1080×1920, H.264, AAC — the combination the platform handles cleanly."
                  icon={WandSparkles}
                />
                <div className="mt-4 space-y-2">
                  {TIKTOK_PRESETS.map((item) => {
                    const active = preset === item.id
                    return (
                      <button
                        key={item.id}
                        type="button"
                        onClick={() => setPreset(item.id)}
                        className={cx(
                          'flex w-full items-start justify-between gap-3 rounded-xl border p-3.5 text-left transition',
                          active
                            ? 'border-wagle-400/40 bg-wagle-400/[0.08]'
                            : 'border-white/10 bg-white/[0.025] hover:border-white/20 hover:bg-white/[0.045]',
                        )}
                      >
                        <span className="min-w-0">
                          <span className={cx('block text-[13px] font-medium', active ? 'text-wagle-200' : 'text-slate-200')}>
                            {item.label}
                          </span>
                          <span className="mt-0.5 block text-[11.5px] leading-relaxed text-slate-400">{item.note}</span>
                        </span>
                        <span className="shrink-0 pt-0.5">
                          {active ? (
                            <Check size={15} className="text-wagle-300" />
                          ) : (
                            <span className="block h-3.5 w-3.5 rounded-full border border-white/20" />
                          )}
                        </span>
                      </button>
                    )
                  })}
                </div>

                <div className="mt-4 grid gap-4 sm:grid-cols-2">
                  <Field label="Framing when the aspect differs">
                    <Segmented value={framing} onChange={setFraming} options={FRAMING} size="sm" />
                  </Field>
                  <Field label="Audio bitrate">
                    <Select
                      value={String(audioKbps)}
                      onChange={(event) => setAudioKbps(Number(event.target.value))}
                      options={[96, 128, 160, 192, 256].map((value) => ({
                        value: String(value),
                        label: `${value} kbps AAC`,
                      }))}
                    />
                  </Field>
                </div>

                {selectedPreset.width && needsResize ? (
                  <Notice tone="info" className="mt-3">
                    Source is {info?.video?.width}×{info?.video?.height}. {framing === 'crop' ? 'Cropping' : 'Padding'} to{' '}
                    {selectedPreset.width}×{selectedPreset.height}. {framing === 'crop' ? 'Check the cut edges in the result preview.' : 'Black bars will be added.'}
                  </Notice>
                ) : null}

                {hdrNeedsAcknowledgement ? (
                  <Notice tone="warning" title="Confirm the HDR decision" className="mt-3">
                    Go back to <button type="button" className="underline" onClick={() => setStep(3)}>HDR &amp; colour</button> and
                    acknowledge the SDR conversion, or switch to container passthrough on the quality step.
                  </Notice>
                ) : null}

                <div className="mt-5 flex flex-wrap items-center gap-2">
                  <Button
                    size="lg"
                    variant="wagle"
                    icon={Zap}
                    onClick={run}
                    disabled={!canRun}
                    loading={task.isRunning}
                  >
                    {task.isRunning ? 'Preparing…' : 'Process with WAGLE Method'}
                  </Button>
                  <Button variant="ghost" onClick={reset} disabled={task.isRunning}>
                    Start over
                  </Button>
                  <Badge tone="wagle" className="ml-auto">
                    {mode === 'passthrough' ? 'no re-encode' : `H.264 CRF ${crf}`}
                  </Badge>
                </div>

                <div className="mt-4">
                  <JobStatus task={task} runningLabel="Preparing upload file…" tone="wagle" />
                </div>
              </Panel>

              {result ? (
                <Panel className="p-5">
                  <PanelHeader title="Before and after" subtitle="Source versus the file this run produced." icon={Sparkles} />
                  <div className="mt-4 overflow-hidden rounded-xl border border-white/[0.07]">
                    <table className="w-full text-[12px]">
                      <thead className="bg-white/[0.04] text-[10.5px] uppercase tracking-[0.14em] text-slate-500">
                        <tr>
                          <th className="px-3 py-2 text-left font-medium">Property</th>
                          <th className="px-3 py-2 text-left font-medium">Original</th>
                          <th className="px-3 py-2 text-left font-medium">WAGLE output</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-white/[0.06]">
                        {[
                          {
                            label: 'Resolution',
                            before: info?.video ? `${info.video.width}×${info.video.height}` : '—',
                            after: result.plan.targetDimensions.width
                              ? `${result.plan.targetDimensions.width}×${result.plan.targetDimensions.height}`
                              : 'source',
                          },
                          {
                            label: 'Frame rate',
                            before: sourceFps ? `${sourceFps.toFixed(2)} fps` : '—',
                            after: result.plan.fpsMode === 'keep' ? 'unchanged' : `${result.plan.fpsMode} fps CFR`,
                          },
                          {
                            label: 'Video codec',
                            before: prettyCodec(info?.video?.codec),
                            after: result.plan.mode === 'passthrough' ? prettyCodec(info?.video?.codec) : 'H.264 (AVC)',
                          },
                          { label: 'Container', before: info?.container?.split(',')[0] || '—', after: 'MP4 · faststart' },
                          {
                            label: 'HDR',
                            before: sourceIsHDR ? info?.video?.hdr || 'HDR' : 'SDR',
                            after:
                              result.plan.mode === 'passthrough'
                                ? sourceIsHDR
                                  ? 'preserved'
                                  : 'SDR'
                                : sourceIsHDR
                                  ? 'SDR (tone-mapped)'
                                  : 'SDR',
                          },
                          {
                            label: 'Video bitrate',
                            before: formatBitrate(info?.video?.bitrate),
                            after: formatBitrate(estimatedVideoKbps),
                          },
                          {
                            label: 'File size',
                            before: formatBytes(file?.size),
                            after: formatBytes(result.size),
                          },
                        ].map((row) => (
                          <tr key={row.label}>
                            <td className="px-3 py-2 text-slate-500">{row.label}</td>
                            <td className="px-3 py-2 font-mono text-slate-300">{row.before}</td>
                            <td className="px-3 py-2 font-mono text-slate-100">{row.after}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>

                  <div className="mt-4 flex flex-wrap items-center gap-2 rounded-xl border border-wagle-400/25 bg-wagle-400/[0.06] px-4 py-3">
                    <WandSparkles size={15} className="text-wagle-300" />
                    <span className="text-[12.5px] font-medium text-wagle-200">Processed with WAGLE Method</span>
                    <span className="text-slate-600">·</span>
                    <span className="text-[11.5px] text-slate-400">Powered by NXT Core</span>
                  </div>
                </Panel>
              ) : null}
            </>
          ) : null}
        </div>

        {/* Side column */}
        <div className="space-y-5">
          <Panel className="p-5">
            <PanelHeader title="Plan summary" subtitle="What will be written, before you run it." icon={Info} />
            <div className="mt-4 space-y-1.5">
              {planSummary.map((row) => (
                <div key={row.label} className="flex items-baseline justify-between gap-3 border-b border-white/[0.05] py-1.5 last:border-0">
                  <span className="text-[12px] text-slate-500">{row.label}</span>
                  <span className="text-right font-mono text-[11.5px] text-slate-200">{row.value}</span>
                </div>
              ))}
            </div>

            {mode === 'passthrough' ? (
              <Notice tone="success" title="Zero-loss plan" className="mt-4">
                No pixels are recomputed. This is the fastest and safest path — but it cannot improve resolution, frame
                rate or compression.
              </Notice>
            ) : (
              <Notice tone="info" title="Re-encode plan" className="mt-4">
                Video is decoded and re-encoded to H.264. This is where size and compatibility are won, and where a little
                detail is spent.
              </Notice>
            )}

            {result ? (
              <div className="mt-4">
                <OutputCard
                  result={result}
                  originalSize={file?.size}
                  onReset={reset}
                  note="Your prepared upload file is ready. Send it to TikTok Studio to publish, or download it and upload from the TikTok app."
                />
              </div>
            ) : null}
          </Panel>

          <Panel className="p-5">
            <PanelHeader title="What this does not do" icon={ShieldCheck} />
            <ul className="mt-3 space-y-2.5 text-[11.5px] leading-relaxed text-slate-400">
              <li>
                <span className="text-slate-200">It cannot stop TikTok&apos;s re-encode.</span> Every upload is re-processed
                server-side. We only control the quality of what you hand over.
              </li>
              <li>
                <span className="text-slate-200">Upscaling creates no real detail.</span> A 1080p canvas from a 720p source
                is still 720p worth of information.
              </li>
              <li>
                <span className="text-slate-200">Duplicated frames are not new motion.</span> Interpolation generates frames,
                duplication repeats them.
              </li>
              <li>
                <span className="text-slate-200">4K is rarely worth it.</span> Most viewers receive a 1080p or smaller
                rendition; bitrate matters more than pixel count.
              </li>
            </ul>
            <PrivacyNote className="mt-3" />
          </Panel>

          <Panel className="p-5">
            <SideNote title="Recommended starting point">
              <p>1080×1920 · constant frame rate · 60 fps only if the source really has it · CRF 20 capped at 16 Mbps · AAC 160 kbps.</p>
              <p>If your export is already H.264/AAC MP4, settle for nothing less than container passthrough.</p>
            </SideNote>
          </Panel>
        </div>
      </div>
    </div>
  )
}
