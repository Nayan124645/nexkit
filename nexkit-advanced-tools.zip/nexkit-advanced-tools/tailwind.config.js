/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        ink: {
          950: '#05060a',
          900: '#080a10',
          850: '#0b0e15',
          800: '#10131b',
          700: '#171b25',
        },
        nxt: {
          50: '#eef1ff',
          200: '#c7cdfe',
          300: '#a5b0fd',
          400: '#818cf8',
          500: '#6366f1',
          600: '#4f46e5',
        },
        cyanic: {
          300: '#7deef8',
          400: '#35d6e8',
          500: '#06b6d4',
        },
        wagle: {
          300: '#ffd39a',
          400: '#ffb45c',
          500: '#f59e0b',
        },
      },
      fontFamily: {
        sans: [
          'ui-sans-serif',
          '-apple-system',
          'BlinkMacSystemFont',
          '"Segoe UI"',
          'Inter',
          'Roboto',
          'Helvetica',
          'Arial',
          'sans-serif',
        ],
        mono: ['ui-monospace', 'SFMono-Regular', 'Menlo', 'Consolas', 'monospace'],
      },
      letterSpacing: {
        tightest: '-0.035em',
      },
      boxShadow: {
        lift: '0 30px 60px -32px rgba(0,0,0,0.95)',
        glow: '0 0 0 1px rgba(99,102,241,0.35), 0 18px 50px -18px rgba(79,70,229,0.55)',
      },
      transitionTimingFunction: {
        smooth: 'cubic-bezier(0.22, 1, 0.36, 1)',
      },
      keyframes: {
        rise: {
          '0%': { opacity: '0', transform: 'translateY(10px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
        shimmer: {
          '0%': { backgroundPosition: '-200% 0' },
          '100%': { backgroundPosition: '200% 0' },
        },
        pulseSoft: {
          '0%, 100%': { opacity: '0.55' },
          '50%': { opacity: '1' },
        },
      },
      animation: {
        rise: 'rise 0.5s cubic-bezier(0.22,1,0.36,1) both',
        shimmer: 'shimmer 2.4s linear infinite',
        pulseSoft: 'pulseSoft 2.4s ease-in-out infinite',
      },
    },
  },
  plugins: [],
}
