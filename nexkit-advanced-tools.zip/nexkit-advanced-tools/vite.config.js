import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

/**
 * Base path control for GitHub Pages.
 *   standalone / local dev      -> VITE_BASE_PATH unset  => "/"
 *   inside an existing NeXkiT   -> VITE_BASE_PATH=/nexkit/tools/
 */
const base = process.env.VITE_BASE_PATH || '/'

const allowedHosts = (process.env.VITE_ALLOWED_HOSTS || '')
  .split(',')
  .map((h) => h.trim())
  .filter(Boolean)

export default defineConfig({
  base,
  plugins: [react()],
  server: {
    host: '0.0.0.0',
    port: 5173,
    strictPort: false,
    allowedHosts: allowedHosts.length ? allowedHosts : undefined,
  },
  preview: {
    host: '0.0.0.0',
    port: 4173,
    allowedHosts: allowedHosts.length ? allowedHosts : undefined,
  },
  build: {
    target: 'es2020',
    sourcemap: false,
    chunkSizeWarningLimit: 1600,
  },
  optimizeDeps: {
    exclude: ['@ffmpeg/ffmpeg', '@ffmpeg/util'],
  },
})
